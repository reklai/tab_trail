import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const ROOT = process.cwd();

function readText(pathFromRoot) {
  return readFileSync(resolve(ROOT, pathFromRoot), "utf8");
}

test("breadcrumb overlay includes mobile tightening and scroll containment", () => {
  const css = readText("src/lib/ui/panels/breadcrumbTrail/breadcrumbTrail.css");
  assert.match(css, /@media \(max-width:/);
  assert.match(css, /border-radius:\s*8px/);
  assert.match(css, /overflow-x:\s*auto/);
});

test("popup layout is fixed-height, scroll-safe, and never uses 100vh", () => {
  const popupCss = readText("src/entryPoints/toolbarPopup/toolbarPopup.css");
  assert.match(popupCss, /height:\s*440px/);
  assert.match(popupCss, /\.popup-scroll\s*\{[\s\S]*flex:\s*1 1 auto/);
  assert.doesNotMatch(popupCss, /100vh/);
  assert.match(popupCss, /grid-template-columns:\s*minmax\(0,\s*1fr\)/);
});

test("options layout collapses its grid on narrow viewports", () => {
  const optionsCss = readText("src/entryPoints/optionsPage/optionsPage.css");
  assert.match(optionsCss, /\.setting-grid\s*\{[\s\S]*grid-template-columns:\s*repeat\(2,\s*minmax\(0,\s*1fr\)\)/);
  assert.match(optionsCss, /@media \(max-width:\s*620px\)/);
  assert.match(optionsCss, /grid-template-columns:\s*minmax\(0,\s*1fr\)/);
});
