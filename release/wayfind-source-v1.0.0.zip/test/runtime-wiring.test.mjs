import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const ROOT = process.cwd();

function readSource(pathFromRoot) {
  return readFileSync(resolve(ROOT, pathFromRoot), "utf8");
}

test("background composes the domain, handler, router, and migration at top level", () => {
  const source = readSource("src/entryPoints/backgroundRuntime/background.ts");
  assert.match(source, /createTrailDomain\(\)/);
  assert.match(source, /registerLifecycleListeners\(\)/);
  assert.match(source, /registerRuntimeMessageRouter\(\[/);
  assert.match(source, /createTrailMessageHandler\(/);
  assert.match(source, /migrateStorageIfNeeded\(\)/);
  assert.match(source, /ensureLoaded\(\)/);
  // Listener registration must precede the async bootstrap for MV3 workers.
  assert.ok(
    source.indexOf("registerRuntimeMessageRouter") < source.indexOf("async function bootstrapBackground"),
    "router registration must happen before the async bootstrap",
  );
});

test("message handler routes every trail message and falls back to UNHANDLED", () => {
  const source = readSource("src/lib/backgroundRuntime/handlers/trailMessageHandler.ts");
  for (const messageType of [
    "TRAIL_CONTENT_READY",
    "TRAIL_GET",
    "TRAIL_TOGGLE_OVERLAY",
    "TRAIL_JUMP",
    "TRAIL_OPEN_IN_NEW_TAB",
    "TRAIL_OVERLAY_STATE",
    "WAYFIND_OPEN_OPTIONS",
  ]) {
    assert.match(source, new RegExp(`case "${messageType}"`), `handler must route ${messageType}`);
  }
  assert.match(source, /default:\s*\n?\s*return UNHANDLED/);
});

test("router rethrows on the trail query so its retrying caller is not misled", () => {
  const source = readSource("src/lib/backgroundRuntime/handlers/runtimeRouter.ts");
  assert.match(source, /TRAIL_GET/);
  assert.match(source, /throw error/);
});

test("domain registers all three webNavigation intakes and serializes per tab", () => {
  const source = readSource("src/lib/backgroundRuntime/domains/trailDomain.ts");
  assert.match(source, /webNavigation\.onCommitted\.addListener/);
  assert.match(source, /webNavigation\.onHistoryStateUpdated\.addListener/);
  assert.match(source, /webNavigation\.onReferenceFragmentUpdated\.addListener/);
  assert.match(source, /frameId !== 0/);
  assert.match(source, /createKeyedTaskQueue\(\)/);
  // Session-storage mirror with the storage.local wipe fallback.
  assert.match(source, /session\?: SessionStorageArea/);
  assert.match(source, /TRAIL_MIRROR_KEY_PREFIX/);
  assert.match(source, /runtime\.onStartup\.addListener/);
  assert.match(source, /tabs\.onRemoved\.addListener/);
});

test("content script captures both trigger event kinds in capture phase and is re-injection safe", () => {
  const source = readSource("src/lib/appInit/appInit.ts");
  assert.match(source, /addEventListener\("keydown", keydownHandler, true\)/);
  assert.match(source, /addEventListener\("mousedown", mousedownHandler, true\)/);
  assert.match(source, /addEventListener\("contextmenu", mouseFollowUpHandler, true\)/);
  assert.match(source, /matchesToggleTrigger/);
  assert.match(source, /window\.__wayfindCleanup/);
  assert.match(source, /announceTrailContentReady/);
  assert.match(source, /HISTORY_GO/);
});

test("trigger matcher rejects auto-repeat and untrusted events", () => {
  const source = readSource("src/lib/core/trail/trailCore.ts");
  assert.match(source, /event\.repeat/);
  assert.match(source, /event\.isTrusted/);
  assert.match(source, /applyNavigationEvent/);
  assert.match(source, /resolveJumpPlan/);
});

test("runtime message contract declares all message literals", () => {
  const source = readSource("src/lib/common/contracts/runtimeMessages.ts");
  for (const messageType of [
    "WAYFIND_PING",
    "TRAIL_SHOW",
    "TRAIL_UPDATED",
    "HISTORY_GO",
    "TRAIL_CONTENT_READY",
    "TRAIL_GET",
    "TRAIL_TOGGLE_OVERLAY",
    "TRAIL_JUMP",
    "TRAIL_OPEN_IN_NEW_TAB",
    "TRAIL_OVERLAY_STATE",
    "WAYFIND_OPEN_OPTIONS",
  ]) {
    assert.match(source, new RegExp(messageType), `contract must declare ${messageType}`);
  }
});
