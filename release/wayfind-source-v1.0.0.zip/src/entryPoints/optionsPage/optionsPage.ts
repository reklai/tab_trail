// Options page: the full Wayfind settings surface. Every control saves on
// change and round-trips through the shared normalizers so stored data stays
// valid. The trigger capture button records either a keydown (event.code) or
// a mousedown (event.button) — whichever the user performs first.

import browser from "webextension-polyfill";
import {
  DEFAULT_WAYFIND_SETTINGS,
  DEFAULT_WAYFIND_TRIGGER,
  formatTriggerKeyLabel,
  formatTriggerMouseLabel,
  formatWayfindTriggerCombo,
  isValidTriggerKeyCode,
  isValidTriggerMouseButton,
  loadWayfindSettings,
  saveWayfindSettings,
} from "../../lib/common/contracts/wayfind";
import { populateModifierSelect } from "../../lib/ui/settings/settingsControls";

let settings: WayfindSettings = {
  ...DEFAULT_WAYFIND_SETTINGS,
  trigger: { ...DEFAULT_WAYFIND_TRIGGER },
};
let capturing = false;

function element<T extends HTMLElement>(id: string): T | null {
  return document.getElementById(id) as T | null;
}

function triggerButtonLabel(): string {
  return settings.trigger.kind === "mouse"
    ? formatTriggerMouseLabel(settings.trigger.mouseButton)
    : formatTriggerKeyLabel(settings.trigger.keyCode);
}

function renderSettings(): void {
  const modifierSelect = element<HTMLSelectElement>("triggerModifier");
  if (modifierSelect) populateModifierSelect(modifierSelect, settings.trigger.modifier);

  const shiftInput = element<HTMLInputElement>("triggerWithShift");
  if (shiftInput) shiftInput.checked = settings.trigger.withShift;

  const captureButton = element("triggerCaptureBtn");
  if (captureButton && !capturing) {
    captureButton.textContent = triggerButtonLabel();
    captureButton.classList.remove("is-capturing");
  }

  const maxVisibleInput = element<HTMLInputElement>("maxVisibleSegments");
  if (maxVisibleInput && document.activeElement !== maxVisibleInput) {
    maxVisibleInput.value = String(settings.maxVisibleSegments);
  }

  const arrowsInput = element<HTMLInputElement>("showTransitionArrows");
  if (arrowsInput) arrowsInput.checked = settings.showTransitionArrows;

  const combo = formatWayfindTriggerCombo(settings.trigger);
  for (const node of document.querySelectorAll<HTMLElement>("[data-combo]")) {
    node.textContent = combo;
  }
}

async function persistSettings(): Promise<void> {
  await saveWayfindSettings(settings);
  settings = await loadWayfindSettings();
  renderSettings();
}

function captureKeydown(event: KeyboardEvent): void {
  event.preventDefault();
  event.stopPropagation();
  if (event.key === "Escape") {
    stopCapture();
    return;
  }
  if (isValidTriggerKeyCode(event.code)) {
    settings = {
      ...settings,
      trigger: { ...settings.trigger, kind: "key", keyCode: event.code },
    };
    stopCapture();
    void persistSettings();
  }
  // Modifier-only presses keep the capture open until a valid key arrives.
}

function captureMousedown(event: MouseEvent): void {
  if (!isValidTriggerMouseButton(event.button)) {
    // A left click cancels the capture (it is not a valid trigger button).
    if (event.button === 0) stopCapture();
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  settings = {
    ...settings,
    trigger: { ...settings.trigger, kind: "mouse", mouseButton: event.button },
  };
  stopCapture();
  void persistSettings();
}

function captureContextMenu(event: MouseEvent): void {
  // Right-button captures must not also open the page context menu.
  event.preventDefault();
  event.stopPropagation();
}

function startCapture(): void {
  if (capturing) return;
  capturing = true;
  const captureButton = element("triggerCaptureBtn");
  if (captureButton) {
    captureButton.textContent = "Press a key or mouse button…";
    captureButton.classList.add("is-capturing");
  }
  // Delay the mousedown hook one tick so the click that opened the capture
  // does not immediately cancel it.
  window.setTimeout(() => {
    if (!capturing) return;
    window.addEventListener("keydown", captureKeydown, true);
    window.addEventListener("mousedown", captureMousedown, true);
    window.addEventListener("contextmenu", captureContextMenu, true);
  }, 0);
}

function stopCapture(): void {
  if (!capturing) return;
  capturing = false;
  window.removeEventListener("keydown", captureKeydown, true);
  window.removeEventListener("mousedown", captureMousedown, true);
  window.removeEventListener("contextmenu", captureContextMenu, true);
  renderSettings();
}

function bindControls(): void {
  element<HTMLSelectElement>("triggerModifier")?.addEventListener("change", (event) => {
    const modifier = (event.target as HTMLSelectElement).value as WayfindModifierKey;
    settings = { ...settings, trigger: { ...settings.trigger, modifier } };
    void persistSettings();
  });

  element<HTMLInputElement>("triggerWithShift")?.addEventListener("change", (event) => {
    const withShift = (event.target as HTMLInputElement).checked;
    settings = { ...settings, trigger: { ...settings.trigger, withShift } };
    void persistSettings();
  });

  element("triggerCaptureBtn")?.addEventListener("click", startCapture);

  element<HTMLInputElement>("maxVisibleSegments")?.addEventListener("change", (event) => {
    const value = Number((event.target as HTMLInputElement).value);
    settings = { ...settings, maxVisibleSegments: value };
    void persistSettings();
  });

  element<HTMLInputElement>("showTransitionArrows")?.addEventListener("change", (event) => {
    settings = { ...settings, showTransitionArrows: (event.target as HTMLInputElement).checked };
    void persistSettings();
  });

  element("resetPositionBtn")?.addEventListener("click", () => {
    settings = { ...settings, overlayPosition: null };
    void persistSettings();
  });

  element("resetBtn")?.addEventListener("click", () => {
    settings = { ...DEFAULT_WAYFIND_SETTINGS, trigger: { ...DEFAULT_WAYFIND_TRIGGER } };
    void persistSettings();
  });

  element("closeBtn")?.addEventListener("click", async () => {
    const tab = await browser.tabs.getCurrent().catch(() => null);
    if (tab?.id != null) {
      await browser.tabs.remove(tab.id).catch(() => {});
    }
  });
}

async function init(): Promise<void> {
  settings = await loadWayfindSettings();
  renderSettings();
  bindControls();
}

void init();
