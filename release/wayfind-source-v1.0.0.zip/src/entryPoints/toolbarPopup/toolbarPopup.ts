// Toolbar popup: quick trigger (keybind) editor plus the current tab's
// navigation trail as a clickable vertical list. The list is the fallback
// surface for privileged pages (chrome://, about:, store pages) where the
// in-page overlay cannot run. Every settings change persists immediately and
// confirms with a small "Saved" toast, mirroring the reference extension.

import browser from "webextension-polyfill";
import {
  formatTriggerKeyLabel,
  formatTriggerMouseLabel,
  formatWayfindTriggerCombo,
  isValidTriggerKeyCode,
  isValidTriggerMouseButton,
  loadWayfindSettings,
  saveWayfindSettings,
} from "../../lib/common/contracts/wayfind";
import { formatTrailTimestamp } from "../../lib/core/trail/trailCore";
import { getTrailWithRetry, jumpToTrailEntry } from "../../lib/adapters/runtime/wayfindApi";
import { populateModifierSelect } from "../../lib/ui/settings/settingsControls";

let settings: WayfindSettings | null = null;
let capturing = false;
let toastTimer = 0;
let currentTabId: number | undefined;

function element<T extends HTMLElement>(id: string): T | null {
  return document.getElementById(id) as T | null;
}

function showPopupToast(message: string): void {
  const toast = element("popupToast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("is-visible");
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 1800);
}

function displayUrl(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.host}${parsed.pathname}`.replace(/\/$/, "") || parsed.host;
  } catch (_) {
    return url;
  }
}

function extractLetter(url: string): string {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    return (host[0] ?? "?").toUpperCase();
  } catch (_) {
    return "?";
  }
}

function faviconNode(entry: TrailEntry): HTMLElement {
  const wrap = document.createElement("span");
  wrap.className = "trail-item-favicon";
  if (entry.favIconUrl && /^https?:/.test(entry.favIconUrl)) {
    const img = document.createElement("img");
    img.src = entry.favIconUrl;
    img.alt = "";
    img.addEventListener("error", () => {
      img.remove();
      wrap.textContent = extractLetter(entry.url);
    });
    wrap.appendChild(img);
    return wrap;
  }
  wrap.textContent = extractLetter(entry.url);
  return wrap;
}

// --- Trigger settings ---

function triggerButtonLabel(trigger: WayfindTrigger): string {
  return trigger.kind === "mouse"
    ? formatTriggerMouseLabel(trigger.mouseButton)
    : formatTriggerKeyLabel(trigger.keyCode);
}

function renderSettings(): void {
  if (!settings) return;
  const { trigger } = settings;

  const modifierSelect = element<HTMLSelectElement>("triggerModifier");
  if (modifierSelect) populateModifierSelect(modifierSelect, trigger.modifier);

  const shiftInput = element<HTMLInputElement>("triggerWithShift");
  if (shiftInput) shiftInput.checked = trigger.withShift;

  const captureButton = element("triggerCaptureBtn");
  if (captureButton && !capturing) {
    captureButton.textContent = triggerButtonLabel(trigger);
    captureButton.classList.remove("is-capturing");
  }

  const combo = formatWayfindTriggerCombo(trigger);
  const shortcutLabel = element("shortcutLabel");
  if (shortcutLabel) shortcutLabel.textContent = `Press ${combo} to show your trail`;
}

async function persistTrigger(patch: Partial<WayfindTrigger>): Promise<void> {
  if (!settings) return;
  settings = { ...settings, trigger: { ...settings.trigger, ...patch } };
  await saveWayfindSettings(settings);
  settings = await loadWayfindSettings();
  renderSettings();
  showPopupToast("Saved");
}

function captureKeydown(event: KeyboardEvent): void {
  event.preventDefault();
  event.stopPropagation();
  if (event.key === "Escape") {
    stopCapture();
    return;
  }
  if (isValidTriggerKeyCode(event.code)) {
    stopCapture();
    void persistTrigger({ kind: "key", keyCode: event.code });
  }
  // Modifier-only presses keep the capture open until a valid key arrives.
}

function captureMousedown(event: MouseEvent): void {
  if (!isValidTriggerMouseButton(event.button)) {
    // A left click cancels the capture (it is not a valid trigger button).
    if (event.button === 0) stopCapture();
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  stopCapture();
  void persistTrigger({ kind: "mouse", mouseButton: event.button });
}

function captureContextMenu(event: MouseEvent): void {
  // Right-button captures must not also open the popup's context menu.
  event.preventDefault();
  event.stopPropagation();
}

function startCapture(): void {
  if (capturing) return;
  capturing = true;
  const captureButton = element("triggerCaptureBtn");
  if (captureButton) {
    captureButton.textContent = "Press key / button…";
    captureButton.classList.add("is-capturing");
  }
  // Delay the mousedown hook one tick so the click that opened the capture
  // does not immediately cancel it.
  window.setTimeout(() => {
    if (!capturing) return;
    window.addEventListener("keydown", captureKeydown, true);
    window.addEventListener("mousedown", captureMousedown, true);
    window.addEventListener("contextmenu", captureContextMenu, true);
  }, 0);
}

function stopCapture(): void {
  if (!capturing) return;
  capturing = false;
  window.removeEventListener("keydown", captureKeydown, true);
  window.removeEventListener("mousedown", captureMousedown, true);
  window.removeEventListener("contextmenu", captureContextMenu, true);
  renderSettings();
}

// --- Trail list ---

function renderTrail(state: TrailState): void {
  const list = element("trailList");
  const empty = element("trailEmpty");
  const count = element("trailCount");
  if (!list || !empty || !count) return;

  list.textContent = "";
  if (state.entries.length === 0) {
    empty.hidden = false;
    count.textContent = "";
    return;
  }
  empty.hidden = true;
  count.textContent = `${state.entries.length} page${state.entries.length === 1 ? "" : "s"}`;

  const now = Date.now();
  state.entries.forEach((entry, index) => {
    const item = document.createElement("li");
    item.className = "trail-item";
    if (index === state.cursor) item.classList.add("is-current");
    if (index > state.cursor) item.classList.add("is-forward");

    item.appendChild(faviconNode(entry));

    const body = document.createElement("div");
    body.className = "trail-item-body";
    const title = document.createElement("div");
    title.className = "trail-item-title";
    title.textContent = entry.title.trim() || displayUrl(entry.url);
    const url = document.createElement("div");
    url.className = "trail-item-url";
    url.textContent = displayUrl(entry.url);
    body.appendChild(title);
    body.appendChild(url);
    item.appendChild(body);

    const time = document.createElement("span");
    time.className = "trail-item-time";
    time.textContent = formatTrailTimestamp(entry.timestamp, now);
    item.appendChild(time);

    item.title = entry.url;
    if (index !== state.cursor) {
      item.addEventListener("click", async () => {
        const result = await jumpToTrailEntry(index, currentTabId);
        if (result && result.ok === false) {
          showPopupToast(result.reason || "Couldn't navigate.");
          return;
        }
        window.close();
      });
    }
    list.appendChild(item);
  });
}

async function refreshTrail(): Promise<void> {
  try {
    const [activeTab] = await browser.tabs
      .query({ active: true, currentWindow: true })
      .catch(() => []);
    currentTabId = activeTab?.id;
    const snapshot = await getTrailWithRetry(currentTabId);
    renderTrail(snapshot.state);
  } catch (_) {
    showPopupToast("Couldn't read the trail.");
  }
}

function bindControls(): void {
  element("closePopupBtn")?.addEventListener("click", () => window.close());

  element<HTMLSelectElement>("triggerModifier")?.addEventListener("change", (event) => {
    const modifier = (event.target as HTMLSelectElement).value as WayfindModifierKey;
    void persistTrigger({ modifier });
  });

  element<HTMLInputElement>("triggerWithShift")?.addEventListener("change", (event) => {
    void persistTrigger({ withShift: (event.target as HTMLInputElement).checked });
  });

  element("triggerCaptureBtn")?.addEventListener("click", startCapture);

  element("settingsBtn")?.addEventListener("click", async () => {
    try {
      await browser.runtime.openOptionsPage();
    } catch (_) {
      // Ignore; nothing else to do from the popup.
    }
    window.close();
  });
}

async function init(): Promise<void> {
  settings = await loadWayfindSettings();
  renderSettings();
  bindControls();
  await refreshTrail();
}

void init();
