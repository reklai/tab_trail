// Compact horizontal breadcrumb bar showing the tab's navigation trail. Built
// on the shared Shadow DOM panel host so it stays isolated from page styles,
// but deliberately NON-modal: the host is click-through outside the bar, and
// nothing inside the bar is focusable, so the page keeps keyboard focus and
// the host's focus-reclaim machinery never engages. Segments are clicked to
// jump, right-clicked for a small in-shadow menu, and the bar is dragged by
// its grip to reposition (position persisted via a callback).

import styles from "./breadcrumbTrail.css";
import {
  createPanelHost,
  dismissPanel,
  getBaseStyles,
  registerPanelCleanup,
} from "../../../common/utils/panelHost";
import { escapeHtml, extractDomain } from "../../../common/utils/helpers";
import { formatTrailTimestamp, truncateTrailTitle } from "../../../core/trail/trailCore";

export interface BreadcrumbTrailCallbacks {
  onJump(index: number): void;
  onOpenInNewTab(index: number): void;
  onClose(): void;
  onPositionChange(position: WayfindOverlayPosition): void;
}

export interface BreadcrumbTrailOptions {
  settings: WayfindSettings;
  callbacks: BreadcrumbTrailCallbacks;
}

const DEFAULT_POSITION: WayfindOverlayPosition = { xPercent: 50, yPercent: 8 };

interface OverlaySession {
  shadow: ShadowRoot;
  bar: HTMLDivElement;
  layer: HTMLDivElement;
  options: BreadcrumbTrailOptions;
  state: TrailState;
  expanded: boolean;
  position: WayfindOverlayPosition;
}

let session: OverlaySession | null = null;

export function isBreadcrumbTrailOpen(): boolean {
  return session !== null;
}

export function hideBreadcrumbTrail(): void {
  if (!session) return;
  dismissPanel();
}

export function updateBreadcrumbTrail(state: TrailState): void {
  if (!session) return;
  session.state = state;
  renderBar();
}

export function showBreadcrumbTrail(state: TrailState, options: BreadcrumbTrailOptions): void {
  const { host, shadow } = createPanelHost();
  // Non-modal: only the bar itself accepts pointer events.
  host.style.pointerEvents = "none";

  const style = document.createElement("style");
  style.textContent = getBaseStyles() + styles;
  shadow.appendChild(style);

  const layer = document.createElement("div");
  layer.className = "wf-layer";
  shadow.appendChild(layer);

  const bar = document.createElement("div");
  bar.className = "wf-bar";
  bar.setAttribute("role", "navigation");
  bar.setAttribute("aria-label", "Navigation trail");
  layer.appendChild(bar);

  session = {
    shadow,
    bar,
    layer,
    options,
    state,
    expanded: false,
    position: options.settings.overlayPosition ?? DEFAULT_POSITION,
  };

  applyPosition();
  renderBar();

  const onDocumentKeydown = (event: KeyboardEvent): void => {
    if (event.key !== "Escape" || !session) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    hideBreadcrumbTrail();
  };
  document.addEventListener("keydown", onDocumentKeydown, true);

  registerPanelCleanup(() => {
    document.removeEventListener("keydown", onDocumentKeydown, true);
    const closing = session;
    session = null;
    closing?.options.callbacks.onClose();
  });
}

function applyPosition(): void {
  if (!session) return;
  const { xPercent, yPercent } = session.position;
  session.bar.style.left = `${xPercent}%`;
  session.bar.style.top = `${yPercent}%`;
}

// --- Rendering ---

function faviconElement(entry: TrailEntry): HTMLElement {
  if (entry.favIconUrl && /^https?:/.test(entry.favIconUrl)) {
    const img = document.createElement("img");
    img.className = "wf-favicon";
    img.src = entry.favIconUrl;
    img.alt = "";
    img.addEventListener("error", () => {
      img.replaceWith(faviconLetterElement(entry));
    });
    return img;
  }
  return faviconLetterElement(entry);
}

function faviconLetterElement(entry: TrailEntry): HTMLElement {
  const letter = document.createElement("span");
  letter.className = "wf-favicon wf-favicon-letter";
  const domain = extractDomain(entry.url);
  letter.textContent = (domain[0] ?? "?").toUpperCase();
  return letter;
}

function entryLabel(entry: TrailEntry): string {
  if (entry.title.trim() !== "") return truncateTrailTitle(entry.title);
  const domain = extractDomain(entry.url);
  return truncateTrailTitle(domain !== "" ? domain : entry.url);
}

function separatorElement(nextEntry: TrailEntry, showTransitionArrows: boolean): HTMLElement {
  const sep = document.createElement("span");
  sep.className = "wf-sep";
  sep.setAttribute("aria-hidden", "true");
  if (!showTransitionArrows) {
    sep.textContent = "›";
    return sep;
  }
  // Differentiate how the next hop happened: a followed link vs an address-bar
  // entry vs in-page (SPA/hash) routing.
  if (nextEntry.transition === "typed") {
    sep.textContent = "↦";
    sep.classList.add("wf-sep-typed");
  } else if (nextEntry.transition === "spa" || nextEntry.transition === "fragment") {
    sep.textContent = "⇢";
    sep.classList.add("wf-sep-spa");
  } else {
    sep.textContent = "→";
  }
  sep.title = nextEntry.transition;
  return sep;
}

// Picks which entry indices render when the trail is longer than the visible
// budget: the first entry stays as the anchor, the tail window keeps the
// cursor visible, and a "+N more" pill stands in for the collapsed middle.
function visibleIndices(state: TrailState, maxVisible: number, expanded: boolean): number[] {
  const total = state.entries.length;
  if (expanded || total <= maxVisible) {
    return state.entries.map((_, index) => index);
  }
  const tailCount = Math.max(2, maxVisible - 2);
  let tailStart = total - tailCount;
  // Keep the cursor visible even if it sits inside the would-be collapsed middle.
  if (state.cursor < tailStart && state.cursor > 0) {
    tailStart = state.cursor;
  }
  const indices = [0];
  for (let index = tailStart; index < total; index += 1) {
    if (index > 0) indices.push(index);
  }
  return indices;
}

function renderBar(): void {
  if (!session) return;
  const { bar, state, options } = session;
  const { settings, callbacks } = options;
  closeSegmentMenu();
  hideTooltip();
  bar.textContent = "";

  bar.appendChild(buildGrip());

  if (state.entries.length === 0) {
    const empty = document.createElement("span");
    empty.className = "wf-empty";
    empty.textContent = "No trail yet. Start clicking links to build one.";
    bar.appendChild(empty);
    bar.appendChild(buildCloseButton());
    return;
  }

  const indices = visibleIndices(state, settings.maxVisibleSegments, session.expanded);
  let previousRendered: number | null = null;
  for (const index of indices) {
    if (previousRendered !== null) {
      if (index > previousRendered + 1) {
        bar.appendChild(buildMorePill(index - previousRendered - 1));
      }
      bar.appendChild(separatorElement(state.entries[index], settings.showTransitionArrows));
    }
    bar.appendChild(buildSegment(index, state, callbacks));
    previousRendered = index;
  }

  bar.appendChild(buildCloseButton());
}

function buildGrip(): HTMLElement {
  const grip = document.createElement("span");
  grip.className = "wf-grip";
  grip.textContent = "⠿";
  grip.title = "Drag to move";
  grip.addEventListener("pointerdown", startDrag);
  return grip;
}

function buildCloseButton(): HTMLElement {
  const close = document.createElement("span");
  close.className = "wf-close";
  close.textContent = "✕";
  close.title = "Hide (Esc)";
  close.addEventListener("click", () => hideBreadcrumbTrail());
  return close;
}

function buildMorePill(hiddenCount: number): HTMLElement {
  const pill = document.createElement("span");
  pill.className = "wf-more";
  pill.textContent = `+${hiddenCount} more`;
  pill.title = "Show the full trail";
  pill.addEventListener("click", () => {
    if (!session) return;
    session.expanded = true;
    renderBar();
  });
  return pill;
}

function buildSegment(
  index: number,
  state: TrailState,
  callbacks: BreadcrumbTrailCallbacks,
): HTMLElement {
  const entry = state.entries[index];
  const segment = document.createElement("span");
  segment.className = "wf-segment";
  if (index === state.cursor) segment.classList.add("wf-segment-current");
  if (index > state.cursor) segment.classList.add("wf-segment-forward");
  segment.setAttribute("aria-current", index === state.cursor ? "page" : "false");

  segment.appendChild(faviconElement(entry));
  const label = document.createElement("span");
  label.className = "wf-label";
  label.textContent = entryLabel(entry);
  segment.appendChild(label);

  segment.addEventListener("click", (event) => {
    event.preventDefault();
    if (index !== state.cursor) callbacks.onJump(index);
  });
  segment.addEventListener("mouseenter", () => showTooltip(segment, entry));
  segment.addEventListener("mouseleave", hideTooltip);
  segment.addEventListener("contextmenu", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openSegmentMenu(segment, index, entry, callbacks);
  });
  return segment;
}

// --- Tooltip ---

let tooltipElement: HTMLDivElement | null = null;

function showTooltip(anchor: HTMLElement, entry: TrailEntry): void {
  if (!session) return;
  hideTooltip();
  const tooltip = document.createElement("div");
  tooltip.className = "wf-tooltip";
  tooltip.innerHTML = `
    <div class="wf-tooltip-url">${escapeHtml(entry.url)}</div>
    <div class="wf-tooltip-time">${escapeHtml(formatTrailTimestamp(entry.timestamp, Date.now()))}</div>
  `;
  session.layer.appendChild(tooltip);
  positionPopover(tooltip, anchor);
  tooltipElement = tooltip;
}

function hideTooltip(): void {
  tooltipElement?.remove();
  tooltipElement = null;
}

// --- Segment context menu (in-shadow; the native menu is suppressed) ---

let menuElement: HTMLDivElement | null = null;
let menuDismissCleanup: (() => void) | null = null;

function closeSegmentMenu(): void {
  menuElement?.remove();
  menuElement = null;
  if (menuDismissCleanup) {
    menuDismissCleanup();
    menuDismissCleanup = null;
  }
}

async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch (_) {
    // Clipboard API can be unavailable in content scripts; fall back below.
  }
  const scratch = document.createElement("textarea");
  scratch.value = text;
  scratch.style.cssText = "position:fixed;opacity:0;pointer-events:none;";
  document.body.appendChild(scratch);
  scratch.select();
  try {
    document.execCommand("copy");
  } finally {
    scratch.remove();
  }
}

function openSegmentMenu(
  anchor: HTMLElement,
  index: number,
  entry: TrailEntry,
  callbacks: BreadcrumbTrailCallbacks,
): void {
  if (!session) return;
  closeSegmentMenu();
  hideTooltip();

  const menu = document.createElement("div");
  menu.className = "wf-menu";
  const items: Array<{ label: string; action: () => void }> = [
    { label: "Open in new tab", action: () => callbacks.onOpenInNewTab(index) },
    { label: "Copy URL", action: () => void copyText(entry.url) },
    {
      label: "Copy as Markdown",
      action: () => void copyText(`[${entry.title.trim() || entry.url}](${entry.url})`),
    },
  ];
  for (const item of items) {
    const row = document.createElement("div");
    row.className = "wf-menu-item";
    row.textContent = item.label;
    row.addEventListener("click", (event) => {
      event.stopPropagation();
      closeSegmentMenu();
      item.action();
    });
    menu.appendChild(row);
  }
  session.layer.appendChild(menu);
  positionPopover(menu, anchor);
  menuElement = menu;

  const onOutsidePointer = (event: Event): void => {
    if (menuElement && event.composedPath().includes(menuElement)) return;
    closeSegmentMenu();
  };
  document.addEventListener("pointerdown", onOutsidePointer, true);
  menuDismissCleanup = () => {
    document.removeEventListener("pointerdown", onOutsidePointer, true);
  };
}

// Places a popover under its anchor segment, clamped to the viewport.
function positionPopover(popover: HTMLElement, anchor: HTMLElement): void {
  const anchorRect = anchor.getBoundingClientRect();
  popover.style.left = "0px";
  popover.style.top = "0px";
  const popoverRect = popover.getBoundingClientRect();
  const width = popoverRect.width || 240;
  const left = Math.min(
    Math.max(8, anchorRect.left),
    Math.max(8, window.innerWidth - width - 8),
  );
  let top = anchorRect.bottom + 6;
  if (top + popoverRect.height > window.innerHeight - 8) {
    top = Math.max(8, anchorRect.top - popoverRect.height - 6);
  }
  popover.style.left = `${left}px`;
  popover.style.top = `${top}px`;
}

// --- Dragging ---

function startDrag(event: PointerEvent): void {
  if (!session) return;
  event.preventDefault();
  const { bar } = session;
  const barRect = bar.getBoundingClientRect();
  const grabOffsetX = event.clientX - (barRect.left + barRect.width / 2);
  const grabOffsetY = event.clientY - barRect.top;
  bar.classList.add("wf-dragging");

  const onMove = (moveEvent: PointerEvent): void => {
    if (!session) return;
    const x = ((moveEvent.clientX - grabOffsetX) / window.innerWidth) * 100;
    const y = ((moveEvent.clientY - grabOffsetY) / window.innerHeight) * 100;
    session.position = {
      xPercent: Math.min(Math.max(x, 0), 100),
      yPercent: Math.min(Math.max(y, 0), 96),
    };
    applyPosition();
  };

  const onEnd = (): void => {
    window.removeEventListener("pointermove", onMove, true);
    window.removeEventListener("pointerup", onEnd, true);
    window.removeEventListener("pointercancel", onEnd, true);
    if (!session) return;
    session.bar.classList.remove("wf-dragging");
    session.options.callbacks.onPositionChange(session.position);
  };

  window.addEventListener("pointermove", onMove, true);
  window.addEventListener("pointerup", onEnd, true);
  window.addEventListener("pointercancel", onEnd, true);
}
