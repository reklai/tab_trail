"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill6 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabtrail.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TABTRAIL_STORAGE_KEYS = {
    settings: "tabtrailSettings",
    // Durable named path snapshots (library). Distinct from session trail mirrors.
    savedTrails: "tabtrailSavedTrails"
  };
  var TABTRAIL_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "super"
  ];
  var TRIGGER_KEY_CODE_PATTERN = /^(?:Key[A-Z]|Digit[0-9])$/;
  var TRIGGER_MOUSE_BUTTONS = [0, 1, 2];
  var MIN_VISIBLE_SEGMENTS = 5;
  var MAX_VISIBLE_SEGMENTS = 12;
  var DEFAULT_TABTRAIL_TRIGGER = {
    modifier: "alt",
    withShift: false,
    kind: "key",
    keyCode: "KeyH",
    mouseButton: 1
  };
  var DEFAULT_TABTRAIL_SETTINGS = {
    trigger: DEFAULT_TABTRAIL_TRIGGER,
    overlayPosition: null,
    maxVisibleSegments: 8
  };
  function normalizeModifierKey(value, fallback) {
    return TABTRAIL_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function isValidTriggerKeyCode(value) {
    return typeof value === "string" && TRIGGER_KEY_CODE_PATTERN.test(value);
  }
  function isValidTriggerMouseButton(value) {
    return typeof value === "number" && TRIGGER_MOUSE_BUTTONS.includes(value);
  }
  function normalizeFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeTabTrailTrigger(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABTRAIL_TRIGGER };
    }
    const trigger = value;
    const keyCode = isValidTriggerKeyCode(trigger.keyCode) ? trigger.keyCode : DEFAULT_TABTRAIL_TRIGGER.keyCode;
    const mouseButton = isValidTriggerMouseButton(trigger.mouseButton) ? trigger.mouseButton : DEFAULT_TABTRAIL_TRIGGER.mouseButton;
    return {
      modifier: normalizeModifierKey(trigger.modifier, DEFAULT_TABTRAIL_TRIGGER.modifier),
      withShift: normalizeFlag(trigger.withShift, DEFAULT_TABTRAIL_TRIGGER.withShift),
      kind: trigger.kind === "mouse" ? "mouse" : "key",
      keyCode,
      mouseButton
    };
  }
  function normalizeOverlayPosition(value) {
    if (typeof value !== "object" || value === null) return null;
    const position = value;
    const x = Number(position.xPercent);
    const y = Number(position.yPercent);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return {
      xPercent: Math.min(Math.max(x, 0), 100),
      yPercent: Math.min(Math.max(y, 0), 100)
    };
  }
  function normalizeMaxVisibleSegments(value) {
    const numeric = Number(value);
    if (!Number.isInteger(numeric)) return DEFAULT_TABTRAIL_SETTINGS.maxVisibleSegments;
    return Math.min(Math.max(numeric, MIN_VISIBLE_SEGMENTS), MAX_VISIBLE_SEGMENTS);
  }
  function normalizeTabTrailSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_TABTRAIL_SETTINGS, trigger: { ...DEFAULT_TABTRAIL_TRIGGER } };
    }
    const settings = value;
    return {
      trigger: normalizeTabTrailTrigger(settings.trigger),
      overlayPosition: normalizeOverlayPosition(settings.overlayPosition),
      maxVisibleSegments: normalizeMaxVisibleSegments(settings.maxVisibleSegments)
    };
  }
  async function loadTabTrailSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(TABTRAIL_STORAGE_KEYS.settings);
      return normalizeTabTrailSettings(data[TABTRAIL_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_TABTRAIL_SETTINGS, trigger: { ...DEFAULT_TABTRAIL_TRIGGER } };
    }
  }
  async function saveTabTrailSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [TABTRAIL_STORAGE_KEYS.settings]: normalizeTabTrailSettings(settings)
    });
  }

  // src/lib/core/trail/savedTrailCore.ts
  var MAX_SAVED_TRAILS = 50;
  var SAVED_TRAIL_NAME_MAX_LENGTH = 80;
  function normalizeSavedTrailName(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, SAVED_TRAIL_NAME_MAX_LENGTH);
  }
  function savedTrailNameKey(name) {
    return normalizeSavedTrailName(name).toLowerCase();
  }
  function normalizeSavedTrailEntries(value) {
    return normalizeTrailState({
      entries: value,
      cursor: Array.isArray(value) ? value.length - 1 : -1
    }).entries;
  }
  function normalizeSavedTrail(value) {
    if (typeof value !== "object" || value === null) return null;
    const raw = value;
    const name = normalizeSavedTrailName(raw.name);
    if (name === "") return null;
    const id = typeof raw.id === "string" && raw.id !== "" ? raw.id : null;
    if (!id) return null;
    const entries = normalizeSavedTrailEntries(raw.entries);
    if (entries.length === 0) return null;
    const createdAt = typeof raw.createdAt === "number" && Number.isFinite(raw.createdAt) ? raw.createdAt : 0;
    const updatedAt = typeof raw.updatedAt === "number" && Number.isFinite(raw.updatedAt) ? raw.updatedAt : createdAt;
    return { id, name, pinned: raw.pinned === true, createdAt, updatedAt, entries };
  }
  function normalizeSavedTrails(value) {
    if (!Array.isArray(value)) return [];
    const seenIds = /* @__PURE__ */ new Set();
    const seenNames = /* @__PURE__ */ new Set();
    const trails = [];
    for (const item of value) {
      const trail = normalizeSavedTrail(item);
      if (!trail) continue;
      const key = savedTrailNameKey(trail.name);
      if (seenIds.has(trail.id) || seenNames.has(key)) continue;
      seenIds.add(trail.id);
      seenNames.add(key);
      trails.push(trail);
      if (trails.length >= MAX_SAVED_TRAILS) break;
    }
    return trails.sort((a, b) => b.updatedAt - a.updatedAt || b.createdAt - a.createdAt);
  }

  // src/lib/core/trail/trailCore.ts
  var TRAIL_MAX_ENTRIES = 100;
  var MODIFIER_KEYS = ["alt", "ctrl", "super"];
  function matchesToggleTrigger(event, trigger) {
    if (!event.isTrusted) return false;
    if (event.shiftKey !== trigger.withShift) return false;
    const modifierHeld = {
      alt: event.altKey,
      ctrl: event.ctrlKey,
      super: event.metaKey
    };
    for (const modifier of MODIFIER_KEYS) {
      const shouldBeHeld = modifier === trigger.modifier;
      if (modifierHeld[modifier] !== shouldBeHeld) return false;
    }
    if (trigger.kind === "key") {
      return event.type === "keydown" && event.repeat !== true && event.code === trigger.keyCode;
    }
    return event.type === "mousedown" && event.button === trigger.mouseButton;
  }
  var KNOWN_TRANSITIONS = [
    "link",
    "typed",
    "reload",
    "spa",
    "fragment",
    "form",
    "back_forward",
    "other"
  ];
  function normalizeTrailTransition(value) {
    return KNOWN_TRANSITIONS.includes(value) ? value : "other";
  }
  function normalizeTrailState(value) {
    if (typeof value !== "object" || value === null) {
      return { entries: [], cursor: -1 };
    }
    const raw = value;
    if (!Array.isArray(raw.entries)) return { entries: [], cursor: -1 };
    const rawEntries = raw.entries;
    const windowed = rawEntries.slice(-TRAIL_MAX_ENTRIES);
    const droppedFromFront = rawEntries.length - windowed.length;
    const rawCursor = typeof raw.cursor === "number" && Number.isInteger(raw.cursor) ? raw.cursor : rawEntries.length - 1;
    const cursorInWindow = rawCursor - droppedFromFront;
    const entries = [];
    let cursor = -1;
    for (let i = 0; i < windowed.length; i += 1) {
      const item = windowed[i];
      if (typeof item !== "object" || item === null) continue;
      const entry = item;
      if (typeof entry.url !== "string" || entry.url === "") continue;
      if (i <= cursorInWindow) cursor = entries.length;
      entries.push({
        url: entry.url,
        title: typeof entry.title === "string" ? entry.title : "",
        favIconUrl: typeof entry.favIconUrl === "string" ? entry.favIconUrl : "",
        timestamp: typeof entry.timestamp === "number" && Number.isFinite(entry.timestamp) ? entry.timestamp : 0,
        transition: normalizeTrailTransition(entry.transition),
        redirected: entry.redirected === true,
        historyBacked: entry.historyBacked !== false
      });
    }
    if (entries.length === 0) return { entries: [], cursor: -1 };
    if (cursor === -1) cursor = 0;
    return { entries, cursor };
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function isReceiverUnavailableError(error) {
    const message = error instanceof Error ? error.message : String(error);
    const lowered = message.toLowerCase();
    return lowered.includes("receiving end does not exist") || lowered.includes("could not establish connection");
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
        if (!isReceiverUnavailableError(error)) throw error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/tabtrailApi.ts
  async function toggleTrailOverlay() {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_TOGGLE_OVERLAY" });
  }
  async function jumpToTrailEntry(index, tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_JUMP", index, tabId });
  }
  async function openTrailEntryInNewTab(index, tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_OPEN_IN_NEW_TAB", index, tabId });
  }
  async function openTrailEntryInNewWindow(index, tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_OPEN_IN_NEW_WINDOW", index, tabId });
  }
  async function reportTrailOverlayState(open) {
    await sendRuntimeMessage({ type: "TRAIL_OVERLAY_STATE", open });
  }
  async function openTabTrailOptions() {
    return sendRuntimeMessageWithRetry({ type: "TABTRAIL_OPEN_OPTIONS" });
  }
  async function openSavedTrail(path, mode) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_OPEN",
      path,
      mode
    });
  }
  async function saveNamedTrail(path, name) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_SAVE",
      path,
      name
    });
  }
  async function renameNamedTrail(id, name) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_RENAME",
      id,
      name
    });
  }
  async function duplicateNamedTrail(id) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_DUPLICATE",
      id
    });
  }
  async function replaceNamedTrail(id, path, expectedPath) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_REPLACE",
      id,
      path,
      expectedPath
    });
  }
  async function setNamedTrailPinned(id, pinned) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_SET_PINNED",
      id,
      pinned
    });
  }
  async function deleteNamedTrail(id) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_DELETE",
      id
    });
  }
  async function restoreNamedTrail(trail) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_RESTORE",
      trail
    });
  }

  // src/lib/ui/overlayFrame/overlayFrameController.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/adapters/runtime/savedTrailsClient.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/adapters/storage/savedTrailsStore.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var mutationTail = Promise.resolve();
  async function loadSavedTrails() {
    const data = await import_webextension_polyfill3.default.storage.local.get(TABTRAIL_STORAGE_KEYS.savedTrails);
    return normalizeSavedTrails(data[TABTRAIL_STORAGE_KEYS.savedTrails]);
  }

  // src/lib/adapters/runtime/savedTrailsClient.ts
  function subscribeToSavedTrails(onChanged) {
    const storageChanged = (changes, areaName) => {
      if (areaName !== "local") return;
      const savedChange = changes[TABTRAIL_STORAGE_KEYS.savedTrails];
      if (!savedChange) return;
      onChanged(normalizeSavedTrails(savedChange.newValue));
    };
    import_webextension_polyfill4.default.storage.onChanged.addListener(storageChanged);
    return () => import_webextension_polyfill4.default.storage.onChanged.removeListener(storageChanged);
  }
  var browserSavedTrailsClient = {
    load: loadSavedTrails,
    subscribe: subscribeToSavedTrails,
    open: openSavedTrail,
    save: saveNamedTrail,
    rename: renameNamedTrail,
    duplicate: duplicateNamedTrail,
    replace: replaceNamedTrail,
    setPinned: setNamedTrailPinned,
    delete: deleteNamedTrail,
    restore: restoreNamedTrail
  };

  // src/lib/common/contracts/overlayFrame.ts
  var OVERLAY_FRAME_PROTOCOL_VERSION = 1;
  var OVERLAY_FRAME_MAX_SURFACES = 32;
  var MAX_TRAIL_ENTRIES_ON_WIRE = 100;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function hasOnlyKeys(value, required, optional = []) {
    const keys = Object.keys(value);
    if (!required.every((key) => Object.prototype.hasOwnProperty.call(value, key))) return false;
    const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
    return keys.every((key) => allowed.has(key));
  }
  function isFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value);
  }
  function isNonNegativeSafeInteger(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  }
  function isEmptyParams(value) {
    return isRecord(value) && Object.keys(value).length === 0;
  }
  function isOverlayPosition(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["xPercent", "yPercent"])) return false;
    return isFiniteNumber(value.xPercent) && value.xPercent >= 0 && value.xPercent <= 100 && isFiniteNumber(value.yPercent) && value.yPercent >= 0 && value.yPercent <= 100;
  }
  var TRAIL_TRANSITIONS = /* @__PURE__ */ new Set([
    "link",
    "typed",
    "reload",
    "spa",
    "fragment",
    "form",
    "back_forward",
    "other"
  ]);
  function isTrailEntry(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, [
      "url",
      "title",
      "favIconUrl",
      "timestamp",
      "transition",
      "redirected",
      "historyBacked"
    ])) return false;
    return typeof value.url === "string" && value.url.length > 0 && typeof value.title === "string" && typeof value.favIconUrl === "string" && isFiniteNumber(value.timestamp) && typeof value.transition === "string" && TRAIL_TRANSITIONS.has(value.transition) && typeof value.redirected === "boolean" && typeof value.historyBacked === "boolean";
  }
  function isTrailEntries(value) {
    return Array.isArray(value) && value.length <= MAX_TRAIL_ENTRIES_ON_WIRE && value.every(isTrailEntry);
  }
  function isSavedTrail(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["id", "name", "pinned", "createdAt", "updatedAt", "entries"])) return false;
    return typeof value.id === "string" && value.id.length > 0 && typeof value.name === "string" && value.name.length > 0 && typeof value.pinned === "boolean" && isFiniteNumber(value.createdAt) && isFiniteNumber(value.updatedAt) && isTrailEntries(value.entries) && value.entries.length > 0;
  }
  function isSurfaceRect(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["x", "y", "width", "height"])) return false;
    return isFiniteNumber(value.x) && isFiniteNumber(value.y) && isFiniteNumber(value.width) && isFiniteNumber(value.height) && value.width > 0 && value.height > 0;
  }
  function isBaseProtocolMessage(value) {
    return isRecord(value) && typeof value.type === "string" && value.version === OVERLAY_FRAME_PROTOCOL_VERSION;
  }
  function isRpcParams(method, params) {
    if (!isRecord(params)) return false;
    switch (method) {
      case "LIVE_JUMP":
      case "LIVE_OPEN_NEW_TAB":
      case "LIVE_OPEN_NEW_WINDOW":
        return hasOnlyKeys(params, ["index"]) && isNonNegativeSafeInteger(params.index);
      case "LIVE_OPEN_OPTIONS":
      case "LIVE_CLOSE":
      case "SAVED_LOAD":
        return isEmptyParams(params);
      case "LIVE_SET_POSITION":
        return hasOnlyKeys(params, ["position"]) && isOverlayPosition(params.position);
      case "SAVED_OPEN":
        return hasOnlyKeys(params, ["path", "mode"]) && isTrailEntries(params.path) && params.path.length > 0 && (params.mode === "current" || params.mode === "new");
      case "SAVED_SAVE":
        return hasOnlyKeys(params, ["path", "name"]) && isTrailEntries(params.path) && params.path.length > 0 && typeof params.name === "string";
      case "SAVED_RENAME":
        return hasOnlyKeys(params, ["id", "name"]) && typeof params.id === "string" && typeof params.name === "string";
      case "SAVED_DUPLICATE":
      case "SAVED_DELETE":
        return hasOnlyKeys(params, ["id"]) && typeof params.id === "string";
      case "SAVED_REPLACE":
        return hasOnlyKeys(params, ["id", "path"], ["expectedPath"]) && typeof params.id === "string" && isTrailEntries(params.path) && params.path.length > 0 && (params.expectedPath === void 0 || isTrailEntries(params.expectedPath));
      case "SAVED_SET_PINNED":
        return hasOnlyKeys(params, ["id", "pinned"]) && typeof params.id === "string" && typeof params.pinned === "boolean";
      case "SAVED_RESTORE":
        return hasOnlyKeys(params, ["trail"]) && isSavedTrail(params.trail);
    }
  }
  function isRpcMethod(value) {
    return typeof value === "string" && [
      "LIVE_JUMP",
      "LIVE_OPEN_NEW_TAB",
      "LIVE_OPEN_NEW_WINDOW",
      "LIVE_OPEN_OPTIONS",
      "LIVE_CLOSE",
      "LIVE_SET_POSITION",
      "SAVED_LOAD",
      "SAVED_OPEN",
      "SAVED_SAVE",
      "SAVED_RENAME",
      "SAVED_DUPLICATE",
      "SAVED_REPLACE",
      "SAVED_SET_PINNED",
      "SAVED_DELETE",
      "SAVED_RESTORE"
    ].includes(value);
  }
  function isOverlayRpcRequest(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["requestId", "method", "params"])) return false;
    return isNonNegativeSafeInteger(value.requestId) && isRpcMethod(value.method) && isRpcParams(value.method, value.params);
  }
  function isOverlayFrameToHostMessage(value) {
    if (!isBaseProtocolMessage(value)) return false;
    switch (value.type) {
      case "FRAME_READY":
        return hasOnlyKeys(value, ["type", "version"]);
      case "FRAME_RPC_REQUEST":
        return hasOnlyKeys(value, ["type", "version", "request"]) && isOverlayRpcRequest(value.request);
      case "FRAME_SURFACES_UPDATED":
        return hasOnlyKeys(value, [
          "type",
          "version",
          "sequence",
          "viewportWidth",
          "viewportHeight",
          "rects"
        ]) && isNonNegativeSafeInteger(value.sequence) && isFiniteNumber(value.viewportWidth) && value.viewportWidth > 0 && isFiniteNumber(value.viewportHeight) && value.viewportHeight > 0 && Array.isArray(value.rects) && value.rects.length <= OVERLAY_FRAME_MAX_SURFACES && value.rects.every(isSurfaceRect);
      case "FRAME_FOCUS_OWNERSHIP":
        return hasOnlyKeys(value, ["type", "version", "owned"]) && typeof value.owned === "boolean";
      case "FRAME_PONG":
        return hasOnlyKeys(value, ["type", "version", "heartbeatId"]) && isNonNegativeSafeInteger(value.heartbeatId);
      case "FRAME_ERROR":
        return hasOnlyKeys(value, ["type", "version", "reason"]) && typeof value.reason === "string";
      default:
        return false;
    }
  }

  // src/lib/ui/overlayFrame/surfaceGeometry.ts
  var OVERLAY_SURFACE_PADDING_PX = 4;
  var OVERLAY_EMPTY_CLIP_PATH = "inset(50%)";
  var MAX_PADDING_PX = 64;
  function isRecord2(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isFiniteNumber2(value) {
    return typeof value === "number" && Number.isFinite(value);
  }
  function isValidViewport(value) {
    return isRecord2(value) && isFiniteNumber2(value.width) && value.width > 0 && isFiniteNumber2(value.height) && value.height > 0;
  }
  function isValidSurface(value) {
    if (!isRecord2(value)) return false;
    const keys = Object.keys(value);
    if (keys.length !== 4 || !["x", "y", "width", "height"].every((key) => Object.prototype.hasOwnProperty.call(value, key))) return false;
    return isFiniteNumber2(value.x) && isFiniteNumber2(value.y) && isFiniteNumber2(value.width) && value.width > 0 && isFiniteNumber2(value.height) && value.height > 0;
  }
  function clamp(value, minimum, maximum) {
    return Math.min(Math.max(value, minimum), maximum);
  }
  function clampSurface(surface, viewport, paddingPx) {
    const left = clamp(surface.x - paddingPx, 0, viewport.width);
    const top = clamp(surface.y - paddingPx, 0, viewport.height);
    const right = clamp(surface.x + surface.width + paddingPx, 0, viewport.width);
    const bottom = clamp(surface.y + surface.height + paddingPx, 0, viewport.height);
    if (right <= left || bottom <= top) return null;
    return { x: left, y: top, width: right - left, height: bottom - top };
  }
  function formatCoordinate(value) {
    const rounded = Math.round(value * 1e3) / 1e3;
    return String(Object.is(rounded, -0) ? 0 : rounded);
  }
  function buildOverlaySurfaceClipPath(rects) {
    if (rects.length === 0) return OVERLAY_EMPTY_CLIP_PATH;
    const subpaths = rects.map((rect) => {
      const left = formatCoordinate(rect.x);
      const top = formatCoordinate(rect.y);
      const right = formatCoordinate(rect.x + rect.width);
      const bottom = formatCoordinate(rect.y + rect.height);
      return `M ${left} ${top} H ${right} V ${bottom} H ${left} Z`;
    });
    return `path("${subpaths.join(" ")}")`;
  }
  function isNewerSurfaceSequence(sequence, lastSequence) {
    if (typeof sequence !== "number" || !Number.isSafeInteger(sequence) || sequence < 0) return false;
    return lastSequence === null || sequence > lastSequence;
  }
  function validateSurfaceUpdate(update, viewport, lastSequence, options = {}) {
    if (!isRecord2(update) || !Array.isArray(update.rects) || !isFiniteNumber2(update.viewportWidth) || update.viewportWidth <= 0 || !isFiniteNumber2(update.viewportHeight) || update.viewportHeight <= 0) {
      return { ok: false, reason: "invalid-update" };
    }
    if (typeof update.sequence !== "number" || !Number.isSafeInteger(update.sequence) || update.sequence < 0) {
      return { ok: false, reason: "invalid-sequence" };
    }
    if (!isNewerSurfaceSequence(update.sequence, lastSequence)) {
      return { ok: false, reason: "stale-sequence" };
    }
    if (!isValidViewport(viewport)) {
      return { ok: false, reason: "invalid-viewport" };
    }
    if (update.viewportWidth !== viewport.width || update.viewportHeight !== viewport.height) {
      return { ok: false, reason: "stale-viewport" };
    }
    if (update.rects.length > OVERLAY_FRAME_MAX_SURFACES) {
      return { ok: false, reason: "too-many-surfaces" };
    }
    const paddingPx = options.paddingPx ?? OVERLAY_SURFACE_PADDING_PX;
    if (!isFiniteNumber2(paddingPx) || paddingPx < 0 || paddingPx > MAX_PADDING_PX) {
      return { ok: false, reason: "invalid-padding" };
    }
    const rects = [];
    for (const surface of update.rects) {
      if (!isValidSurface(surface)) return { ok: false, reason: "invalid-surface" };
      const normalized = clampSurface(surface, viewport, paddingPx);
      if (normalized) rects.push(normalized);
    }
    return {
      ok: true,
      value: {
        sequence: update.sequence,
        rects,
        clipPath: buildOverlaySurfaceClipPath(rects)
      }
    };
  }

  // src/lib/ui/overlayFrame/overlayFrameController.ts
  var FRAME_HOST_ID = "tabtrail-isolated-overlay-host";
  var FRAME_DOCUMENT_PATH = "overlayFrame/overlayFrame.html";
  var STARTUP_TIMEOUT_MS = 3e3;
  var HEARTBEAT_INTERVAL_MS = 2e3;
  var HEARTBEAT_TIMEOUT_MS = 5e3;
  var VIEWPORT_TOLERANCE_PX = 1;
  function randomNonce() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function setImportantStyle(element, property, value) {
    element.style.setProperty(property, value, "important");
  }
  function createFrameHost(frameUrl) {
    document.getElementById(FRAME_HOST_ID)?.remove();
    const host = document.createElement("div");
    host.id = FRAME_HOST_ID;
    setImportantStyle(host, "all", "initial");
    setImportantStyle(host, "position", "fixed");
    setImportantStyle(host, "inset", "0");
    setImportantStyle(host, "width", "100vw");
    setImportantStyle(host, "height", "100vh");
    setImportantStyle(host, "z-index", "2147483647");
    setImportantStyle(host, "pointer-events", "none");
    setImportantStyle(host, "overflow", "hidden");
    setImportantStyle(host, "background", "transparent");
    setImportantStyle(host, "border", "0");
    setImportantStyle(host, "margin", "0");
    setImportantStyle(host, "padding", "0");
    setImportantStyle(host, "color-scheme", "dark");
    const shadow = host.attachShadow({ mode: "closed" });
    const frame = document.createElement("iframe");
    frame.title = "TabTrail navigation overlay";
    frame.tabIndex = -1;
    frame.setAttribute("aria-label", "TabTrail navigation overlay");
    setImportantStyle(frame, "position", "fixed");
    setImportantStyle(frame, "inset", "0");
    setImportantStyle(frame, "width", "100vw");
    setImportantStyle(frame, "height", "100vh");
    setImportantStyle(frame, "border", "0");
    setImportantStyle(frame, "margin", "0");
    setImportantStyle(frame, "padding", "0");
    setImportantStyle(frame, "background", "transparent");
    setImportantStyle(frame, "pointer-events", "none");
    setImportantStyle(frame, "visibility", "hidden");
    setImportantStyle(frame, "clip-path", OVERLAY_EMPTY_CLIP_PATH);
    setImportantStyle(frame, "overscroll-behavior", "none");
    frame.src = frameUrl;
    shadow.appendChild(frame);
    (document.documentElement || document.body).appendChild(host);
    const popoverHost = host;
    if (typeof popoverHost.showPopover === "function") {
      try {
        popoverHost.popover = "manual";
        popoverHost.showPopover();
      } catch (_) {
        popoverHost.removeAttribute("popover");
      }
    }
    return { host, shadow, frame };
  }
  function activeElementBelongsToFrame(session) {
    return session.shadow.activeElement === session.frame || document.activeElement === session.host;
  }
  function restorablePageElement(element) {
    return element !== null && element.isConnected && !element.matches(":disabled") && element.closest("[inert]") === null;
  }
  function actionFailure(reason) {
    return { ok: false, reason };
  }
  function createOverlayFrameController(options) {
    let session = null;
    let nextGeneration = 0;
    const postToFrame = (current, message) => {
      if (session !== current || !current.port) return;
      current.port.postMessage(message);
    };
    const settleOpened = (current, opened) => {
      if (current.settled) return;
      current.settled = true;
      current.resolveOpened(opened);
    };
    const teardown = (current, reason = "Overlay closed") => {
      if (session !== current) return;
      const restoreTarget = current.lastPageFocus;
      const restoreFocus = activeElementBelongsToFrame(current);
      session = null;
      settleOpened(current, false);
      window.clearTimeout(current.startupTimer);
      window.clearInterval(current.heartbeatTimer);
      current.cleanupPageListeners();
      current.unsubscribeSavedTrails?.();
      current.unsubscribeSavedTrails = null;
      if (current.port) {
        try {
          current.port.postMessage({
            type: "HOST_SHUTDOWN",
            version: OVERLAY_FRAME_PROTOCOL_VERSION,
            reason
          });
        } catch (_) {
        }
        current.port.close();
        current.port = null;
      }
      current.host.remove();
      if (current.reportedOpen) {
        void reportTrailOverlayState(false).catch(() => {
        });
      }
      if (restoreFocus && restorablePageElement(restoreTarget)) {
        requestAnimationFrame(() => {
          if (!restorablePageElement(restoreTarget) || document.activeElement !== document.body) return;
          restoreTarget.focus({ preventScroll: true });
        });
      }
    };
    const closeCurrent = (reason) => {
      if (session) teardown(session, reason);
    };
    const normalizeAction = async (operation, fallback) => {
      try {
        return await operation();
      } catch (_) {
        return actionFailure(fallback);
      }
    };
    const rpcResponse = (request, result) => ({
      requestId: request.requestId,
      method: request.method,
      result
    });
    const runRpc = async (request, operation, fallback) => {
      try {
        return rpcResponse(request, await operation());
      } catch (_) {
        return rpcResponse(request, actionFailure(fallback));
      }
    };
    const executeRpc = async (request) => {
      switch (request.method) {
        case "LIVE_JUMP":
          return runRpc(
            request,
            () => normalizeAction(
              () => jumpToTrailEntry(request.params.index),
              "Could not navigate to that trail entry"
            ),
            "Could not navigate to that trail entry"
          );
        case "LIVE_OPEN_NEW_TAB":
          return runRpc(
            request,
            () => normalizeAction(
              () => openTrailEntryInNewTab(request.params.index),
              "Could not open that entry in a new tab"
            ),
            "Could not open that entry in a new tab"
          );
        case "LIVE_OPEN_NEW_WINDOW":
          return runRpc(
            request,
            () => normalizeAction(
              () => openTrailEntryInNewWindow(request.params.index),
              "Could not open that entry in a new window"
            ),
            "Could not open that entry in a new window"
          );
        case "LIVE_OPEN_OPTIONS":
          return runRpc(
            request,
            () => normalizeAction(openTabTrailOptions, "Settings unavailable"),
            "Settings unavailable"
          );
        case "LIVE_CLOSE":
          return rpcResponse(request, { ok: true });
        case "LIVE_SET_POSITION":
          return runRpc(
            request,
            async () => {
              await options.onPositionChange(request.params.position);
              return { ok: true };
            },
            "Could not save overlay position"
          );
        case "SAVED_LOAD":
          return runRpc(
            request,
            async () => ({ ok: true, trails: await browserSavedTrailsClient.load() }),
            "Could not load saved trails"
          );
        case "SAVED_OPEN":
          return runRpc(
            request,
            () => normalizeAction(
              () => browserSavedTrailsClient.open(request.params.path, request.params.mode),
              "Could not open saved trail"
            ),
            "Could not open saved trail"
          );
        case "SAVED_SAVE":
          return runRpc(
            request,
            () => browserSavedTrailsClient.save(request.params.path, request.params.name),
            "Could not save trail"
          );
        case "SAVED_RENAME":
          return runRpc(
            request,
            () => browserSavedTrailsClient.rename(request.params.id, request.params.name),
            "Could not rename trail"
          );
        case "SAVED_DUPLICATE":
          return runRpc(
            request,
            () => browserSavedTrailsClient.duplicate(request.params.id),
            "Could not duplicate trail"
          );
        case "SAVED_REPLACE":
          return runRpc(
            request,
            () => browserSavedTrailsClient.replace(
              request.params.id,
              request.params.path,
              request.params.expectedPath
            ),
            "Could not update trail"
          );
        case "SAVED_SET_PINNED":
          return runRpc(
            request,
            () => browserSavedTrailsClient.setPinned(request.params.id, request.params.pinned),
            "Could not change pinned state"
          );
        case "SAVED_DELETE":
          return runRpc(
            request,
            () => browserSavedTrailsClient.delete(request.params.id),
            "Could not remove trail"
          );
        case "SAVED_RESTORE":
          return runRpc(
            request,
            () => browserSavedTrailsClient.restore(request.params.trail),
            "Could not restore trail"
          );
      }
    };
    const installPageListeners = (current) => {
      const onPointerDown = () => {
        if (session !== current) return;
        current.focusOwned = false;
        postToFrame(current, {
          type: "HOST_FOCUS_RELEASED",
          version: OVERLAY_FRAME_PROTOCOL_VERSION
        });
        postToFrame(current, {
          type: "HOST_DISMISS_TRANSIENTS",
          version: OVERLAY_FRAME_PROTOCOL_VERSION
        });
      };
      const onFocusIn = (event) => {
        if (session !== current) return;
        if (event.target instanceof HTMLElement && event.target !== current.host) {
          current.lastPageFocus = event.target;
        }
        if (!current.focusOwned || !document.hasFocus()) return;
        requestAnimationFrame(() => {
          if (session !== current || !current.focusOwned || !document.hasFocus()) return;
          current.frame.focus({ preventScroll: true });
        });
      };
      const onKeyDown = (event) => {
        if (session !== current || event.key !== "Escape") return;
        event.preventDefault();
        event.stopImmediatePropagation();
        postToFrame(current, {
          type: "HOST_ESCAPE",
          version: OVERLAY_FRAME_PROTOCOL_VERSION
        });
      };
      const invalidateGeometry = () => {
        if (session !== current) return;
        setImportantStyle(current.frame, "visibility", "hidden");
        setImportantStyle(current.frame, "pointer-events", "none");
        setImportantStyle(current.frame, "clip-path", OVERLAY_EMPTY_CLIP_PATH);
        postToFrame(current, {
          type: "HOST_REQUEST_SURFACES",
          version: OVERLAY_FRAME_PROTOCOL_VERSION
        });
      };
      window.addEventListener("pointerdown", onPointerDown, true);
      window.addEventListener("focusin", onFocusIn, true);
      window.addEventListener("keydown", onKeyDown, true);
      window.addEventListener("resize", invalidateGeometry);
      window.visualViewport?.addEventListener("resize", invalidateGeometry);
      return () => {
        window.removeEventListener("pointerdown", onPointerDown, true);
        window.removeEventListener("focusin", onFocusIn, true);
        window.removeEventListener("keydown", onKeyDown, true);
        window.removeEventListener("resize", invalidateGeometry);
        window.visualViewport?.removeEventListener("resize", invalidateGeometry);
      };
    };
    const receiveFrameMessage = (current, received) => {
      if (session !== current) return;
      if (!isOverlayFrameToHostMessage(received)) {
        teardown(current, "Invalid overlay frame message");
        return;
      }
      const message = received;
      switch (message.type) {
        case "FRAME_READY":
          if (!current.claimed || current.ready) {
            teardown(current, "Unexpected overlay frame readiness");
            return;
          }
          current.ready = true;
          postToFrame(current, {
            type: "HOST_INIT",
            version: OVERLAY_FRAME_PROTOCOL_VERSION,
            state: current.state,
            settings: current.settings
          });
          return;
        case "FRAME_RPC_REQUEST":
          if (message.request.requestId <= current.lastRequestId) {
            teardown(current, "Duplicate or stale overlay request");
            return;
          }
          current.lastRequestId = message.request.requestId;
          void executeRpc(message.request).then((response) => {
            if (session !== current) return;
            postToFrame(current, {
              type: "HOST_RPC_RESPONSE",
              version: OVERLAY_FRAME_PROTOCOL_VERSION,
              response
            });
            if (message.request.method === "LIVE_CLOSE") {
              queueMicrotask(() => teardown(current));
            }
          });
          return;
        case "FRAME_SURFACES_UPDATED": {
          const frameWidth = current.frame.clientWidth || window.innerWidth;
          const frameHeight = current.frame.clientHeight || window.innerHeight;
          if (Math.abs(message.viewportWidth - frameWidth) > VIEWPORT_TOLERANCE_PX || Math.abs(message.viewportHeight - frameHeight) > VIEWPORT_TOLERANCE_PX) {
            setImportantStyle(current.frame, "visibility", "hidden");
            setImportantStyle(current.frame, "pointer-events", "none");
            return;
          }
          const validated = validateSurfaceUpdate(
            {
              sequence: message.sequence,
              viewportWidth: frameWidth,
              viewportHeight: frameHeight,
              rects: message.rects
            },
            { width: frameWidth, height: frameHeight },
            current.lastSequence
          );
          if (!validated.ok) {
            teardown(current, `Invalid overlay geometry: ${validated.reason}`);
            return;
          }
          current.lastSequence = validated.value.sequence;
          if (validated.value.rects.length === 0) {
            setImportantStyle(current.frame, "visibility", "hidden");
            setImportantStyle(current.frame, "pointer-events", "none");
            setImportantStyle(current.frame, "clip-path", OVERLAY_EMPTY_CLIP_PATH);
            return;
          }
          if (typeof CSS === "undefined" || typeof CSS.supports !== "function" || !CSS.supports("clip-path", validated.value.clipPath)) {
            teardown(current, "Browser does not support isolated overlay hit testing");
            return;
          }
          setImportantStyle(current.frame, "clip-path", validated.value.clipPath);
          setImportantStyle(current.frame, "visibility", "visible");
          setImportantStyle(current.frame, "pointer-events", "auto");
          if (!current.settled) {
            window.clearTimeout(current.startupTimer);
            settleOpened(current, true);
          }
          return;
        }
        case "FRAME_FOCUS_OWNERSHIP":
          current.focusOwned = message.owned;
          if (message.owned && document.hasFocus()) {
            current.frame.focus({ preventScroll: true });
          }
          return;
        case "FRAME_PONG":
          if (message.heartbeatId === current.heartbeatId) {
            current.lastPongAt = performance.now();
          }
          return;
        case "FRAME_ERROR":
          teardown(current, message.reason || "Overlay frame error");
          return;
      }
    };
    const open = (state, settings) => {
      if (session) return session.opened;
      const frameUrl = import_webextension_polyfill5.default.runtime.getURL(FRAME_DOCUMENT_PATH);
      const { host, shadow, frame } = createFrameHost(frameUrl);
      const active = document.activeElement;
      let resolveOpened = (_opened) => {
      };
      const opened = new Promise((resolve) => {
        resolveOpened = resolve;
      });
      const current = {
        generation: ++nextGeneration,
        nonce: randomNonce(),
        host,
        shadow,
        frame,
        state,
        settings,
        port: null,
        ready: false,
        claimed: false,
        connected: false,
        focusOwned: false,
        lastRequestId: 0,
        lastSequence: null,
        lastPongAt: performance.now(),
        heartbeatId: 0,
        startupTimer: 0,
        heartbeatTimer: 0,
        unsubscribeSavedTrails: null,
        reportedOpen: false,
        settled: false,
        resolveOpened,
        opened,
        lastPageFocus: active instanceof HTMLElement ? active : null,
        cleanupPageListeners: () => {
        }
      };
      session = current;
      current.reportedOpen = true;
      void reportTrailOverlayState(true).catch(() => {
      });
      current.cleanupPageListeners = installPageListeners(current);
      current.unsubscribeSavedTrails = browserSavedTrailsClient.subscribe((trails) => {
        postToFrame(current, {
          type: "HOST_SAVED_TRAILS_UPDATED",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          trails
        });
      });
      frame.addEventListener("error", () => teardown(current, "Overlay frame failed to load"), {
        once: true
      });
      frame.addEventListener("load", () => {
        if (session !== current || current.connected || !frame.contentWindow) {
          if (session === current) teardown(current, "Overlay frame reloaded unexpectedly");
          return;
        }
        current.connected = true;
        const channel = new MessageChannel();
        current.port = channel.port1;
        current.port.addEventListener("message", (event) => {
          receiveFrameMessage(current, event.data);
        });
        current.port.addEventListener("messageerror", () => {
          teardown(current, "Overlay frame message could not be decoded");
        });
        current.port.start();
        const connect = {
          type: "TABTRAIL_OVERLAY_CONNECT",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          nonce: current.nonce
        };
        try {
          frame.contentWindow.postMessage(connect, new URL(frame.src).origin, [channel.port2]);
        } catch (_) {
          teardown(current, "Overlay frame connection failed");
        }
      });
      current.startupTimer = window.setTimeout(() => {
        teardown(current, "Overlay frame startup timed out");
      }, STARTUP_TIMEOUT_MS);
      current.heartbeatTimer = window.setInterval(() => {
        if (session !== current || !current.ready) return;
        if (performance.now() - current.lastPongAt > HEARTBEAT_TIMEOUT_MS) {
          teardown(current, "Overlay frame stopped responding");
          return;
        }
        current.heartbeatId += 1;
        postToFrame(current, {
          type: "HOST_PING",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          heartbeatId: current.heartbeatId
        });
      }, HEARTBEAT_INTERVAL_MS);
      return opened;
    };
    return {
      isOpen: () => session !== null,
      open,
      close: closeCurrent,
      updateTrail: (state) => {
        if (!session) return;
        session.state = state;
        postToFrame(session, {
          type: "HOST_TRAIL_UPDATED",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          state
        });
      },
      updateSettings: (settings) => {
        if (!session) return;
        session.settings = settings;
        postToFrame(session, {
          type: "HOST_SETTINGS_UPDATED",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          settings
        });
      },
      authorizeClaim: (nonce) => {
        if (!session || session.nonce !== nonce || session.claimed || !session.connected) {
          return actionFailure("Overlay frame authentication failed");
        }
        session.claimed = true;
        return { ok: true };
      }
    };
  }

  // src/lib/appInit/appInit.ts
  var MOUSE_CHORD_SWALLOW_WINDOW_MS = 600;
  function isTopFrame() {
    try {
      return window.self === window.top;
    } catch (_) {
      return false;
    }
  }
  function initApp() {
    window.__tabtrailCleanup?.();
    let settings = normalizeTabTrailSettings(null);
    let disposed = false;
    const topFrame = isTopFrame();
    let swallowMouseUntil = 0;
    let swallowedButton = -1;
    let overlayController = null;
    void loadTabTrailSettings().then((loaded) => {
      if (disposed) return;
      settings = loaded;
      overlayController?.updateSettings(settings);
    });
    function toTriggerEvent(event) {
      if (event instanceof KeyboardEvent) {
        return {
          type: "keydown",
          code: event.code,
          altKey: event.altKey,
          ctrlKey: event.ctrlKey,
          metaKey: event.metaKey,
          shiftKey: event.shiftKey,
          repeat: event.repeat,
          isTrusted: event.isTrusted
        };
      }
      return {
        type: "mousedown",
        button: event.button,
        altKey: event.altKey,
        ctrlKey: event.ctrlKey,
        metaKey: event.metaKey,
        shiftKey: event.shiftKey,
        isTrusted: event.isTrusted
      };
    }
    function fireToggle() {
      void toggleTrailOverlay().catch(() => {
      });
    }
    const keydownHandler = (event) => {
      if (!matchesToggleTrigger(toTriggerEvent(event), settings.trigger)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      fireToggle();
    };
    const mousedownHandler = (event) => {
      if (!matchesToggleTrigger(toTriggerEvent(event), settings.trigger)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      swallowMouseUntil = performance.now() + MOUSE_CHORD_SWALLOW_WINDOW_MS;
      swallowedButton = event.button;
      fireToggle();
    };
    const mouseFollowUpHandler = (event) => {
      if (performance.now() > swallowMouseUntil) return;
      const relevant = event.type === "contextmenu" ? swallowedButton === 2 : event.button === swallowedButton;
      if (!relevant) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    };
    window.addEventListener("keydown", keydownHandler, true);
    window.addEventListener("mousedown", mousedownHandler, true);
    window.addEventListener("auxclick", mouseFollowUpHandler, true);
    window.addEventListener("click", mouseFollowUpHandler, true);
    window.addEventListener("contextmenu", mouseFollowUpHandler, true);
    const storageChangedHandler = (changes, areaName) => {
      if (areaName !== "local" || !changes[TABTRAIL_STORAGE_KEYS.settings]) return;
      settings = normalizeTabTrailSettings(changes[TABTRAIL_STORAGE_KEYS.settings].newValue);
      overlayController?.updateSettings(settings);
    };
    import_webextension_polyfill6.default.storage.onChanged.addListener(storageChangedHandler);
    let messageHandler = null;
    let pageHideHandler = null;
    let visibilityChangeHandler = null;
    if (topFrame) {
      overlayController = createOverlayFrameController({
        onPositionChange: async (position) => {
          settings = { ...settings, overlayPosition: position };
          overlayController?.updateSettings(settings);
          await saveTabTrailSettings(settings);
        }
      });
      const closeOpenOverlay = () => {
        overlayController?.close();
      };
      messageHandler = (message) => {
        if (typeof message !== "object" || message === null) return void 0;
        const typed = message;
        switch (typed.type) {
          case "TABTRAIL_PING":
            return Promise.resolve({ ok: true });
          case "OVERLAY_FRAME_CHALLENGE":
            return Promise.resolve(overlayController?.authorizeClaim(typed.nonce) ?? {
              ok: false,
              reason: "Overlay frame unavailable"
            });
          case "TRAIL_SHOW":
            if (overlayController?.isOpen()) {
              overlayController.close("Overlay toggled closed");
              return Promise.resolve({ ok: true });
            }
            return (overlayController?.open(typed.state, settings) ?? Promise.resolve(false)).then((opened) => opened ? { ok: true } : { ok: false, reason: "Overlay unavailable on this page" });
          case "TRAIL_UPDATED":
            overlayController?.updateTrail(typed.state);
            return Promise.resolve({ ok: true });
          case "HISTORY_GO":
            try {
              window.history.go(typed.delta);
              return Promise.resolve({ ok: true });
            } catch (_) {
              return Promise.resolve({ ok: false, reason: "history.go failed" });
            }
          default:
            return void 0;
        }
      };
      import_webextension_polyfill6.default.runtime.onMessage.addListener(messageHandler);
      pageHideHandler = closeOpenOverlay;
      visibilityChangeHandler = () => {
        if (document.visibilityState !== "hidden") return;
        closeOpenOverlay();
      };
      window.addEventListener("pagehide", pageHideHandler);
      document.addEventListener("visibilitychange", visibilityChangeHandler);
    }
    window.__tabtrailCleanup = () => {
      disposed = true;
      window.removeEventListener("keydown", keydownHandler, true);
      window.removeEventListener("mousedown", mousedownHandler, true);
      window.removeEventListener("auxclick", mouseFollowUpHandler, true);
      window.removeEventListener("click", mouseFollowUpHandler, true);
      window.removeEventListener("contextmenu", mouseFollowUpHandler, true);
      import_webextension_polyfill6.default.storage.onChanged.removeListener(storageChangedHandler);
      if (messageHandler) import_webextension_polyfill6.default.runtime.onMessage.removeListener(messageHandler);
      if (pageHideHandler) window.removeEventListener("pagehide", pageHideHandler);
      if (visibilityChangeHandler) {
        document.removeEventListener("visibilitychange", visibilityChangeHandler);
      }
      overlayController?.close("Content script stopped");
      overlayController = null;
      delete window.__tabtrailCleanup;
    };
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();
