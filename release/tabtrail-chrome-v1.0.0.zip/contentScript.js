"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/appInit/appInit.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/wayfind.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var WAYFIND_STORAGE_KEYS = {
    settings: "wayfindSettings"
  };
  var WAYFIND_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "super"
  ];
  var TRIGGER_KEY_CODE_PATTERN = /^(?:Key[A-Z]|Digit[0-9])$/;
  var TRIGGER_MOUSE_BUTTONS = [0, 1, 2];
  var MIN_VISIBLE_SEGMENTS = 5;
  var MAX_VISIBLE_SEGMENTS = 12;
  var DEFAULT_WAYFIND_TRIGGER = {
    modifier: "alt",
    withShift: false,
    kind: "key",
    keyCode: "KeyH",
    mouseButton: 1
  };
  var DEFAULT_WAYFIND_SETTINGS = {
    trigger: DEFAULT_WAYFIND_TRIGGER,
    showTransitionArrows: true,
    overlayPosition: null,
    maxVisibleSegments: 8
  };
  function normalizeModifierKey(value, fallback) {
    return WAYFIND_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function isValidTriggerKeyCode(value) {
    return typeof value === "string" && TRIGGER_KEY_CODE_PATTERN.test(value);
  }
  function isValidTriggerMouseButton(value) {
    return typeof value === "number" && TRIGGER_MOUSE_BUTTONS.includes(value);
  }
  function normalizeFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeWayfindTrigger(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_WAYFIND_TRIGGER };
    }
    const trigger = value;
    const keyCode = isValidTriggerKeyCode(trigger.keyCode) ? trigger.keyCode : DEFAULT_WAYFIND_TRIGGER.keyCode;
    const mouseButton = isValidTriggerMouseButton(trigger.mouseButton) ? trigger.mouseButton : DEFAULT_WAYFIND_TRIGGER.mouseButton;
    return {
      modifier: normalizeModifierKey(trigger.modifier, DEFAULT_WAYFIND_TRIGGER.modifier),
      withShift: normalizeFlag(trigger.withShift, DEFAULT_WAYFIND_TRIGGER.withShift),
      kind: trigger.kind === "mouse" ? "mouse" : "key",
      keyCode,
      mouseButton
    };
  }
  function normalizeOverlayPosition(value) {
    if (typeof value !== "object" || value === null) return null;
    const position = value;
    const x = Number(position.xPercent);
    const y = Number(position.yPercent);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return {
      xPercent: Math.min(Math.max(x, 0), 100),
      yPercent: Math.min(Math.max(y, 0), 100)
    };
  }
  function normalizeMaxVisibleSegments(value) {
    const numeric = Number(value);
    if (!Number.isInteger(numeric)) return DEFAULT_WAYFIND_SETTINGS.maxVisibleSegments;
    return Math.min(Math.max(numeric, MIN_VISIBLE_SEGMENTS), MAX_VISIBLE_SEGMENTS);
  }
  function normalizeWayfindSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_WAYFIND_SETTINGS, trigger: { ...DEFAULT_WAYFIND_TRIGGER } };
    }
    const settings = value;
    return {
      trigger: normalizeWayfindTrigger(settings.trigger),
      showTransitionArrows: true,
      overlayPosition: normalizeOverlayPosition(settings.overlayPosition),
      maxVisibleSegments: normalizeMaxVisibleSegments(settings.maxVisibleSegments)
    };
  }
  async function loadWayfindSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(WAYFIND_STORAGE_KEYS.settings);
      return normalizeWayfindSettings(data[WAYFIND_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_WAYFIND_SETTINGS, trigger: { ...DEFAULT_WAYFIND_TRIGGER } };
    }
  }
  async function saveWayfindSettings(settings) {
    await import_webextension_polyfill.default.storage.local.set({
      [WAYFIND_STORAGE_KEYS.settings]: normalizeWayfindSettings(settings)
    });
  }

  // src/lib/core/trail/trailCore.ts
  var MODIFIER_KEYS = ["alt", "ctrl", "super"];
  function matchesToggleTrigger(event, trigger) {
    if (!event.isTrusted) return false;
    if (event.shiftKey !== trigger.withShift) return false;
    const modifierHeld = {
      alt: event.altKey,
      ctrl: event.ctrlKey,
      super: event.metaKey
    };
    for (const modifier of MODIFIER_KEYS) {
      const shouldBeHeld = modifier === trigger.modifier;
      if (modifierHeld[modifier] !== shouldBeHeld) return false;
    }
    if (trigger.kind === "key") {
      return event.type === "keydown" && event.repeat !== true && event.code === trigger.keyCode;
    }
    return event.type === "mousedown" && event.button === trigger.mouseButton;
  }
  function formatTrailTimestamp(timestamp, now) {
    const elapsed = Math.max(0, now - timestamp);
    const seconds = Math.floor(elapsed / 1e3);
    if (seconds < 45) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${Math.max(1, minutes)}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/wayfindApi.ts
  async function toggleTrailOverlay() {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_TOGGLE_OVERLAY" });
  }
  async function jumpToTrailEntry(index, tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_JUMP", index, tabId });
  }
  async function openTrailEntryInNewTab(index, tabId) {
    return sendRuntimeMessage({ type: "TRAIL_OPEN_IN_NEW_TAB", index, tabId });
  }
  async function openTrailEntryInNewWindow(index, tabId) {
    return sendRuntimeMessage({ type: "TRAIL_OPEN_IN_NEW_WINDOW", index, tabId });
  }
  async function reportTrailOverlayState(open) {
    await sendRuntimeMessage({ type: "TRAIL_OVERLAY_STATE", open });
  }
  async function announceTrailContentReady() {
    await sendRuntimeMessage({ type: "TRAIL_CONTENT_READY" });
  }
  async function openWayfindOptions() {
    return sendRuntimeMessageWithRetry({ type: "WAYFIND_OPEN_OPTIONS" });
  }

  // src/lib/ui/panels/breadcrumbTrail/breadcrumbTrail.css
  var breadcrumbTrail_default = '.wf-layer {\n  position: fixed;\n  inset: 0;\n  pointer-events: none;\n  overscroll-behavior: contain;\n}\n\n.wf-bar {\n  pointer-events: auto;\n  position: fixed;\n  transform: translateX(-50%) translateZ(0);\n  width: min(90vw, 390px);\n  max-height: min(82vh, 560px);\n  display: flex;\n  flex-direction: column;\n  overflow: visible;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  font-size: 12px;\n  line-height: 1.35;\n  user-select: none;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  animation: wf-branch-in 0.14s ease-out;\n}\n\n.wf-branch-header {\n  min-height: 42px;\n  display: grid;\n  grid-template-columns: auto minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 10px;\n  background: #252525;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  border-radius: 8px 8px 0 0;\n}\n\n.wf-settings {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  background: var(--ht-color-surface);\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  padding: 0;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-settings:hover {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-accent-soft);\n  border-color: var(--ht-color-accent);\n}\n\n.wf-branch-title {\n  min-width: 0;\n  color: var(--ht-color-text-title);\n  font-size: 11px;\n  font-weight: 700;\n  text-align: center;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-branch-list {\n  min-height: 0;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr);\n  gap: 0;\n  padding: 10px 10px 12px;\n  overflow-x: hidden;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n}\n\n.wf-bar.wf-dragging {\n  cursor: grabbing;\n  opacity: 0.92;\n}\n\n@keyframes wf-branch-in {\n  from { opacity: 0; transform: translateX(-50%) translateY(-6px); }\n  to { opacity: 1; transform: translateX(-50%) translateY(0); }\n}\n\n.wf-grip {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: grab;\n  color: #ffdf8a;\n  background: rgba(254,188,46,0.16);\n  border: 1px solid rgba(254,188,46,0.36);\n  border-radius: 6px;\n  padding: 0;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-grip:hover {\n  color: #fff;\n  background: rgba(254,188,46,0.26);\n  border-color: rgba(254,188,46,0.62);\n}\n\n.wf-bar.wf-dragging .wf-grip {\n  color: #fff;\n  background: rgba(254,188,46,0.34);\n  border-color: rgba(254,188,46,0.74);\n}\n\n.wf-close {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: #ffd6d3;\n  background: rgba(255,95,87,0.14);\n  border: 1px solid rgba(255,95,87,0.3);\n  padding: 0;\n  border-radius: 6px;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-close:hover {\n  color: #fff;\n  background: rgba(255,95,87,0.28);\n  border-color: rgba(255,95,87,0.56);\n}\n\n.wf-empty {\n  color: var(--ht-color-text-muted);\n  padding: 4px 6px;\n  line-height: 1.45;\n}\n\n.wf-branch-row {\n  min-width: 0;\n  position: relative;\n  display: grid;\n  grid-template-columns: 14px minmax(0, 1fr);\n  column-gap: 8px;\n  align-items: start;\n  margin: 2px 0;\n  padding: 7px 8px 7px 6px;\n  border-radius: 7px;\n  cursor: pointer;\n  color: #d6d6d6;\n}\n\n.wf-branch-row:hover {\n  background: var(--ht-color-hover);\n  color: var(--ht-color-text-strong);\n}\n\n.wf-branch-node {\n  width: 7px;\n  height: 7px;\n  margin-top: 6px;\n  border-radius: 999px;\n  background: #8f8f8f;\n  box-shadow: 0 0 0 3px rgba(255,255,255,0.05);\n}\n\n.wf-branch-row-current {\n  color: #f2f7ff;\n  font-weight: 700;\n  background: rgba(10,132,255,0.18);\n  box-shadow: inset 0 0 0 1px rgba(10,132,255,0.3);\n  cursor: default;\n}\n\n.wf-branch-row-current .wf-branch-node {\n  background: #30d158;\n  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);\n}\n\n.wf-branch-row-current .wf-branch-entry-url {\n  color: #aacdff;\n}\n\n.wf-branch-row-previewed {\n  box-shadow: inset 3px 0 0 #ffb340, inset 0 0 0 1px rgba(255,179,64,0.24);\n}\n\n.wf-branch-row-previewed:not(.wf-branch-row-current) {\n  background: rgba(255,179,64,0.1);\n}\n\n.wf-branch-row-previewed .wf-branch-node {\n  background: #ffb340;\n  box-shadow: 0 0 0 3px rgba(255,179,64,0.18);\n}\n\n.wf-branch-row-current.wf-branch-row-previewed .wf-branch-node {\n  background: #30d158;\n  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);\n}\n\n.wf-branch-row-forward {\n  opacity: 0.52;\n}\n\n.wf-branch-entry {\n  min-width: 0;\n  display: grid;\n  gap: 2px;\n}\n\n.wf-branch-entry-title {\n  min-width: 0;\n  color: inherit;\n  line-height: 1.3;\n  overflow: hidden;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  word-break: break-word;\n}\n\n.wf-branch-entry-url {\n  min-width: 0;\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  line-height: 1.25;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-branch-connector {\n  position: relative;\n  width: 20px;\n  height: 16px;\n  margin: 3px 0 3px 6px;\n  color: #838383;\n}\n\n.wf-branch-connector::before {\n  content: "";\n  position: absolute;\n  left: 6px;\n  top: 0;\n  bottom: 2px;\n  border-left: 1px solid currentColor;\n}\n\n.wf-branch-connector::after {\n  content: "";\n  position: absolute;\n  left: 3px;\n  bottom: 1px;\n  width: 6px;\n  height: 6px;\n  border-right: 1px solid currentColor;\n  border-bottom: 1px solid currentColor;\n  transform: rotate(45deg);\n}\n\n.wf-branch-connector-typed {\n  color: var(--ht-color-warning);\n}\n\n.wf-branch-connector-spa {\n  color: var(--ht-color-accent);\n}\n\n.wf-more {\n  justify-self: start;\n  padding: 3px 9px;\n  margin-left: 12px;\n  border-radius: 999px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-muted);\n  cursor: pointer;\n  font-size: 11px;\n}\n\n.wf-more:hover {\n  background: var(--ht-color-surface-strong);\n  color: var(--ht-color-text-strong);\n}\n\n.wf-more-collapse {\n  margin-top: 4px;\n}\n\n.wf-tooltip {\n  pointer-events: none;\n  position: fixed;\n  z-index: 10;\n  max-width: min(82vw, 520px);\n  padding: 9px 11px;\n  border-radius: 8px;\n  background: var(--ht-color-bg);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  backface-visibility: hidden;\n  contain: layout style paint;\n}\n\n.wf-tooltip-title {\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n  font-weight: 700;\n  line-height: 1.35;\n  white-space: normal;\n  word-break: break-word;\n}\n\n.wf-tooltip-url {\n  color: var(--ht-color-text-soft);\n  font-size: 11px;\n  margin-top: 4px;\n  word-break: break-all;\n  white-space: normal;\n}\n\n.wf-tooltip-time {\n  color: var(--ht-color-text-muted);\n  font-size: 10px;\n  margin-top: 3px;\n}\n\n.wf-preview-pane {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 12;\n  width: min(88vw, 640px);\n  height: min(72vh, 520px);\n  display: grid;\n  grid-template-rows: auto minmax(0, 1fr);\n  overflow: hidden;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  contain: layout style paint;\n}\n\n.wf-preview-pane-bottom {\n  border-radius: 8px 8px 0 0;\n}\n\n.wf-preview-pane-header {\n  min-width: 0;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto;\n  gap: 8px;\n  align-items: center;\n  padding: 8px 8px 8px 10px;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  background: #252525;\n}\n\n.wf-preview-pane-identity {\n  min-width: 0;\n}\n\n.wf-preview-pane-kicker {\n  color: var(--ht-color-text-title);\n  font-size: 10px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  margin-bottom: 2px;\n}\n\n.wf-preview-pane-title {\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n  font-weight: 700;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-preview-pane-url {\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  margin-top: 2px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-preview-pane-actions {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n}\n\n.wf-preview-pane-drag,\n.wf-preview-pane-action,\n.wf-preview-pane-close {\n  width: 22px;\n  height: 22px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  background: var(--ht-color-surface);\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  padding: 0;\n  font-size: 12px;\n  font-weight: 800;\n}\n\n.wf-preview-pane-drag {\n  cursor: grab;\n  color: #ffdf8a;\n  background: rgba(254,188,46,0.16);\n  border-color: rgba(254,188,46,0.36);\n}\n\n.wf-preview-pane-drag:hover,\n.wf-preview-pane-dragging .wf-preview-pane-drag {\n  color: #fff;\n  background: rgba(254,188,46,0.28);\n  border-color: rgba(254,188,46,0.62);\n}\n\n.wf-preview-pane-dragging {\n  opacity: 0.96;\n}\n\n.wf-preview-pane-action:hover {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-accent-soft);\n  border-color: var(--ht-color-accent);\n}\n\n.wf-preview-pane-close {\n  color: #ffd6d3;\n  background: rgba(255,95,87,0.14);\n  border-color: rgba(255,95,87,0.3);\n}\n\n.wf-preview-pane-close:hover {\n  color: #fff;\n  background: rgba(255,95,87,0.28);\n  border-color: rgba(255,95,87,0.56);\n}\n\n.wf-preview-pane-frame {\n  width: 100%;\n  height: 100%;\n  border: 0;\n  background: #fff;\n}\n\n.wf-menu {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 14;\n  min-width: 170px;\n  padding: 4px;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  contain: layout style paint;\n}\n\n.wf-menu-item {\n  padding: 6px 10px;\n  border-radius: 5px;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  font-size: 12px;\n}\n\n.wf-menu-item:hover {\n  background: var(--ht-color-accent-soft);\n  color: var(--ht-color-text-strong);\n}\n\n@media (max-width: 520px) {\n  .wf-bar {\n    width: min(96vw, 360px);\n    max-height: 78vh;\n    font-size: 11px;\n  }\n\n  .wf-branch-header {\n    min-height: 38px;\n    padding: 7px 8px;\n  }\n\n  .wf-branch-list {\n    padding: 8px;\n  }\n\n  .wf-preview-pane {\n    width: calc(100vw - 24px);\n    height: min(66vh, 520px);\n  }\n}\n';

  // src/lib/common/utils/panelHost.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/helpers.ts
  var HTML_ESCAPE = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  };
  var HTML_ESCAPE_RE = /[&<>"']/;
  function escapeHtml(text) {
    if (!HTML_ESCAPE_RE.test(text)) return text;
    return text.replace(/[&<>"']/g, (character) => HTML_ESCAPE[character]);
  }
  var DOMAIN_CACHE_MAX = 500;
  var domainCache = /* @__PURE__ */ new Map();
  function cacheDomain(url, value) {
    if (domainCache.size >= DOMAIN_CACHE_MAX) {
      const firstKey = domainCache.keys().next().value;
      if (firstKey !== void 0) domainCache.delete(firstKey);
    }
    domainCache.set(url, value);
    return value;
  }
  function extractDomain(url) {
    const cached = domainCache.get(url);
    if (cached) return cached;
    try {
      return cacheDomain(url, new URL(url).hostname);
    } catch (_) {
      return cacheDomain(url, url.length > 30 ? url.substring(0, 30) + "\u2026" : url);
    }
  }

  // src/lib/common/utils/panelHost.ts
  var activePanelCleanup = null;
  var activePanelFailSafeCleanup = null;
  function invokeCleanupSafely(label, cleanup) {
    if (!cleanup) return;
    try {
      cleanup();
    } catch (error) {
      console.error(`[TabTrail] ${label}:`, error);
    }
  }
  function cleanupPanelFailSafe() {
    const cleanup = activePanelFailSafeCleanup;
    activePanelFailSafeCleanup = null;
    invokeCleanupSafely("Panel fail-safe cleanup failed", cleanup);
  }
  function handlePanelRuntimeFault(label, reason) {
    if (!document.getElementById("ht-panel-host")) return;
    console.error(`[TabTrail] ${label}; dismissing panel.`, reason);
    dismissPanel();
  }
  var EXTENSION_BASE_URL = import_webextension_polyfill3.default.runtime.getURL("");
  function reasonLooksExtensionScoped(reason) {
    if (!reason) return false;
    if (typeof reason === "string") return reason.includes(EXTENSION_BASE_URL);
    if (typeof reason === "object") {
      const maybeError = reason;
      if (typeof maybeError.stack === "string" && maybeError.stack.includes(EXTENSION_BASE_URL)) {
        return true;
      }
      if (typeof maybeError.message === "string" && maybeError.message.includes(EXTENSION_BASE_URL)) {
        return true;
      }
    }
    return false;
  }
  function isPanelRuntimeFaultFromExtension(event) {
    if (typeof event.filename === "string" && event.filename.startsWith(EXTENSION_BASE_URL)) {
      return true;
    }
    if (reasonLooksExtensionScoped(event.error)) return true;
    return reasonLooksExtensionScoped(event.message);
  }
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      const cleanup = activePanelCleanup;
      activePanelCleanup = null;
      invokeCleanupSafely("Panel cleanup failed while opening a new panel", cleanup);
    }
    cleanupPanelFailSafe();
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host = document.createElement("div");
    host.id = "ht-panel-host";
    host.tabIndex = -1;
    host.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:auto;overscroll-behavior:contain;isolation:isolate;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    let lastFocusedInPanel = null;
    let pointerInteractionInPanel = false;
    shadow.addEventListener("focusin", (event) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        lastFocusedInPanel = target;
      }
    });
    shadow.addEventListener("pointerdown", () => {
      pointerInteractionInPanel = true;
    });
    const onGlobalPointerEnd = () => {
      pointerInteractionInPanel = false;
    };
    window.addEventListener("pointerup", onGlobalPointerEnd, true);
    window.addEventListener("pointercancel", onGlobalPointerEnd, true);
    const focusPreferredPanelTarget = () => {
      if (!document.getElementById("ht-panel-host")) return;
      if (lastFocusedInPanel && shadow.contains(lastFocusedInPanel)) {
        lastFocusedInPanel.focus({ preventScroll: true });
        return;
      }
      host.focus({ preventScroll: true });
    };
    let reclaimId = 0;
    host.addEventListener("focusout", () => {
      cancelAnimationFrame(reclaimId);
      reclaimId = requestAnimationFrame(() => {
        if (document.visibilityState !== "visible") return;
        if (pointerInteractionInPanel) return;
        if (!document.getElementById("ht-panel-host")) return;
        const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
        const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
        if (!activeInHostTree && !activeInShadow) {
          focusPreferredPanelTarget();
        }
      });
    });
    const onVisibilityChange = () => {
      if (document.visibilityState !== "visible") return;
      if (!document.getElementById("ht-panel-host")) return;
      const activeInHostTree = document.activeElement === host || host.contains(document.activeElement);
      const activeInShadow = !!shadow.activeElement && shadow.contains(shadow.activeElement);
      if (!activeInHostTree && !activeInShadow) {
        focusPreferredPanelTarget();
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);
    const onError = (event) => {
      if (!isPanelRuntimeFaultFromExtension(event)) return;
      handlePanelRuntimeFault("Panel runtime error", event.error || event.message);
    };
    const onUnhandledRejection = (event) => {
      if (!reasonLooksExtensionScoped(event.reason)) return;
      handlePanelRuntimeFault("Panel unhandled rejection", event.reason);
    };
    let lastAnimationFrameAt = performance.now();
    let frameProbeId = 0;
    const frameProbe = (ts) => {
      lastAnimationFrameAt = ts;
      frameProbeId = requestAnimationFrame(frameProbe);
    };
    frameProbeId = requestAnimationFrame(frameProbe);
    const watchdogIntervalId = window.setInterval(() => {
      if (!document.getElementById("ht-panel-host")) return;
      if (document.visibilityState !== "visible") return;
      const gapMs = performance.now() - lastAnimationFrameAt;
      if (gapMs > 3e3) {
        handlePanelRuntimeFault("Panel watchdog detected UI stall", { gapMs });
      }
    }, 1e3);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);
    activePanelFailSafeCleanup = () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
      window.removeEventListener("pointerup", onGlobalPointerEnd, true);
      window.removeEventListener("pointercancel", onGlobalPointerEnd, true);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      cancelAnimationFrame(frameProbeId);
      window.clearInterval(watchdogIntervalId);
    };
    return { host, shadow };
  }
  function removePanelHost() {
    cleanupPanelFailSafe();
    const host = document.getElementById("ht-panel-host");
    if (host) host.remove();
    activePanelCleanup = null;
  }
  function dismissPanel() {
    const cleanup = activePanelCleanup;
    activePanelCleanup = null;
    invokeCleanupSafely("Panel cleanup failed during dismiss", cleanup);
    removePanelHost();
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      --ht-input-row-pad-y: 8px;
      --ht-input-row-pad-x: 14px;
      --ht-input-row-pad-x-compact: 10px;
      --ht-input-prompt-gap: 8px;
      --ht-input-prompt-size: 14px;
      --ht-input-prompt-weight: 600;
      --ht-input-font-size: 13px;
      --ht-input-caret-color: var(--ht-color-text-strong);
      --ht-pane-header-pad-y: 5px;
      --ht-pane-header-pad-x: 14px;
      --ht-pane-header-font-size: 11px;
      --ht-pane-header-weight: 500;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    /* Keep every overlay shell truly centered, even if panel-specific
       rules regress or are partially overridden. */
    .ht-help-container {
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    /* Reusable UI primitives (input rows + pane headers) for panel consistency */
    .ht-ui-input-wrap {
      display: flex;
      align-items: center;
      padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);
      border-bottom: 1px solid var(--ht-color-border-soft);
      background: var(--ht-color-bg-elevated);
    }
    .ht-ui-input-prompt {
      color: var(--ht-color-accent);
      margin-right: var(--ht-input-prompt-gap);
      font-weight: var(--ht-input-prompt-weight);
      font-size: var(--ht-input-prompt-size);
    }
    .ht-ui-input-field {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: var(--ht-color-text);
      font-family: inherit;
      font-size: var(--ht-input-font-size);
      caret-color: var(--ht-input-caret-color);
    }
    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }
    .ht-ui-input-field::placeholder {
      color: var(--ht-color-text-dim);
    }
    .ht-ui-pane-header {
      padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);
      font-size: var(--ht-pane-header-font-size);
      color: var(--ht-color-text-muted);
      background: var(--ht-color-bg-elevated);
      border-bottom: 1px solid var(--ht-color-border-faint);
      font-weight: var(--ht-pane-header-weight);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ht-ui-pane-header-text {
      flex: 1;
    }
    .ht-ui-pane-header-meta {
      font-size: 10px;
      color: var(--ht-color-text-dim);
      flex-shrink: 0;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 8px; justify-content: center; width: 100%; flex-wrap: wrap;
      align-items: center;
    }
    .ht-footer-hint {
      display: inline-flex;
      align-items: baseline;
      gap: 4px;
      white-space: nowrap;
      color: var(--ht-color-text-muted);
    }
    .ht-footer-key {
      color: var(--ht-color-text-soft);
      font-weight: 700;
    }
    .ht-footer-sep {
      color: var(--ht-color-text-dim);
      font-weight: 600;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }

    @media (max-width: 520px), (max-height: 560px) {
      .ht-ui-input-wrap {
        padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);
      }
    }
  `;
  }

  // src/lib/ui/panels/breadcrumbTrail/breadcrumbTrail.ts
  var DEFAULT_POSITION = { xPercent: 50, yPercent: 8 };
  var HOVER_DETAIL_DELAY_MS = 350;
  var PREVIEW_VIEWPORT_MARGIN = 12;
  var PREVIEW_GAP = 12;
  var PREVIEW_SIDE_MIN_WIDTH = 460;
  var PREVIEW_DESKTOP_WIDTH = 640;
  var PREVIEW_DESKTOP_HEIGHT = 520;
  var session = null;
  function isBreadcrumbTrailOpen() {
    return session !== null;
  }
  function hideBreadcrumbTrail() {
    if (!session) return;
    dismissPanel();
  }
  function updateBreadcrumbTrail(state) {
    if (!session) return;
    session.state = state;
    renderBar();
  }
  function showBreadcrumbTrail(state, options) {
    const { host, shadow } = createPanelHost();
    host.style.pointerEvents = "none";
    const style = document.createElement("style");
    style.textContent = getBaseStyles() + breadcrumbTrail_default;
    shadow.appendChild(style);
    const layer = document.createElement("div");
    layer.className = "wf-layer";
    shadow.appendChild(layer);
    const bar = document.createElement("div");
    bar.className = "wf-bar";
    bar.setAttribute("role", "navigation");
    bar.setAttribute("aria-label", "Navigation trail");
    layer.appendChild(bar);
    session = {
      shadow,
      bar,
      layer,
      options,
      state,
      expanded: false,
      position: options.settings.overlayPosition ?? DEFAULT_POSITION
    };
    applyPosition();
    renderBar();
    const onDocumentKeydown = (event) => {
      if (event.key !== "Escape" || !session) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      hideBreadcrumbTrail();
    };
    document.addEventListener("keydown", onDocumentKeydown, true);
    registerPanelCleanup(() => {
      document.removeEventListener("keydown", onDocumentKeydown, true);
      closeEntryMenu();
      hideTooltip();
      closeEntryPreview();
      const closing = session;
      session = null;
      closing?.options.callbacks.onClose();
    });
  }
  function applyPosition() {
    if (!session) return;
    const { xPercent, yPercent } = session.position;
    session.bar.style.left = `${xPercent}%`;
    session.bar.style.top = `${yPercent}%`;
    if (previewElement) positionPreviewPane(previewElement);
  }
  function entryTitle(entry) {
    if (entry.title.trim() !== "") return entry.title.trim();
    const domain = extractDomain(entry.url);
    return domain !== "" ? domain : entry.url;
  }
  function entryUrlSubtitle(entry) {
    try {
      const parsed = new URL(entry.url);
      const path = parsed.pathname === "/" ? "" : parsed.pathname;
      const query = parsed.search ? "?..." : "";
      const hash = parsed.hash ? "#..." : "";
      return `${parsed.hostname}${path}${query}${hash}`;
    } catch (_) {
      return entry.url;
    }
  }
  function branchConnectorElement(nextEntry, showTransitionArrows) {
    const connector = document.createElement("div");
    connector.className = "wf-branch-connector";
    connector.setAttribute("aria-hidden", "true");
    if (!showTransitionArrows) {
      return connector;
    }
    if (nextEntry.transition === "typed") {
      connector.classList.add("wf-branch-connector-typed");
    } else if (nextEntry.transition === "spa" || nextEntry.transition === "fragment") {
      connector.classList.add("wf-branch-connector-spa");
    }
    connector.title = nextEntry.transition;
    return connector;
  }
  function visibleIndices(state, maxVisible, expanded) {
    const total = state.entries.length;
    if (expanded || total <= maxVisible) {
      return state.entries.map((_, index) => index);
    }
    const budget = Math.min(Math.max(1, maxVisible), total);
    const selected = /* @__PURE__ */ new Set([0]);
    const addIndex = (index) => {
      if (selected.size >= budget) return;
      if (index < 0 || index >= total) return;
      selected.add(index);
    };
    addIndex(state.cursor);
    addIndex(total - 1);
    for (let distance = 1; selected.size < budget && distance < total; distance += 1) {
      addIndex(state.cursor - distance);
      addIndex(state.cursor + distance);
    }
    return [...selected].sort((a, b) => a - b);
  }
  function renderBar() {
    if (!session) return;
    const { bar, state, options } = session;
    const { settings, callbacks } = options;
    closeEntryMenu();
    hideTooltip();
    closeEntryPreview();
    bar.textContent = "";
    bar.appendChild(buildBranchHeader(callbacks));
    const branchList = buildBranchList();
    bar.appendChild(branchList);
    if (state.entries.length === 0) {
      const empty = document.createElement("span");
      empty.className = "wf-empty";
      empty.textContent = "No trail yet. Start clicking links to build one.";
      branchList.appendChild(empty);
      return;
    }
    const indices = visibleIndices(state, settings.maxVisibleSegments, session.expanded);
    let previousRendered = null;
    for (const index of indices) {
      if (previousRendered !== null) {
        if (index > previousRendered + 1) {
          const firstHiddenIndex = previousRendered + 1;
          branchList.appendChild(branchConnectorElement(
            state.entries[firstHiddenIndex],
            settings.showTransitionArrows
          ));
          branchList.appendChild(buildMorePill(index - previousRendered - 1));
        }
        branchList.appendChild(branchConnectorElement(state.entries[index], settings.showTransitionArrows));
      }
      branchList.appendChild(buildBranchRow(index, state, callbacks));
      previousRendered = index;
    }
    if (session.expanded && state.entries.length > settings.maxVisibleSegments) {
      branchList.appendChild(buildCollapsePill());
    }
  }
  function buildBranchHeader(callbacks) {
    const header = document.createElement("div");
    header.className = "wf-branch-header";
    header.appendChild(buildSettingsButton(callbacks));
    const title = document.createElement("span");
    title.className = "wf-branch-title";
    title.textContent = "Branch";
    header.appendChild(title);
    header.appendChild(buildGrip());
    header.appendChild(buildCloseButton());
    return header;
  }
  function buildBranchList() {
    const branchList = document.createElement("div");
    branchList.className = "wf-branch-list";
    return branchList;
  }
  function buildGrip() {
    const grip = document.createElement("span");
    grip.className = "wf-grip";
    grip.textContent = "\u283F";
    grip.title = "Drag to move";
    grip.addEventListener("pointerdown", startDrag);
    return grip;
  }
  function buildSettingsButton(callbacks) {
    const settings = document.createElement("span");
    settings.className = "wf-settings";
    settings.textContent = "\u2699";
    settings.title = "Open settings";
    settings.addEventListener("click", () => callbacks.onOpenOptions());
    return settings;
  }
  function buildCloseButton() {
    const close = document.createElement("span");
    close.className = "wf-close";
    close.textContent = "\u2715";
    close.title = "Hide (Esc)";
    close.addEventListener("click", () => hideBreadcrumbTrail());
    return close;
  }
  function buildMorePill(hiddenCount) {
    const pill = document.createElement("span");
    pill.className = "wf-more";
    pill.textContent = `+${hiddenCount} more`;
    pill.title = "Show the full trail";
    pill.addEventListener("click", () => {
      if (!session) return;
      session.expanded = true;
      renderBar();
    });
    return pill;
  }
  function buildCollapsePill() {
    const pill = document.createElement("span");
    pill.className = "wf-more wf-more-collapse";
    pill.textContent = "Show less";
    pill.title = "Collapse the trail";
    pill.addEventListener("click", () => {
      if (!session) return;
      session.expanded = false;
      renderBar();
    });
    return pill;
  }
  function buildBranchRow(index, state, callbacks) {
    const entry = state.entries[index];
    const row = document.createElement("div");
    row.className = "wf-branch-row";
    if (index === state.cursor) row.classList.add("wf-branch-row-current");
    if (index > state.cursor) row.classList.add("wf-branch-row-forward");
    row.setAttribute("aria-current", index === state.cursor ? "page" : "false");
    const node = document.createElement("span");
    node.className = "wf-branch-node";
    node.setAttribute("aria-hidden", "true");
    row.appendChild(node);
    const content = document.createElement("div");
    content.className = "wf-branch-entry";
    const title = document.createElement("span");
    title.className = "wf-branch-entry-title";
    title.textContent = entryTitle(entry);
    content.appendChild(title);
    const url = document.createElement("span");
    url.className = "wf-branch-entry-url";
    url.textContent = entryUrlSubtitle(entry);
    content.appendChild(url);
    row.appendChild(content);
    row.addEventListener("click", (event) => {
      event.preventDefault();
      if (index !== state.cursor) callbacks.onJump(index);
    });
    row.addEventListener("mouseenter", () => scheduleTooltip(row, entry));
    row.addEventListener("mouseleave", hideTooltip);
    row.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openEntryMenu(row, index, entry, callbacks);
    });
    return row;
  }
  var tooltipElement = null;
  var tooltipDelayHandle = null;
  function clearTooltipDelay() {
    if (tooltipDelayHandle == null) return;
    window.clearTimeout(tooltipDelayHandle);
    tooltipDelayHandle = null;
  }
  function rowNeedsTooltip(anchor) {
    const title = anchor.querySelector(".wf-branch-entry-title");
    const url = anchor.querySelector(".wf-branch-entry-url");
    return Boolean(
      title && title.scrollHeight > title.clientHeight + 1 || url && url.scrollWidth > url.clientWidth + 1
    );
  }
  function scheduleTooltip(anchor, entry) {
    hideTooltip();
    tooltipDelayHandle = window.setTimeout(() => {
      tooltipDelayHandle = null;
      if (!anchor.matches(":hover") || !rowNeedsTooltip(anchor)) return;
      showTooltip(anchor, entry);
    }, HOVER_DETAIL_DELAY_MS);
  }
  function showTooltip(anchor, entry) {
    if (!session) return;
    hideTooltip();
    const title = entryTitle(entry);
    const tooltip = document.createElement("div");
    tooltip.className = "wf-tooltip";
    tooltip.innerHTML = `
    <div class="wf-tooltip-title">${escapeHtml(title)}</div>
    <div class="wf-tooltip-url">${escapeHtml(entry.url)}</div>
    <div class="wf-tooltip-time">${escapeHtml(formatTrailTimestamp(entry.timestamp, Date.now()))}</div>
  `;
    session.layer.appendChild(tooltip);
    positionPopover(tooltip, anchor);
    tooltipElement = tooltip;
  }
  function hideTooltip() {
    clearTooltipDelay();
    tooltipElement?.remove();
    tooltipElement = null;
  }
  var previewElement = null;
  var previewedRowElement = null;
  var previewManualPosition = null;
  var previewDragCleanup = null;
  function closeEntryPreview() {
    stopPreviewPaneDrag();
    previewManualPosition = null;
    previewedRowElement?.classList.remove("wf-branch-row-previewed");
    previewedRowElement = null;
    previewElement?.remove();
    previewElement = null;
  }
  function stopPreviewPaneDrag() {
    if (previewDragCleanup) {
      previewDragCleanup();
      previewDragCleanup = null;
    }
    previewElement?.classList.remove("wf-preview-pane-dragging");
  }
  function openEntryPreview(anchor, index, entry, callbacks) {
    if (!session) return;
    closeEntryPreview();
    hideTooltip();
    anchor.classList.add("wf-branch-row-previewed");
    previewedRowElement = anchor;
    const preview = document.createElement("div");
    preview.className = "wf-preview-pane";
    const header = document.createElement("div");
    header.className = "wf-preview-pane-header";
    const identity = document.createElement("div");
    identity.className = "wf-preview-pane-identity";
    const kicker = document.createElement("div");
    kicker.className = "wf-preview-pane-kicker";
    kicker.textContent = "Preview";
    identity.appendChild(kicker);
    const title = document.createElement("div");
    title.className = "wf-preview-pane-title";
    title.textContent = entryTitle(entry);
    identity.appendChild(title);
    const url = document.createElement("div");
    url.className = "wf-preview-pane-url";
    url.textContent = entryUrlSubtitle(entry);
    identity.appendChild(url);
    const actions = document.createElement("div");
    actions.className = "wf-preview-pane-actions";
    const drag = document.createElement("button");
    drag.className = "wf-preview-pane-drag";
    drag.type = "button";
    drag.textContent = "\u283F";
    drag.title = "Move preview pane";
    drag.addEventListener("pointerdown", startPreviewPaneDrag);
    const open = document.createElement("button");
    open.className = "wf-preview-pane-action";
    open.type = "button";
    open.textContent = "\u2197";
    open.title = "Open in new tab";
    open.addEventListener("click", () => callbacks.onOpenInNewTab(index));
    const close = document.createElement("button");
    close.className = "wf-preview-pane-close";
    close.type = "button";
    close.textContent = "\u2715";
    close.title = "Close preview";
    close.addEventListener("click", () => closeEntryPreview());
    actions.appendChild(drag);
    actions.appendChild(open);
    actions.appendChild(close);
    header.appendChild(identity);
    header.appendChild(actions);
    const frame = document.createElement("iframe");
    frame.className = "wf-preview-pane-frame";
    frame.title = `Preview: ${entryTitle(entry)}`;
    frame.referrerPolicy = "no-referrer";
    frame.setAttribute("sandbox", "allow-forms allow-popups allow-same-origin allow-scripts");
    frame.src = entry.url;
    preview.appendChild(header);
    preview.appendChild(frame);
    session.layer.appendChild(preview);
    positionPreviewPane(preview);
    previewElement = preview;
  }
  function positionPreviewPane(preview) {
    if (!session) return;
    const barRect = session.bar.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const margin = PREVIEW_VIEWPORT_MARGIN;
    const availableHeight = Math.max(160, viewportHeight - margin * 2);
    const rightSpace = viewportWidth - barRect.right - PREVIEW_GAP - margin;
    const leftSpace = barRect.left - PREVIEW_GAP - margin;
    const canUseRight = viewportWidth >= 760 && rightSpace >= PREVIEW_SIDE_MIN_WIDTH;
    const canUseLeft = viewportWidth >= 760 && leftSpace >= PREVIEW_SIDE_MIN_WIDTH;
    preview.classList.remove("wf-preview-pane-bottom");
    if (previewManualPosition) {
      const rect = preview.getBoundingClientRect();
      const position = clampPreviewPanePosition(
        previewManualPosition.left,
        previewManualPosition.top,
        rect.width || PREVIEW_DESKTOP_WIDTH,
        rect.height || PREVIEW_DESKTOP_HEIGHT
      );
      previewManualPosition = position;
      preview.style.left = `${position.left}px`;
      preview.style.top = `${position.top}px`;
      return;
    }
    preview.style.width = "";
    preview.style.height = "";
    preview.style.left = "";
    preview.style.top = "";
    if (canUseRight || canUseLeft) {
      const useRight = canUseRight && (!canUseLeft || rightSpace >= leftSpace);
      const availableWidth = useRight ? rightSpace : leftSpace;
      const width2 = Math.min(PREVIEW_DESKTOP_WIDTH, availableWidth);
      const height2 = Math.min(PREVIEW_DESKTOP_HEIGHT, availableHeight);
      const left = useRight ? barRect.right + PREVIEW_GAP : barRect.left - PREVIEW_GAP - width2;
      const top = Math.min(
        Math.max(margin, barRect.top),
        Math.max(margin, viewportHeight - height2 - margin)
      );
      preview.style.width = `${width2}px`;
      preview.style.height = `${height2}px`;
      preview.style.left = `${left}px`;
      preview.style.top = `${top}px`;
      return;
    }
    preview.classList.add("wf-preview-pane-bottom");
    const width = Math.max(0, viewportWidth - margin * 2);
    const targetHeight = Math.round(viewportHeight * 0.66);
    const height = Math.min(Math.max(260, targetHeight), availableHeight);
    preview.style.width = `${width}px`;
    preview.style.height = `${height}px`;
    preview.style.left = `${margin}px`;
    preview.style.top = `${Math.max(margin, viewportHeight - height - margin)}px`;
  }
  function clampPreviewPanePosition(left, top, width, height) {
    const margin = PREVIEW_VIEWPORT_MARGIN;
    const maxLeft = Math.max(margin, window.innerWidth - width - margin);
    const maxTop = Math.max(margin, window.innerHeight - height - margin);
    return {
      left: Math.min(Math.max(margin, left), maxLeft),
      top: Math.min(Math.max(margin, top), maxTop)
    };
  }
  function startPreviewPaneDrag(event) {
    if (!previewElement) return;
    event.preventDefault();
    event.stopPropagation();
    stopPreviewPaneDrag();
    const pane = previewElement;
    const paneRect = pane.getBoundingClientRect();
    const offsetX = event.clientX - paneRect.left;
    const offsetY = event.clientY - paneRect.top;
    pane.classList.remove("wf-preview-pane-bottom");
    pane.classList.add("wf-preview-pane-dragging");
    pane.style.width = `${paneRect.width}px`;
    pane.style.height = `${paneRect.height}px`;
    previewManualPosition = clampPreviewPanePosition(
      paneRect.left,
      paneRect.top,
      paneRect.width,
      paneRect.height
    );
    pane.style.left = `${previewManualPosition.left}px`;
    pane.style.top = `${previewManualPosition.top}px`;
    const move = (moveEvent) => {
      const position = clampPreviewPanePosition(
        moveEvent.clientX - offsetX,
        moveEvent.clientY - offsetY,
        paneRect.width,
        paneRect.height
      );
      previewManualPosition = position;
      pane.style.left = `${position.left}px`;
      pane.style.top = `${position.top}px`;
    };
    const end = () => {
      window.removeEventListener("pointermove", move, true);
      window.removeEventListener("pointerup", end, true);
      window.removeEventListener("pointercancel", end, true);
      previewDragCleanup = null;
      pane.classList.remove("wf-preview-pane-dragging");
    };
    previewDragCleanup = end;
    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", end, true);
    window.addEventListener("pointercancel", end, true);
  }
  var menuElement = null;
  var menuDismissCleanup = null;
  function closeEntryMenu() {
    menuElement?.remove();
    menuElement = null;
    if (menuDismissCleanup) {
      menuDismissCleanup();
      menuDismissCleanup = null;
    }
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (_) {
    }
    const scratch = document.createElement("textarea");
    scratch.value = text;
    scratch.style.cssText = "position:fixed;opacity:0;pointer-events:none;";
    document.body.appendChild(scratch);
    scratch.select();
    try {
      document.execCommand("copy");
    } finally {
      scratch.remove();
    }
  }
  function openEntryMenu(anchor, index, entry, callbacks) {
    if (!session) return;
    closeEntryMenu();
    hideTooltip();
    const menu = document.createElement("div");
    menu.className = "wf-menu";
    const items = [
      { label: "Preview", action: () => openEntryPreview(anchor, index, entry, callbacks) },
      { label: "Open in new tab", action: () => callbacks.onOpenInNewTab(index) },
      { label: "Open in new window", action: () => callbacks.onOpenInNewWindow(index) },
      { label: "Copy URL", action: () => void copyText(entry.url) }
    ];
    for (const item of items) {
      const row = document.createElement("div");
      row.className = "wf-menu-item";
      row.textContent = item.label;
      row.addEventListener("click", (event) => {
        event.stopPropagation();
        closeEntryMenu();
        item.action();
      });
      menu.appendChild(row);
    }
    session.layer.appendChild(menu);
    positionPopover(menu, anchor);
    menuElement = menu;
    const onOutsidePointer = (event) => {
      if (menuElement && event.composedPath().includes(menuElement)) return;
      closeEntryMenu();
    };
    document.addEventListener("pointerdown", onOutsidePointer, true);
    menuDismissCleanup = () => {
      document.removeEventListener("pointerdown", onOutsidePointer, true);
    };
  }
  function positionPopover(popover, anchor) {
    const anchorRect = anchor.getBoundingClientRect();
    popover.style.left = "0px";
    popover.style.top = "0px";
    const popoverRect = popover.getBoundingClientRect();
    const width = popoverRect.width || 240;
    const left = Math.min(
      Math.max(8, anchorRect.left),
      Math.max(8, window.innerWidth - width - 8)
    );
    let top = anchorRect.bottom + 6;
    if (top + popoverRect.height > window.innerHeight - 8) {
      top = Math.max(8, anchorRect.top - popoverRect.height - 6);
    }
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  }
  function startDrag(event) {
    if (!session) return;
    event.preventDefault();
    const { bar } = session;
    const barRect = bar.getBoundingClientRect();
    const grabOffsetX = event.clientX - (barRect.left + barRect.width / 2);
    const grabOffsetY = event.clientY - barRect.top;
    bar.classList.add("wf-dragging");
    const onMove = (moveEvent) => {
      if (!session) return;
      const x = (moveEvent.clientX - grabOffsetX) / window.innerWidth * 100;
      const y = (moveEvent.clientY - grabOffsetY) / window.innerHeight * 100;
      session.position = {
        xPercent: Math.min(Math.max(x, 0), 100),
        yPercent: Math.min(Math.max(y, 0), 96)
      };
      applyPosition();
    };
    const onEnd = () => {
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onEnd, true);
      window.removeEventListener("pointercancel", onEnd, true);
      if (!session) return;
      session.bar.classList.remove("wf-dragging");
      session.options.callbacks.onPositionChange(session.position);
    };
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onEnd, true);
    window.addEventListener("pointercancel", onEnd, true);
  }

  // src/lib/appInit/appInit.ts
  var MOUSE_CHORD_SWALLOW_WINDOW_MS = 600;
  function isTopFrame() {
    try {
      return window.self === window.top;
    } catch (_) {
      return false;
    }
  }
  function initApp() {
    window.__wayfindCleanup?.();
    let settings = normalizeWayfindSettings(null);
    let disposed = false;
    const topFrame = isTopFrame();
    let swallowMouseUntil = 0;
    let swallowedButton = -1;
    void loadWayfindSettings().then((loaded) => {
      if (!disposed) settings = loaded;
    });
    function toTriggerEvent(event) {
      if (event instanceof KeyboardEvent) {
        return {
          type: "keydown",
          code: event.code,
          altKey: event.altKey,
          ctrlKey: event.ctrlKey,
          metaKey: event.metaKey,
          shiftKey: event.shiftKey,
          repeat: event.repeat,
          isTrusted: event.isTrusted
        };
      }
      return {
        type: "mousedown",
        button: event.button,
        altKey: event.altKey,
        ctrlKey: event.ctrlKey,
        metaKey: event.metaKey,
        shiftKey: event.shiftKey,
        isTrusted: event.isTrusted
      };
    }
    function fireToggle() {
      void toggleTrailOverlay().catch(() => {
      });
    }
    const keydownHandler = (event) => {
      if (!matchesToggleTrigger(toTriggerEvent(event), settings.trigger)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      fireToggle();
    };
    const mousedownHandler = (event) => {
      if (!matchesToggleTrigger(toTriggerEvent(event), settings.trigger)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      swallowMouseUntil = performance.now() + MOUSE_CHORD_SWALLOW_WINDOW_MS;
      swallowedButton = event.button;
      fireToggle();
    };
    const mouseFollowUpHandler = (event) => {
      if (performance.now() > swallowMouseUntil) return;
      if (event.type !== "contextmenu" && event.button !== swallowedButton) return;
      event.preventDefault();
      event.stopImmediatePropagation();
    };
    window.addEventListener("keydown", keydownHandler, true);
    window.addEventListener("mousedown", mousedownHandler, true);
    window.addEventListener("auxclick", mouseFollowUpHandler, true);
    window.addEventListener("click", mouseFollowUpHandler, true);
    window.addEventListener("contextmenu", mouseFollowUpHandler, true);
    const storageChangedHandler = (changes, areaName) => {
      if (areaName !== "local" || !changes[WAYFIND_STORAGE_KEYS.settings]) return;
      settings = normalizeWayfindSettings(changes[WAYFIND_STORAGE_KEYS.settings].newValue);
    };
    import_webextension_polyfill4.default.storage.onChanged.addListener(storageChangedHandler);
    let messageHandler = null;
    let pageHideHandler = null;
    if (topFrame) {
      const openOverlay = (state) => {
        showBreadcrumbTrail(state, {
          settings,
          callbacks: {
            onJump: (index) => {
              void jumpToTrailEntry(index);
            },
            onOpenInNewTab: (index) => {
              void openTrailEntryInNewTab(index);
            },
            onOpenInNewWindow: (index) => {
              void openTrailEntryInNewWindow(index);
            },
            onOpenOptions: () => {
              void openWayfindOptions();
            },
            onClose: () => {
              void reportTrailOverlayState(false).catch(() => {
              });
            },
            onPositionChange: (position) => {
              void saveWayfindSettings({ ...settings, overlayPosition: position });
            }
          }
        });
        void reportTrailOverlayState(true).catch(() => {
        });
      };
      messageHandler = (message) => {
        if (typeof message !== "object" || message === null) return void 0;
        const typed = message;
        switch (typed.type) {
          case "WAYFIND_PING":
            return Promise.resolve({ ok: true });
          case "TRAIL_SHOW":
            if (isBreadcrumbTrailOpen()) {
              hideBreadcrumbTrail();
            } else {
              openOverlay(typed.state);
            }
            return Promise.resolve({ ok: true });
          case "TRAIL_UPDATED":
            if (isBreadcrumbTrailOpen()) updateBreadcrumbTrail(typed.state);
            return Promise.resolve({ ok: true });
          case "HISTORY_GO":
            try {
              window.history.go(typed.delta);
              return Promise.resolve({ ok: true });
            } catch (_) {
              return Promise.resolve({ ok: false, reason: "history.go failed" });
            }
          default:
            return void 0;
        }
      };
      import_webextension_polyfill4.default.runtime.onMessage.addListener(messageHandler);
      pageHideHandler = () => {
        if (!isBreadcrumbTrailOpen()) return;
        hideBreadcrumbTrail();
      };
      window.addEventListener("pagehide", pageHideHandler);
      void announceTrailContentReady().catch(() => {
      });
    }
    window.__wayfindCleanup = () => {
      disposed = true;
      window.removeEventListener("keydown", keydownHandler, true);
      window.removeEventListener("mousedown", mousedownHandler, true);
      window.removeEventListener("auxclick", mouseFollowUpHandler, true);
      window.removeEventListener("click", mouseFollowUpHandler, true);
      window.removeEventListener("contextmenu", mouseFollowUpHandler, true);
      import_webextension_polyfill4.default.storage.onChanged.removeListener(storageChangedHandler);
      if (messageHandler) import_webextension_polyfill4.default.runtime.onMessage.removeListener(messageHandler);
      if (pageHideHandler) window.removeEventListener("pagehide", pageHideHandler);
      if (isBreadcrumbTrailOpen()) hideBreadcrumbTrail();
      delete window.__wayfindCleanup;
    };
  }

  // src/entryPoints/contentScript/contentScript.ts
  initApp();
})();
