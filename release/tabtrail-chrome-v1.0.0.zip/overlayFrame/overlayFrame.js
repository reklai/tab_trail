"use strict";(()=>{var Tn=Object.create;var Ht=Object.defineProperty;var xn=Object.getOwnPropertyDescriptor;var En=Object.getOwnPropertyNames;var Sn=Object.getPrototypeOf,An=Object.prototype.hasOwnProperty;var Rn=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Ln=(e,t,r,n)=>{if(t&&typeof t=="object"||typeof t=="function")for(let i of En(t))!An.call(e,i)&&i!==r&&Ht(e,i,{get:()=>t[i],enumerable:!(n=xn(t,i))||n.enumerable});return e};var He=(e,t,r)=>(r=e!=null?Tn(Sn(e)):{},Ln(t||!e||!e.__esModule?Ht(r,"default",{value:e,enumerable:!0}):r,e));var Te=Rn((nt,Ft)=>{(function(e,t){if(typeof define=="function"&&define.amd)define("webextension-polyfill",["module"],t);else if(typeof nt<"u")t(Ft);else{var r={exports:{}};t(r),e.browser=r.exports}})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:nt,function(e){"use strict";if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)e.exports=globalThis.browser;else{let t="The message port closed before a response was received.",r=n=>{let i={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(i).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class o extends WeakMap{constructor(y,w=void 0){super(w),this.createItem=y}get(y){return this.has(y)||this.set(y,this.createItem(y)),super.get(y)}}let a=g=>g&&typeof g=="object"&&typeof g.then=="function",s=(g,y)=>(...w)=>{n.runtime.lastError?g.reject(new Error(n.runtime.lastError.message)):y.singleCallbackArg||w.length<=1&&y.singleCallbackArg!==!1?g.resolve(w[0]):g.resolve(w)},u=g=>g==1?"argument":"arguments",l=(g,y)=>function(T,...A){if(A.length<y.minArgs)throw new Error(`Expected at least ${y.minArgs} ${u(y.minArgs)} for ${g}(), got ${A.length}`);if(A.length>y.maxArgs)throw new Error(`Expected at most ${y.maxArgs} ${u(y.maxArgs)} for ${g}(), got ${A.length}`);return new Promise((C,N)=>{if(y.fallbackToNoCallback)try{T[g](...A,s({resolve:C,reject:N},y))}catch(S){console.warn(`${g} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,S),T[g](...A),y.fallbackToNoCallback=!1,y.noCallback=!0,C()}else y.noCallback?(T[g](...A),C()):T[g](...A,s({resolve:C,reject:N},y))})},d=(g,y,w)=>new Proxy(y,{apply(T,A,C){return w.call(A,g,...C)}}),c=Function.call.bind(Object.prototype.hasOwnProperty),f=(g,y={},w={})=>{let T=Object.create(null),A={has(N,S){return S in g||S in T},get(N,S,I){if(S in T)return T[S];if(!(S in g))return;let P=g[S];if(typeof P=="function")if(typeof y[S]=="function")P=d(g,g[S],y[S]);else if(c(w,S)){let ae=l(S,w[S]);P=d(g,g[S],ae)}else P=P.bind(g);else if(typeof P=="object"&&P!==null&&(c(y,S)||c(w,S)))P=f(P,y[S],w[S]);else if(c(w,"*"))P=f(P,y[S],w["*"]);else return Object.defineProperty(T,S,{configurable:!0,enumerable:!0,get(){return g[S]},set(ae){g[S]=ae}}),P;return T[S]=P,P},set(N,S,I,P){return S in T?T[S]=I:g[S]=I,!0},defineProperty(N,S,I){return Reflect.defineProperty(T,S,I)},deleteProperty(N,S){return Reflect.deleteProperty(T,S)}},C=Object.create(g);return new Proxy(C,A)},p=g=>({addListener(y,w,...T){y.addListener(g.get(w),...T)},hasListener(y,w){return y.hasListener(g.get(w))},removeListener(y,w){y.removeListener(g.get(w))}}),b=new o(g=>typeof g!="function"?g:function(w){let T=f(w,{},{getContent:{minArgs:0,maxArgs:0}});g(T)}),R=new o(g=>typeof g!="function"?g:function(w,T,A){let C=!1,N,S=new Promise(we=>{N=function(V){C=!0,we(V)}}),I;try{I=g(w,T,N)}catch(we){I=Promise.reject(we)}let P=I!==!0&&a(I);if(I!==!0&&!P&&!C)return!1;let ae=we=>{we.then(V=>{A(V)},V=>{let rt;V&&(V instanceof Error||typeof V.message=="string")?rt=V.message:rt="An unexpected error occurred",A({__mozWebExtensionPolyfillReject__:!0,message:rt})}).catch(V=>{console.error("Failed to send onMessage rejected reply",V)})};return ae(P?I:S),!0}),v=({reject:g,resolve:y},w)=>{n.runtime.lastError?n.runtime.lastError.message===t?y():g(new Error(n.runtime.lastError.message)):w&&w.__mozWebExtensionPolyfillReject__?g(new Error(w.message)):y(w)},x=(g,y,w,...T)=>{if(T.length<y.minArgs)throw new Error(`Expected at least ${y.minArgs} ${u(y.minArgs)} for ${g}(), got ${T.length}`);if(T.length>y.maxArgs)throw new Error(`Expected at most ${y.maxArgs} ${u(y.maxArgs)} for ${g}(), got ${T.length}`);return new Promise((A,C)=>{let N=v.bind(null,{resolve:A,reject:C});T.push(N),w.sendMessage(...T)})},M={devtools:{network:{onRequestFinished:p(b)}},runtime:{onMessage:p(R),onMessageExternal:p(R),sendMessage:x.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:x.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},_={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return i.privacy={network:{"*":_},services:{"*":_},websites:{"*":_}},f(n,M,i)};e.exports=r(chrome)}})});var Bt=He(Te());function Vt(e){return new Promise(t=>setTimeout(t,e))}var Mn={retryDelaysMs:[0,80,220,420]};function On(e){let r=(e instanceof Error?e.message:String(e)).toLowerCase();return r.includes("receiving end does not exist")||r.includes("could not establish connection")}async function $t(e){return await Bt.default.runtime.sendMessage(e)}async function W(e,t=Mn){let r=null;for(let n of t.retryDelaysMs){n>0&&await Vt(n);try{return await $t(e)}catch(i){if(r=i,!On(i))throw i}}throw r||new Error(`Runtime message failed: ${e.type}`)}async function Ut(e){return W({type:"OVERLAY_FRAME_CLAIM",nonce:e})}async function Wt(e,t){return W({type:"SAVED_TRAIL_OPEN",path:e,mode:t})}async function zt(e,t){return W({type:"SAVED_TRAIL_SAVE",path:e,name:t})}async function qt(e,t){return W({type:"SAVED_TRAIL_RENAME",id:e,name:t})}async function Kt(e,t,r){return W({type:"SAVED_TRAIL_REPLACE",id:e,path:t,expectedPath:r})}async function Yt(e,t){return W({type:"SAVED_TRAIL_SET_PINNED",id:e,pinned:t})}async function Gt(e){return W({type:"SAVED_TRAIL_DELETE",id:e})}async function jt(e){return W({type:"SAVED_TRAIL_RESTORE",trail:e})}var _n=/^[a-f0-9]{32}$/,Cn=/^(?:Key[A-Z]|Digit[0-9])$/;function D(e){return typeof e=="object"&&e!==null&&!Array.isArray(e)}function L(e,t,r=[]){let n=Object.keys(e);if(!t.every(o=>Object.prototype.hasOwnProperty.call(e,o)))return!1;let i=new Set([...t,...r]);return n.every(o=>i.has(o))}function xe(e){return typeof e=="number"&&Number.isFinite(e)}function Xt(e){return typeof e=="number"&&Number.isSafeInteger(e)&&e>=0}function Ee(e){return e===void 0||typeof e=="string"}function Pn(e){return!D(e)||!L(e,["xPercent","yPercent"])?!1:xe(e.xPercent)&&e.xPercent>=0&&e.xPercent<=100&&xe(e.yPercent)&&e.yPercent>=0&&e.yPercent<=100}var Nn=new Set(["link","typed","reload","spa","fragment","form","back_forward","other"]);function kn(e){return!D(e)||!L(e,["url","title","favIconUrl","timestamp","transition","redirected","historyBacked"])?!1:typeof e.url=="string"&&e.url.length>0&&typeof e.title=="string"&&typeof e.favIconUrl=="string"&&xe(e.timestamp)&&typeof e.transition=="string"&&Nn.has(e.transition)&&typeof e.redirected=="boolean"&&typeof e.historyBacked=="boolean"}function Qt(e){return Array.isArray(e)&&e.length<=100&&e.every(kn)}function it(e){if(!D(e)||!L(e,["entries","cursor"])||!Qt(e.entries)||!Number.isSafeInteger(e.cursor))return!1;let t=e.cursor;return e.entries.length===0?t===-1:t>=0&&t<e.entries.length}function In(e){return!D(e)||!L(e,["modifier","withShift","kind","keyCode","mouseButton"])?!1:(e.modifier==="alt"||e.modifier==="ctrl"||e.modifier==="super")&&typeof e.withShift=="boolean"&&(e.kind==="key"||e.kind==="mouse")&&typeof e.keyCode=="string"&&Cn.test(e.keyCode)&&typeof e.mouseButton=="number"&&[0,1,2].includes(e.mouseButton)}function ot(e){return!D(e)||!L(e,["trigger","overlayPosition","maxVisibleSegments"])?!1:In(e.trigger)&&(e.overlayPosition===null||Pn(e.overlayPosition))&&Number.isSafeInteger(e.maxVisibleSegments)&&e.maxVisibleSegments>=5&&e.maxVisibleSegments<=12}function Fe(e){return!D(e)||!L(e,["id","name","pinned","createdAt","updatedAt","entries"])?!1:typeof e.id=="string"&&e.id.length>0&&typeof e.name=="string"&&e.name.length>0&&typeof e.pinned=="boolean"&&xe(e.createdAt)&&xe(e.updatedAt)&&Qt(e.entries)&&e.entries.length>0}function Ve(e){return Array.isArray(e)&&e.length<=50&&e.every(Fe)}function Dn(e){return!D(e)||!L(e,["ok"],["reason"])?!1:e.ok===!0?e.reason===void 0:e.ok===!1&&Ee(e.reason)}function Hn(e){return!D(e)||typeof e.ok!="boolean"?!1:e.ok===!1?L(e,["ok"],["reason"])&&Ee(e.reason):L(e,["ok","trails"])&&Ve(e.trails)}function Fn(e){return!D(e)||typeof e.ok!="boolean"?!1:e.ok===!1?L(e,["ok"],["reason"])&&Ee(e.reason):L(e,["ok","trail","trails"])&&Fe(e.trail)&&Ve(e.trails)}function Vn(e){return!D(e)||typeof e.ok!="boolean"?!1:e.ok===!1?L(e,["ok"],["reason"])&&Ee(e.reason):L(e,["ok","trail","previousTrail","trails"])&&Fe(e.trail)&&Fe(e.previousTrail)&&Ve(e.trails)}function Jt(e){return D(e)&&typeof e.type=="string"&&e.version===2}function Bn(e){return Jt(e)&&L(e,["type","version","nonce"])&&e.type==="TABTRAIL_OVERLAY_CONNECT"&&typeof e.nonce=="string"&&_n.test(e.nonce)}function $n(e){return D(e)?typeof e.postMessage=="function"&&typeof e.start=="function"&&typeof e.close=="function"&&typeof e.addEventListener=="function"&&typeof e.removeEventListener=="function":!1}function Zt(e){if(!D(e)||!Bn(e.data)||!Array.isArray(e.ports)||e.ports.length!==1)return null;let t=e.ports[0];return $n(t)?{message:e.data,port:t}:null}function Un(e){return typeof e=="string"&&["LIVE_JUMP","LIVE_OPEN_NEW_TAB","LIVE_OPEN_NEW_WINDOW","LIVE_OPEN_OPTIONS","LIVE_CLOSE","LIVE_SET_POSITION","SAVED_LOAD","SAVED_OPEN","SAVED_SAVE","SAVED_RENAME","SAVED_REPLACE","SAVED_SET_PINNED","SAVED_DELETE","SAVED_RESTORE"].includes(e)}function Wn(e,t){switch(e){case"SAVED_LOAD":return Hn(t);case"SAVED_SAVE":case"SAVED_RENAME":case"SAVED_SET_PINNED":case"SAVED_DELETE":case"SAVED_RESTORE":return Fn(t);case"SAVED_REPLACE":return Vn(t);default:return Dn(t)}}function zn(e){return!D(e)||!L(e,["requestId","method","result"])?!1:Xt(e.requestId)&&Un(e.method)&&Wn(e.method,e.result)}function er(e){if(!Jt(e))return!1;switch(e.type){case"HOST_INIT":return L(e,["type","version","state","settings"])&&it(e.state)&&ot(e.settings);case"HOST_TRAIL_UPDATED":return L(e,["type","version","state"])&&it(e.state);case"HOST_SETTINGS_UPDATED":return L(e,["type","version","settings"])&&ot(e.settings);case"HOST_SAVED_TRAILS_UPDATED":return L(e,["type","version","trails"])&&Ve(e.trails);case"HOST_RPC_RESPONSE":return L(e,["type","version","response"])&&zn(e.response);case"HOST_DISMISS_TRANSIENTS":case"HOST_ESCAPE":case"HOST_FOCUS_RELEASED":case"HOST_REQUEST_SURFACES":return L(e,["type","version"]);case"HOST_PING":return L(e,["type","version","heartbeatId"])&&Xt(e.heartbeatId);case"HOST_HIBERNATE":return L(e,["type","version"]);case"HOST_SHOW":return L(e,["type","version","state","settings"])&&it(e.state)&&ot(e.settings);case"HOST_SHUTDOWN":return L(e,["type","version"],["reason"])&&Ee(e.reason);default:return!1}}var G=50,Be=80;function se(e){return typeof e!="string"?"":e.trim().replace(/\s+/g," ").slice(0,Be)}function tr(e){return se(e).toLowerCase()}function at(e){if(!e)return"Saved trail";let t=e.title.trim();if(t!=="")return se(t)||"Saved trail";try{let r=new URL(e.url).hostname;return se(r)||"Saved trail"}catch{return"Saved trail"}}function le(e){return e.entries.length===0?null:e.entries[e.entries.length-1]}function st(e){return rr({entries:e,cursor:Array.isArray(e)?e.length-1:-1}).entries}function $e(e,t){return e.length!==t.length?!1:e.every((r,n)=>{let i=t[n];return r.url===i.url&&r.title===i.title&&r.favIconUrl===i.favIconUrl&&r.timestamp===i.timestamp&&r.transition===i.transition&&r.redirected===i.redirected&&r.historyBacked===i.historyBacked})}function lt(e){if(typeof e!="object"||e===null)return null;let t=e,r=se(t.name);if(r==="")return null;let n=typeof t.id=="string"&&t.id!==""?t.id:null;if(!n)return null;let i=st(t.entries);if(i.length===0)return null;let o=typeof t.createdAt=="number"&&Number.isFinite(t.createdAt)?t.createdAt:0,a=typeof t.updatedAt=="number"&&Number.isFinite(t.updatedAt)?t.updatedAt:o;return{id:n,name:r,pinned:t.pinned===!0,createdAt:o,updatedAt:a,entries:i}}function z(e){if(!Array.isArray(e))return[];let t=new Set,r=new Set,n=[];for(let i of e){let o=lt(i);if(!o)continue;let a=tr(o.name);if(!(t.has(o.id)||r.has(a))&&(t.add(o.id),r.add(a),n.push(o),n.length>=G))break}return n.sort((i,o)=>o.updatedAt-i.updatedAt||o.createdAt-i.createdAt)}var Gn=100;var jn=["alt","ctrl","super"],nr=600;function ct(e){return e.type==="keydown"?{type:"keydown",code:e.code,altKey:e.altKey,ctrlKey:e.ctrlKey,metaKey:e.metaKey,shiftKey:e.shiftKey,repeat:e.repeat,isTrusted:e.isTrusted}:{type:"mousedown",button:e.button,altKey:e.altKey,ctrlKey:e.ctrlKey,metaKey:e.metaKey,shiftKey:e.shiftKey,isTrusted:e.isTrusted}}function ir(e,t){return e.type==="contextmenu"?t===2:e.button===t}function dt(e,t){if(!e.isTrusted||e.shiftKey!==t.withShift)return!1;let r={alt:e.altKey,ctrl:e.ctrlKey,super:e.metaKey};for(let n of jn){let i=n===t.modifier;if(r[n]!==i)return!1}return t.kind==="key"?e.type==="keydown"&&e.repeat!==!0&&e.code===t.keyCode:e.type==="mousedown"&&e.button===t.mouseButton}var Xn=["link","typed","reload","spa","fragment","form","back_forward","other"];function Qn(e){return Xn.includes(e)?e:"other"}function ut(e,t){let r=Math.max(0,t-e),n=Math.floor(r/1e3);if(n<45)return"just now";let i=Math.floor(n/60);if(i<60)return`${Math.max(1,i)}m ago`;let o=Math.floor(i/60);return o<24?`${o}h ago`:`${Math.floor(o/24)}d ago`}function rr(e){if(typeof e!="object"||e===null)return{entries:[],cursor:-1};let t=e;if(!Array.isArray(t.entries))return{entries:[],cursor:-1};let r=t.entries,n=r.slice(-Gn),i=r.length-n.length,a=(typeof t.cursor=="number"&&Number.isInteger(t.cursor)?t.cursor:r.length-1)-i,s=[],u=-1;for(let l=0;l<n.length;l+=1){let d=n[l];if(typeof d!="object"||d===null)continue;let c=d;typeof c.url!="string"||c.url===""||(l<=a&&(u=s.length),s.push({url:c.url,title:typeof c.title=="string"?c.title:"",favIconUrl:typeof c.favIconUrl=="string"?c.favIconUrl:"",timestamp:typeof c.timestamp=="number"&&Number.isFinite(c.timestamp)?c.timestamp:0,transition:Qn(c.transition),redirected:c.redirected===!0,historyBacked:c.historyBacked!==!1}))}return s.length===0?{entries:[],cursor:-1}:(u===-1&&(u=0),{entries:s,cursor:u})}function ce(e,t){let{entries:r}=e;return!Number.isInteger(t)||t<0||t>=r.length?null:r.slice(0,t+1).map(n=>({...n}))}function or(e=window,t=nr){let r=0,n=-1,i=o=>{o instanceof MouseEvent&&(performance.now()>r||ir(o,n)&&(o.preventDefault(),o.stopImmediatePropagation()))};return e.addEventListener("auxclick",i,!0),e.addEventListener("click",i,!0),e.addEventListener("contextmenu",i,!0),{arm(o){r=performance.now()+t,n=o},dispose(){r=0,n=-1,e.removeEventListener("auxclick",i,!0),e.removeEventListener("click",i,!0),e.removeEventListener("contextmenu",i,!0)}}}var ar=`.wf-layer {
  position: fixed;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
  overscroll-behavior: none;
}

.wf-bar {
  pointer-events: auto;
  position: fixed;
  transform: translateX(-50%) translateZ(0);
  width: min(90vw, 390px);
  max-height: min(82vh, 560px);
  display: flex;
  flex-direction: column;
  overflow: visible;
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  color: var(--ht-color-text);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  font-size: 12px;
  line-height: 1.35;
  user-select: none;
  backface-visibility: hidden;
  will-change: transform;
  contain: layout style paint;
}

.wf-branch-header {
  min-height: 42px;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  background: #252525;
  border-bottom: 1px solid var(--ht-color-border-soft);
  border-radius: 8px 8px 0 0;
}

.wf-header-left {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.wf-settings,
.wf-library {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  cursor: pointer;
  color: var(--ht-color-text-soft);
  background: var(--ht-color-surface);
  border: 1px solid var(--ht-color-border-soft);
  border-radius: 6px;
  padding: 0;
  flex-shrink: 0;
  font-size: 13px;
  font-weight: 800;
  line-height: 1;
}

.wf-settings:hover,
.wf-library:hover {
  color: var(--ht-color-text-strong);
  background: var(--ht-color-accent-soft);
  border-color: var(--ht-color-accent);
}

.wf-settings:focus-visible,
.wf-library:focus-visible,
.wf-close:focus-visible,
.wf-preview-pane-action:focus-visible,
.wf-preview-pane-close:focus-visible,
.wf-trail-tree-preview-close:focus-visible,
.wf-notice-action:focus-visible {
  outline: 2px solid var(--ht-color-accent);
  outline-offset: 2px;
}

.wf-notice-stack {
  pointer-events: none;
  position: fixed;
  z-index: 16;
  left: 50%;
  bottom: 18px;
  transform: translateX(-50%);
  width: min(92vw, 380px);
  max-height: calc(100vh - 36px);
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 3px;
  box-sizing: border-box;
  overflow-y: auto;
  overscroll-behavior: contain;
}

.wf-notice {
  pointer-events: auto;
  width: 100%;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 6px;
  background: var(--ht-color-bg-elevated);
  color: var(--ht-color-text-strong);
  border: 1px solid var(--ht-color-accent);
  box-shadow: var(--ht-shadow-overlay);
  font-size: 11px;
  line-height: 1.3;
}

.wf-notice-error {
  border-color: rgba(255, 95, 87, 0.72);
}

.wf-notice-copy {
  min-width: 0;
}

.wf-notice-action {
  flex: 0 0 auto;
  border: 0;
  border-radius: 5px;
  padding: 5px 8px;
  background: var(--ht-color-accent);
  color: #fff;
  font: inherit;
  font-weight: 700;
  cursor: pointer;
}

.wf-notice-action:disabled {
  cursor: wait;
  opacity: 0.7;
}

.wf-branch-title {
  min-width: 0;
  color: var(--ht-color-text-title);
  font-size: 11px;
  font-weight: 700;
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-branch-list {
  min-height: 0;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
  padding: 10px 10px 12px;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
}

.wf-bar.wf-dragging {
  cursor: grabbing;
  opacity: 0.92;
}

.wf-bar-blocked {
  pointer-events: none;
  background: #101010;
}

.wf-bar-blocked .wf-branch-header {
  background: #121212;
}

.wf-bar-blocked .wf-branch-row-current {
  color: #b8b8b8;
  background: #151515;
  box-shadow: none;
}

.wf-bar-blocked .wf-branch-row-current .wf-branch-node {
  background: #686868;
  box-shadow: none;
}

.wf-bar-blocked .wf-branch-row-current .wf-branch-entry-url {
  color: #858585;
}

.wf-grip {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  cursor: grab;
  color: #ffdf8a;
  background: rgba(254,188,46,0.16);
  border: 1px solid rgba(254,188,46,0.36);
  border-radius: 6px;
  padding: 0;
  flex-shrink: 0;
  font-size: 13px;
  font-weight: 800;
}

.wf-grip:hover {
  color: #fff;
  background: rgba(254,188,46,0.26);
  border-color: rgba(254,188,46,0.62);
}

.wf-bar.wf-dragging .wf-grip {
  color: #fff;
  background: rgba(254,188,46,0.34);
  border-color: rgba(254,188,46,0.74);
}

.wf-close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  cursor: pointer;
  color: #ffd6d3;
  background: rgba(255,95,87,0.14);
  border: 1px solid rgba(255,95,87,0.3);
  padding: 0;
  border-radius: 6px;
  flex-shrink: 0;
  font-size: 13px;
  font-weight: 800;
}

.wf-close:hover {
  color: #fff;
  background: rgba(255,95,87,0.28);
  border-color: rgba(255,95,87,0.56);
}

.wf-empty {
  color: var(--ht-color-text-muted);
  padding: 4px 6px;
  line-height: 1.45;
}

.wf-branch-row {
  min-width: 0;
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  column-gap: 4px;
  align-items: start;
  margin: 2px 0;
  padding: 7px 6px 7px 6px;
  border-radius: 7px;
  color: #d6d6d6;
}

.wf-branch-row:hover,
.wf-branch-row:focus-within {
  background: var(--ht-color-hover);
  color: var(--ht-color-text-strong);
}

.wf-branch-row-main {
  min-width: 0;
  display: grid;
  grid-template-columns: 14px minmax(0, 1fr);
  column-gap: 8px;
  align-items: start;
  padding: 0;
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.wf-branch-row-main:focus-visible {
  outline: 2px solid var(--ht-color-accent);
  outline-offset: 3px;
  border-radius: 4px;
}

.wf-branch-row-current .wf-branch-row-main {
  cursor: default;
}

.wf-branch-node {
  width: 7px;
  height: 7px;
  margin-top: 6px;
  border-radius: 999px;
  background: #8f8f8f;
  box-shadow: none;
}

.wf-branch-row-current {
  color: #f2f7ff;
  font-weight: 700;
  background: rgba(10,132,255,0.18);
  box-shadow: inset 0 0 0 1px rgba(10,132,255,0.3);
  cursor: default;
}

.wf-branch-row-current .wf-branch-node {
  background: #30d158;
  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);
}

.wf-branch-row-fork .wf-branch-node {
  outline: 1px dashed rgba(142, 192, 255, 0.8);
  outline-offset: 3px;
}

.wf-branch-row-current .wf-branch-entry-url {
  color: #aacdff;
}

.wf-branch-row-previewed {
  box-shadow: inset 3px 0 0 #ffb340, inset 0 0 0 1px rgba(255,179,64,0.24);
}

.wf-branch-row-previewed:not(.wf-branch-row-current) {
  background: rgba(255,179,64,0.1);
}

.wf-branch-row-previewed .wf-branch-node {
  background: #ffb340;
  box-shadow: 0 0 0 3px rgba(255,179,64,0.18);
}

.wf-branch-row-current.wf-branch-row-previewed .wf-branch-node {
  background: #30d158;
  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);
}

.wf-branch-row-forward {
  opacity: 0.52;
}

.wf-branch-entry {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.wf-branch-entry-title {
  min-width: 0;
  color: inherit;
  line-height: 1.3;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  word-break: break-word;
}

.wf-branch-entry-url {
  min-width: 0;
  color: var(--ht-color-text-muted);
  font-size: 11px;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-row-more {
  align-self: start;
  width: 28px;
  height: 28px;
  margin-top: -1px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: var(--ht-color-text-muted);
  background: transparent;
  border: 1px solid transparent;
  border-radius: 6px;
  padding: 0;
  font-size: 16px;
  font-weight: 800;
  line-height: 1;
}

.wf-row-more:hover,
.wf-row-more:focus-visible {
  color: var(--ht-color-text-strong);
  background: var(--ht-color-surface);
  border-color: var(--ht-color-border-soft);
  outline: none;
}

.wf-branch-connector {
  position: relative;
  width: 20px;
  height: 16px;
  margin: 3px 0 3px 6px;
  color: #838383;
}

.wf-branch-connector::before {
  content: "";
  position: absolute;
  left: 6px;
  top: 0;
  bottom: 2px;
  border-left: 1px solid currentColor;
}

.wf-branch-connector::after {
  content: "";
  position: absolute;
  left: 3px;
  bottom: 1px;
  width: 6px;
  height: 6px;
  border-right: 1px solid currentColor;
  border-bottom: 1px solid currentColor;
  transform: rotate(45deg);
}

.wf-branch-connector-typed {
  color: var(--ht-color-warning);
}

.wf-branch-connector-spa {
  color: var(--ht-color-accent);
}

.wf-branch-connector-inherited {
  color: #7894b5;
  opacity: 0.65;
}

.wf-branch-connector-inherited::before {
  border-left-style: dashed;
}

.wf-more {
  justify-self: start;
  padding: 3px 9px;
  margin-left: 12px;
  border-radius: 999px;
  background: var(--ht-color-surface);
  color: var(--ht-color-text-muted);
  cursor: pointer;
  font-size: 11px;
  border: 0;
  font-family: inherit;
}

.wf-more:hover {
  background: var(--ht-color-surface-strong);
  color: var(--ht-color-text-strong);
}

.wf-more:focus-visible {
  outline: 2px solid var(--ht-color-accent);
  outline-offset: 2px;
}

.wf-more-collapse {
  margin-top: 4px;
}

.wf-preview-pane {
  pointer-events: auto;
  position: fixed;
  z-index: 12;
  width: min(88vw, 640px);
  height: min(72vh, 520px);
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  overflow: hidden;
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  contain: layout style paint;
}

.wf-preview-pane-bottom {
  border-radius: 8px 8px 0 0;
}

.wf-preview-pane-header {
  min-width: 0;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
  align-items: center;
  padding: 8px 8px 8px 10px;
  border-bottom: 1px solid var(--ht-color-border-soft);
  background: #252525;
}

.wf-preview-pane-identity {
  min-width: 0;
}

.wf-preview-pane-kicker {
  color: var(--ht-color-text-title);
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  margin-bottom: 2px;
}

.wf-preview-pane-title {
  color: var(--ht-color-text-strong);
  font-size: 12px;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-preview-pane-url {
  color: var(--ht-color-text-muted);
  font-size: 11px;
  margin-top: 2px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-preview-pane-actions {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.wf-preview-pane-drag,
.wf-preview-pane-action,
.wf-preview-pane-close {
  width: 22px;
  height: 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: var(--ht-color-text-soft);
  background: var(--ht-color-surface);
  border: 1px solid var(--ht-color-border-soft);
  border-radius: 6px;
  padding: 0;
  font-size: 12px;
  font-weight: 800;
}

.wf-preview-pane-drag {
  cursor: grab;
  color: #ffdf8a;
  background: rgba(254,188,46,0.16);
  border-color: rgba(254,188,46,0.36);
}

.wf-preview-pane-drag:hover,
.wf-preview-pane-dragging .wf-preview-pane-drag {
  color: #fff;
  background: rgba(254,188,46,0.28);
  border-color: rgba(254,188,46,0.62);
}

.wf-preview-pane-dragging {
  opacity: 0.96;
}

.wf-preview-pane-action:hover {
  color: var(--ht-color-text-strong);
  background: var(--ht-color-accent-soft);
  border-color: var(--ht-color-accent);
}

.wf-preview-pane-close {
  color: #ffd6d3;
  background: rgba(255,95,87,0.14);
  border-color: rgba(255,95,87,0.3);
}

.wf-preview-pane-close:hover {
  color: #fff;
  background: rgba(255,95,87,0.28);
  border-color: rgba(255,95,87,0.56);
}

.wf-preview-pane-frame {
  width: 100%;
  height: 100%;
  border: 0;
  outline: 0;
  display: block;
  background: var(--ht-color-bg);
}

.wf-menu {
  pointer-events: auto;
  position: fixed;
  z-index: 14;
  box-sizing: border-box;
  width: min(320px, calc(100vw - 16px));
  max-height: calc(100vh - 16px);
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 6px;
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  contain: layout style paint;
}

.wf-menu-detail {
  padding: 9px 10px;
  margin-bottom: 6px;
  border-radius: 6px;
  background: var(--ht-color-surface-dim);
  border: 1px solid var(--ht-color-border-soft);
}

.wf-menu-detail-title {
  color: var(--ht-color-text-strong);
  font-size: 12px;
  font-weight: 700;
  line-height: 1.35;
  word-break: break-word;
}

.wf-menu-detail-url {
  color: var(--ht-color-text-soft);
  font-size: 11px;
  line-height: 1.35;
  margin-top: 4px;
  word-break: break-all;
}

.wf-menu-detail-time {
  color: var(--ht-color-text-muted);
  font-size: 10px;
  margin-top: 4px;
}

.wf-menu-actions {
  display: grid;
  gap: 1px;
  padding-bottom: 2px;
}

.wf-menu-item {
  width: 100%;
  border: 0;
  background: transparent;
  padding: 6px 10px;
  border-radius: 5px;
  cursor: pointer;
  color: var(--ht-color-text-soft);
  font-family: inherit;
  font-size: 12px;
  text-align: left;
}

.wf-menu-item:hover,
.wf-menu-item:focus-visible {
  background: var(--ht-color-accent-soft);
  color: var(--ht-color-text-strong);
  outline: none;
}

.wf-menu-item:disabled {
  cursor: default;
  opacity: 0.45;
  background: transparent;
}

.wf-menu-item-danger:not(:disabled) {
  color: #ffb4ae;
}

.wf-menu-item-danger:not(:disabled):hover,
.wf-menu-item-danger:not(:disabled):focus-visible {
  background: rgba(255, 95, 87, 0.14);
  color: #ffd6d3;
}

@media (max-width: 520px) {
  .wf-bar {
    width: min(96vw, 360px);
    max-height: 78vh;
    font-size: 11px;
  }

  .wf-branch-header {
    min-height: 38px;
    padding: 7px 8px;
  }

  .wf-branch-list {
    padding: 8px;
  }

  .wf-preview-pane {
    width: calc(100vw - 24px);
    height: min(66vh, 520px);
  }
}
`;var sr=`/* Saved trails library, dialogs, and path tree preview.
   Mounted alongside the live-bar stylesheet in the overlay shadow root. */

/* Name dialog (save trail up to this point) */
.wf-dialog {
  pointer-events: auto;
  position: fixed;
  z-index: 14;
  left: 50%;
  top: 18%;
  transform: translateX(-50%);
  width: min(92vw, 320px);
  padding: 12px;
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  color: var(--ht-color-text);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  display: grid;
  gap: 8px;
}

.wf-dialog-title {
  font-size: 12px;
  font-weight: 700;
  color: var(--ht-color-text-title);
}

.wf-dialog-summary {
  font-size: 11px;
  color: var(--ht-color-text-muted);
  line-height: 1.35;
}

.wf-dialog-input {
  width: 100%;
  box-sizing: border-box;
  padding: 7px 8px;
  border-radius: 6px;
  border: 1px solid var(--ht-color-border-soft);
  background: var(--ht-color-surface);
  color: var(--ht-color-text-strong);
  font-size: 12px;
}

.wf-dialog-input:focus {
  outline: none;
  border-color: var(--ht-color-accent);
}

.wf-dialog-error {
  font-size: 11px;
  color: #ffb4ae;
  line-height: 1.3;
}

.wf-dialog-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 2px;
}

.wf-dialog-btn {
  padding: 6px 10px;
  border-radius: 6px;
  border: 1px solid var(--ht-color-border-soft);
  background: var(--ht-color-surface);
  color: var(--ht-color-text-soft);
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
}

.wf-dialog-btn:hover {
  color: var(--ht-color-text-strong);
  background: var(--ht-color-surface-strong);
}

.wf-dialog-btn:focus-visible,
.wf-dialog-input:focus-visible {
  outline: 2px solid var(--ht-color-accent);
  outline-offset: 2px;
}

.wf-dialog-btn:disabled,
.wf-dialog-input:disabled {
  cursor: wait;
  opacity: 0.65;
}

.wf-dialog-btn-primary {
  background: var(--ht-color-accent-soft);
  border-color: var(--ht-color-accent);
  color: var(--ht-color-text-strong);
}

/* Saved trails library */
.wf-library-panel {
  pointer-events: auto;
  position: fixed;
  z-index: 13;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  min-height: 120px;
  max-height: min(76vh, 480px);
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  color: var(--ht-color-text);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  overflow: hidden;
  backface-visibility: hidden;
  will-change: transform;
  contain: layout style paint;
}

.wf-library-header {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  background: #252525;
  border-bottom: 1px solid var(--ht-color-border-soft);
}

.wf-library-heading {
  min-width: 0;
  display: flex;
  align-items: baseline;
  gap: 8px;
}

.wf-library-panel-dragging {
  opacity: 0.94;
  cursor: grabbing;
}

.wf-library-panel-dragging .wf-grip {
  cursor: grabbing;
}

.wf-library-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ht-color-text-title);
}

.wf-library-count {
  color: var(--ht-color-text-muted);
  font-size: 10px;
  font-variant-numeric: tabular-nums;
}

.wf-library-close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  cursor: pointer;
  color: #ffd6d3;
  background: rgba(255, 95, 87, 0.14);
  border: 1px solid rgba(255, 95, 87, 0.3);
  border-radius: 6px;
  padding: 0;
  font-size: 13px;
  font-weight: 800;
}

.wf-library-close:hover,
.wf-library-close:focus-visible {
  color: #fff;
  background: rgba(255, 95, 87, 0.28);
  outline: none;
}

.wf-library-tools {
  display: block;
  padding: 8px;
  border-bottom: 1px solid var(--ht-color-border-soft);
  background: var(--ht-color-surface-dim);
}

.wf-library-search {
  width: 100%;
  min-width: 0;
  height: 30px;
  border: 1px solid var(--ht-color-border-soft);
  border-radius: 6px;
  background: var(--ht-color-surface);
  color: var(--ht-color-text-strong);
  padding: 0 8px;
  font-family: inherit;
  font-size: 11px;
}

.wf-library-search:focus-visible {
  outline: 2px solid var(--ht-color-accent);
  outline-offset: 1px;
}

.wf-library-search:disabled {
  opacity: 0.55;
}

.wf-library-list {
  min-height: 0;
  flex: 1;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 8px;
  display: grid;
  gap: 4px;
  max-height: min(58vh, 350px);
}

.wf-library-state {
  color: var(--ht-color-text-muted);
  font-size: 11px;
  line-height: 1.45;
  padding: 14px 8px;
  display: grid;
  justify-items: start;
  gap: 7px;
}

.wf-library-state strong {
  color: var(--ht-color-text-strong);
  font-size: 12px;
}

.wf-library-state-copy {
  max-width: 32ch;
}

.wf-library-state-action {
  border: 1px solid var(--ht-color-border-soft);
  border-radius: 6px;
  padding: 6px 9px;
  background: var(--ht-color-surface);
  color: var(--ht-color-text-strong);
  font-family: inherit;
  font-size: 11px;
  cursor: pointer;
}

.wf-library-state-action:hover,
.wf-library-state-action:focus-visible {
  border-color: var(--ht-color-accent);
  background: var(--ht-color-accent-soft);
  outline: none;
}

.wf-library-limit {
  padding: 6px 8px;
  border-radius: 5px;
  background: rgba(255, 179, 64, 0.1);
  color: #ffd28a;
  font-size: 10px;
  line-height: 1.4;
}

.wf-library-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto auto;
  align-items: start;
  column-gap: 4px;
  padding: 7px 4px 7px 8px;
  border-radius: 6px;
  border: 1px solid transparent;
}

.wf-library-row:hover,
.wf-library-row:focus-within {
  background: var(--ht-color-surface);
  border-color: var(--ht-color-border-soft);
}

.wf-library-row-pinned {
  border-color: rgba(255, 179, 64, 0.2);
}

.wf-library-row[aria-busy="true"] {
  opacity: 0.65;
}

.wf-library-row-main {
  min-width: 0;
  display: grid;
  gap: 2px;
  border: 0;
  background: transparent;
  padding: 0;
  color: inherit;
  font-family: inherit;
  text-align: left;
}

.wf-library-row-name {
  font-size: 12px;
  font-weight: 600;
  color: var(--ht-color-text-strong);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-library-row-meta {
  font-size: 11px;
  color: var(--ht-color-text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-library-search-match {
  padding: 0;
  border-radius: 2px;
  background: #ffe16a;
  color: #241d00;
  box-shadow: 0 0 0 1px rgba(255, 225, 106, 0.28);
}

.wf-library-pin {
  width: 28px;
  height: 28px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: var(--ht-color-text-muted);
  background: transparent;
  border: 1px solid transparent;
  border-radius: 6px;
  padding: 0;
  font-size: 15px;
  line-height: 1;
}

.wf-library-pin:hover,
.wf-library-pin:focus-visible,
.wf-library-pin[aria-pressed="true"] {
  color: #ffd28a;
  background: rgba(255, 179, 64, 0.12);
  border-color: rgba(255, 179, 64, 0.3);
  outline: none;
}

/* Saved trail path tree preview (node list, not page iframe) */
.wf-trail-tree-preview {
  pointer-events: auto;
  position: fixed;
  z-index: 14;
  display: flex;
  flex-direction: column;
  min-height: 120px;
  max-height: min(70vh, 420px);
  border-radius: 8px;
  background: var(--ht-color-bg-elevated);
  color: var(--ht-color-text);
  border: 0;
  box-shadow: var(--ht-shadow-overlay);
  overflow: hidden;
}

.wf-trail-tree-preview-header {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: start;
  gap: 8px;
  padding: 8px 10px;
  background: #252525;
  border-bottom: 1px solid var(--ht-color-border-soft);
}

.wf-trail-tree-preview-identity {
  min-width: 0;
  display: grid;
  gap: 2px;
}

.wf-trail-tree-preview-kicker {
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ht-color-text-muted);
}

.wf-trail-tree-preview-title {
  font-size: 12px;
  font-weight: 700;
  color: var(--ht-color-text-title);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wf-trail-tree-preview-meta {
  font-size: 11px;
  color: var(--ht-color-text-muted);
}

.wf-trail-tree-preview-close {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  cursor: pointer;
  color: #ffd6d3;
  background: rgba(255, 95, 87, 0.14);
  border: 1px solid rgba(255, 95, 87, 0.3);
  border-radius: 6px;
  padding: 0;
  font-size: 13px;
  font-weight: 800;
}

.wf-trail-tree-preview-close:hover {
  color: #fff;
  background: rgba(255, 95, 87, 0.28);
}

.wf-trail-tree-preview-list {
  min-height: 0;
  flex: 1;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 10px;
  display: grid;
  gap: 0;
}

.wf-trail-tree-node {
  cursor: default;
  grid-template-columns: 14px minmax(0, 1fr);
}

.wf-trail-tree-node:hover {
  background: transparent;
  border-color: transparent;
}

@media (max-width: 520px) {
  .wf-library-panel {
    max-height: min(66vh, 380px);
  }

  .wf-library-list {
    max-height: min(48vh, 280px);
  }

  .wf-trail-tree-preview {
    max-height: min(66vh, 380px);
  }

  .wf-dialog {
    top: 12%;
    width: min(94vw, 320px);
  }
}
`;var ft=He(Te());var ei=He(Te());var Se={settings:"tabtrailSettings",savedTrails:"tabtrailSavedTrails"};var lr=He(Te());var Ko=Promise.resolve();async function cr(){let e=await lr.default.storage.local.get(Se.savedTrails);return z(e[Se.savedTrails])}function ti(e){let t=(r,n)=>{if(n!=="local")return;let i=r[Se.savedTrails];i&&e(z(i.newValue))};return ft.default.storage.onChanged.addListener(t),()=>ft.default.storage.onChanged.removeListener(t)}var dr={load:cr,subscribe:ti,open:Wt,save:zt,rename:qt,replace:Kt,setPinned:Yt,delete:Gt,restore:jt};var ee=null,mt=null;function gt(e,t){if(t)try{t()}catch(r){console.error(`[TabTrail] ${e}:`,r)}}function mr(){let e=mt;mt=null,gt("Panel fail-safe cleanup failed",e)}function ur(e,t){document.getElementById("ht-panel-host")&&(console.error(`[TabTrail] ${e}; dismissing panel.`,t),requestAnimationFrame(()=>{document.getElementById("ht-panel-host")&&ht()}))}var pr=/(?:chrome|moz|safari-web)-extension:\/\/[^/\s)]+/i;function ri(e){return e.match(pr)?.[0]??null}var fr=ri(new Error().stack??"");function Ue(e){return fr?e.includes(fr):pr.test(e)}function pt(e){if(!e)return!1;if(typeof e=="string")return Ue(e);if(typeof e=="object"){let t=e;if(typeof t.stack=="string"&&Ue(t.stack)||typeof t.message=="string"&&Ue(t.message))return!0}return!1}function ni(e){return typeof e.filename=="string"&&Ue(e.filename)||pt(e.error)?!0:pt(e.message)}function gr(e){ee=e}function hr(){if(ee){let o=ee;ee=null,gt("Panel cleanup failed while opening a new panel",o)}mr();let e=document.getElementById("ht-panel-host");e&&e.remove();let t=document.createElement("div");t.id="ht-panel-host",t.style.cssText="position:fixed;inset:0;width:100vw;height:100vh;width:100dvw;height:100dvh;z-index:2147483647;pointer-events:auto;overflow:hidden;overscroll-behavior:none;isolation:isolate;";let r=t.attachShadow({mode:"open"});document.body.appendChild(t);let n=o=>{ni(o)&&ur("Panel runtime error",o.error||o.message)},i=o=>{pt(o.reason)&&ur("Panel unhandled rejection",o.reason)};return window.addEventListener("error",n),window.addEventListener("unhandledrejection",i),mt=()=>{window.removeEventListener("error",n),window.removeEventListener("unhandledrejection",i)},{host:t,shadow:r}}function ii(){mr();let e=document.getElementById("ht-panel-host");e&&e.remove(),ee=null}function ht(){let e=ee;ee=null,gt("Panel cleanup failed during dismiss",e),ii()}function br(){return`
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: transparent;
      --ht-color-border-soft: transparent;
      --ht-color-border-faint: transparent;
      --ht-color-border-ultra-faint: transparent;
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: none;
      --ht-radius: 10px;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }
  `}var oi=0;function We(e){let t=`tabtrail-context-menu-${++oi}`,r=document.createElement("div");r.id=t,r.className="wf-menu",r.dataset.tabtrailHitSurface="",r.dataset.tabtrailScrollRegion="",r.setAttribute("role","menu"),r.tabIndex=-1;let n=document.createElement("div");n.className="wf-menu-detail",n.setAttribute("role","presentation");let i=document.createElement("div");i.id=`${t}-title`,i.className="wf-menu-detail-title",i.textContent=e.detail.title,n.appendChild(i),r.setAttribute("aria-labelledby",i.id);let o=[];if(e.detail.subtitle){let v=document.createElement("div");v.id=`${t}-subtitle`,v.className="wf-menu-detail-url",v.textContent=e.detail.subtitle,n.appendChild(v),o.push(v.id)}if(e.detail.meta){let v=document.createElement("div");v.id=`${t}-meta`,v.className="wf-menu-detail-time",v.textContent=e.detail.meta,n.appendChild(v),o.push(v.id)}o.length>0&&r.setAttribute("aria-describedby",o.join(" ")),r.appendChild(n);let a=document.createElement("div");a.className="wf-menu-actions",a.setAttribute("role","presentation");let s=[];for(let v of e.items){let x=document.createElement("button");x.type="button",x.className="wf-menu-item",x.setAttribute("role","menuitem"),x.textContent=v.label,x.disabled=v.disabled===!0,x.tabIndex=-1,v.danger&&(x.classList.add("wf-menu-item-danger"),x.dataset.danger="true"),x.addEventListener("click",M=>{M.stopPropagation(),d(M.detail===0),v.action()}),a.appendChild(x),s.push(x)}r.appendChild(a),e.layer.appendChild(r);let u=()=>ai(r,e.anchor);u(),window.addEventListener("resize",u),e.trigger&&(e.trigger.setAttribute("aria-haspopup","menu"),e.trigger.setAttribute("aria-expanded","true"),e.trigger.setAttribute("aria-controls",t));let l=!1,d=v=>{if(!l){l=!0,document.removeEventListener("pointerdown",c,!0),window.removeEventListener("resize",u),r.remove(),e.trigger&&(e.trigger.setAttribute("aria-expanded","false"),e.trigger.removeAttribute("aria-controls"));try{e.onClose()}finally{v&&e.trigger?.isConnected&&!e.trigger.matches(":disabled")&&e.trigger.focus({preventScroll:!0})}}},c=v=>{let x=v.composedPath();x.includes(r)||e.trigger&&x.includes(e.trigger)||d(!1)};document.addEventListener("pointerdown",c,!0);let f=()=>s.filter(v=>!v.disabled),p=v=>{for(let x of s)x.tabIndex=x===v?0:-1;v.focus({preventScroll:!0}),v.scrollIntoView?.({block:"nearest",inline:"nearest"})};r.addEventListener("keydown",v=>{let x=f();if(v.key==="Escape"){v.preventDefault(),v.stopPropagation(),d(!0);return}if(v.key==="Tab"){d(!1);return}if(!["ArrowDown","ArrowUp","Home","End"].includes(v.key)||x.length===0)return;v.preventDefault(),v.stopPropagation();let M=x.indexOf(v.target),_;v.key==="Home"?_=0:v.key==="End"?_=x.length-1:v.key==="ArrowDown"?_=M<0?0:(M+1)%x.length:_=M<0?x.length-1:(M-1+x.length)%x.length;let g=x[_];g&&p(g)});let b=f()[0];e.focusOnOpen!==!1&&(b?p(b):r.focus({preventScroll:!0}));let R=()=>{let v=r.getRootNode(),x="activeElement"in v?v.activeElement:document.activeElement;return x instanceof HTMLElement&&r.contains(x)};return{element:r,close:()=>d(R())}}function ai(e,t){let i=t.getBoundingClientRect();e.style.left="0px",e.style.top="0px";let o=e.getBoundingClientRect(),a=o.width||240,s=Math.min(o.height,Math.max(0,window.innerHeight-8*2)),u=Math.min(Math.max(8,i.left),Math.max(8,window.innerWidth-a-8)),l=i.bottom+6;l+s>window.innerHeight-8&&(l=i.top-s-6),l=Math.min(Math.max(8,l),Math.max(8,window.innerHeight-s-8)),e.style.left=`${u}px`,e.style.top=`${l}px`}function B(e){queueMicrotask(()=>{let t=e();if(!t?.isConnected||t.matches(":disabled")||t.inert||t.closest("[inert]")!==null)return;let r=t.getRootNode(),n="activeElement"in r?r.activeElement:null;if(n===t)return;let i=t.ownerDocument,o="host"in r?r.host:null,a=s=>s instanceof HTMLElement&&s.isConnected&&s!==i.body&&s!==i.documentElement&&s!==o;a(n)||a(i.activeElement)||t.focus({preventScroll:!0})})}var vr=["keydown","keyup","keypress","beforeinput","input","change","compositionstart","compositionupdate","compositionend","focusin","focusout","copy","cut","paste","pointerdown","pointerup","pointermove","pointercancel","pointerover","pointerout","pointerenter","pointerleave","mousedown","mouseup","mousemove","mouseover","mouseout","mouseenter","mouseleave","click","dblclick","auxclick","contextmenu","touchstart","touchmove","touchend","touchcancel","drag","dragstart","dragend","dragenter","dragleave","dragover","drop"],yr="[data-tabtrail-scroll-region]",si="[data-tabtrail-wheel-surface]";function li(e){return typeof e.matches=="function"}function ci(e){return e.composedPath().filter(li)}function wr(e,t,r,n){return n<0?e>0:n>0?e+t<r:!1}function di(e,t){return wr(e.scrollTop,e.clientHeight,e.scrollHeight,t.deltaY)||wr(e.scrollLeft,e.clientWidth,e.scrollWidth,t.deltaX)}function Tr(e,t,r){return e.deltaMode===WheelEvent.DOM_DELTA_LINE?16:e.deltaMode===WheelEvent.DOM_DELTA_PAGE&&(r==="y"?t.clientHeight:t.clientWidth)||1}function xr(e,t,r){return Math.min(Math.max(e,t),r)}function Er(e,t){let r=t.deltaX*Tr(t,e,"x"),n=t.deltaY*Tr(t,e,"y"),i=Math.max(0,e.scrollWidth-e.clientWidth),o=Math.max(0,e.scrollHeight-e.clientHeight);e.scrollLeft=xr(e.scrollLeft+r,0,i),e.scrollTop=xr(e.scrollTop+n,0,o)}function Sr(e){let t=n=>{n.stopPropagation()},r=n=>{let i=n;i.stopPropagation();let o=ci(i),a=o.find(l=>l.matches(yr));if(a instanceof HTMLElement){di(a,i)?i.defaultPrevented&&Er(a,i):i.preventDefault();return}let u=o.find(l=>l.matches(si))?.querySelector(yr);u&&Er(u,i),i.preventDefault()};for(let n of vr)e.addEventListener(n,t);return e.addEventListener("wheel",r,{passive:!1}),()=>{for(let n of vr)e.removeEventListener(n,t);e.removeEventListener("wheel",r)}}function Ar(e){if(e){e.statusNoticeCleanup?.();for(let t of e.undoNoticeCleanups)t();e.undoNoticeCleanups.clear(),e.statusNoticeCleanup=null}}function ui(e){B(()=>e.noticeStack.querySelector(".wf-notice-action:not(:disabled)")??e.layer.querySelector(".wf-library-search")??e.layer.querySelector(".wf-library-row .wf-row-more")??e.bar.querySelector("[data-live-control=library]"))}function bt(e,t,r,n={}){if(!t())return;let i=n.undo===!0;i||e.statusNoticeCleanup?.();let o=document.createElement("div");o.className=`wf-notice wf-notice-${n.tone??"info"} ${i?"wf-notice-undo":"wf-notice-status"}`,o.dataset.tabtrailHitSurface="",o.setAttribute("role",n.tone==="error"?"alert":"status"),o.setAttribute("aria-live",n.tone==="error"?"assertive":"polite");let a=document.createElement("span");if(a.className="wf-notice-copy",a.textContent=r,o.appendChild(a),n.actionLabel&&n.action){let p=document.createElement("button");p.type="button",p.className="wf-notice-action",p.textContent=n.actionLabel,p.addEventListener("click",()=>{!n.action||p.disabled||(p.disabled=!0,p.textContent="Working\u2026",Promise.resolve(n.action()).then(()=>{o.isConnected&&d()}).catch(()=>{t()&&bt(e,t,"Action failed",{tone:"error",durationMs:5e3})}))}),o.appendChild(p)}i?e.noticeStack.appendChild(o):e.noticeStack.prepend(o);let s=n.durationMs??(n.action?8e3:2200),u=Date.now(),l=null,d=()=>{let p=o.contains(e.shadow.activeElement);l!=null&&window.clearTimeout(l),l=null,o.remove(),i?e.undoNoticeCleanups.delete(d):e.statusNoticeCleanup===d&&(e.statusNoticeCleanup=null),p&&ui(e)},c=()=>{l!=null||s<=0||(u=Date.now(),l=window.setTimeout(d,s))},f=()=>{l!=null&&(window.clearTimeout(l),l=null,s=Math.max(0,s-(Date.now()-u)))};o.addEventListener("mouseenter",f),o.addEventListener("mouseleave",c),o.addEventListener("focusin",f),o.addEventListener("focusout",c),i?e.undoNoticeCleanups.add(d):e.statusNoticeCleanup=d,c()}function Ae(e,t,r,n,i=12){let o=Math.max(i,window.innerWidth-r-i),a=Math.max(i,window.innerHeight-n-i);return{left:Math.min(Math.max(i,e),o),top:Math.min(Math.max(i,t),a)}}function ze(e,t,r={}){t.preventDefault(),t.stopPropagation();let n=e.getBoundingClientRect(),i=t.clientX-n.left,o=t.clientY-n.top,a=r.draggingClass,s=t.pointerId;try{e.setPointerCapture(s)}catch{}a&&e.classList.add(a),e.style.width=`${n.width}px`,e.style.height=`${n.height}px`;let u=(b,R)=>{let v=Ae(b,R,n.width,n.height);e.style.left=`${v.left}px`,e.style.top=`${v.top}px`,r.onMove?.(v)};u(n.left,n.top);let l=b=>{b.pointerId===s&&u(b.clientX-i,b.clientY-o)},d=!1,c=()=>{if(!d){d=!0,window.removeEventListener("pointermove",l,!0),window.removeEventListener("pointerup",f,!0),window.removeEventListener("pointercancel",f,!0);try{e.hasPointerCapture(s)&&e.releasePointerCapture(s)}catch{}a&&e.classList.remove(a),r.onEnd?.()}},f=b=>{b.pointerId===s&&c()},p=()=>c();return window.addEventListener("pointermove",l,!0),window.addEventListener("pointerup",f,!0),window.addEventListener("pointercancel",f,!0),p}var Re=new Map;function Rr(e,t){if(Re.size>=500){let r=Re.keys().next().value;r!==void 0&&Re.delete(r)}return Re.set(e,t),t}function Lr(e){let t=Re.get(e);if(t)return t;try{return Rr(e,new URL(e).hostname)}catch{return Rr(e,e.length>30?e.substring(0,30)+"\u2026":e)}}function O(e){if(e.title.trim()!=="")return e.title.trim();let t=Lr(e.url);return t!==""?t:e.url}function te(e){try{let t=new URL(e.url),r=t.pathname==="/"?"":t.pathname,n=t.search?"?...":"",i=t.hash?"#...":"";return`${t.hostname}${r}${n}${i}`}catch{return e.url}}function Le(e){let t=document.createElement("div");return t.className="wf-branch-connector",t.setAttribute("aria-hidden","true"),e.historyBacked||(t.classList.add("wf-branch-connector-inherited"),t.title="Direct-navigation boundary"),e.transition==="typed"?t.classList.add("wf-branch-connector-typed"):(e.transition==="spa"||e.transition==="fragment")&&t.classList.add("wf-branch-connector-spa"),e.historyBacked&&(t.title=e.transition),t}function Mr(e,t){let r=document.createElement("div");r.className="wf-branch-row wf-trail-tree-node",t&&r.classList.add("wf-branch-row-current");let n=document.createElement("span");n.className="wf-branch-node",n.setAttribute("aria-hidden","true"),r.appendChild(n);let i=document.createElement("div");i.className="wf-branch-entry";let o=document.createElement("span");o.className="wf-branch-entry-title",o.textContent=O(e),i.appendChild(o);let a=document.createElement("span");return a.className="wf-branch-entry-url",a.textContent=te(e),i.appendChild(a),r.appendChild(i),r}function F(e){return`${e} page${e===1?"":"s"}`}var fi=12,qe=12,Or=460,_r=640,Cr=520;function Pr(e,t){let r=null,n=null,i=null,o=null,a=null,s=(l=!1)=>{let d=a;if(o?.(),o=null,i=null,n?.classList.remove("wf-branch-row-previewed"),n=null,r){let c=r.querySelector("iframe");c&&c.removeAttribute("src"),r.remove()}r=null,a=null,l&&B(()=>d)},u=l=>{let d=t();if(!d)return;let c=d.getBoundingClientRect(),f=window.innerWidth,p=window.innerHeight,b=fi,R=Math.max(160,p-b*2),v=f-c.right-qe-b,x=c.left-qe-b,M=f>=760&&v>=Or,_=f>=760&&x>=Or;if(l.classList.remove("wf-preview-pane-bottom"),i){let T=l.getBoundingClientRect(),A=Ae(i.left,i.top,T.width||_r,T.height||Cr,b);i=A,l.style.left=`${A.left}px`,l.style.top=`${A.top}px`;return}if(l.style.width="",l.style.height="",l.style.left="",l.style.top="",M||_){let T=M&&(!_||v>=x),C=Math.min(_r,T?v:x),N=Math.min(Cr,R),S=T?c.right+qe:c.left-qe-C,I=Math.min(Math.max(b,c.top),Math.max(b,p-N-b));l.style.width=`${C}px`,l.style.height=`${N}px`,l.style.left=`${S}px`,l.style.top=`${I}px`;return}l.classList.add("wf-preview-pane-bottom");let g=Math.max(0,f-b*2),y=Math.round(p*.66),w=Math.min(Math.max(260,y),R);l.style.width=`${g}px`,l.style.height=`${w}px`,l.style.left=`${b}px`,l.style.top=`${Math.max(b,p-w-b)}px`};return{isOpen:()=>r!==null,focusedReturnTarget:()=>{if(!r)return null;let l=r.getRootNode(),d="activeElement"in l?l.activeElement:document.activeElement;return d instanceof HTMLElement&&r.contains(d)?a:null},close:s,reposition:()=>{r&&u(r)},update(l,d){if(!r||n!==l)return;let c=r.querySelector(".wf-preview-pane-title"),f=r.querySelector(".wf-preview-pane-url"),p=r.querySelector("iframe");c&&(c.textContent=O(d)),f&&(f.textContent=te(d)),p&&(p.title=`Preview: ${O(d)}`)},open(l,d,c,f){let p=e();if(!p)return;s(),l&&(l.classList.add("wf-branch-row-previewed"),n=l);let b=document.createElement("div");b.className="wf-preview-pane",b.dataset.tabtrailHitSurface="",b.setAttribute("role","dialog"),b.setAttribute("aria-modal","false");let R=document.createElement("div");R.className="wf-preview-pane-header";let v=document.createElement("div");v.className="wf-preview-pane-identity";let x=document.createElement("div");x.className="wf-preview-pane-kicker",x.textContent="Preview",v.appendChild(x);let M=document.createElement("div");M.id="tabtrail-live-preview-title",M.className="wf-preview-pane-title",M.textContent=O(d),v.appendChild(M);let _=document.createElement("div");_.id="tabtrail-live-preview-url",_.className="wf-preview-pane-url",_.textContent=te(d),v.appendChild(_),b.setAttribute("aria-labelledby",M.id),b.setAttribute("aria-describedby",_.id);let g=document.createElement("div");g.className="wf-preview-pane-actions";let y=document.createElement("span");y.className="wf-preview-pane-drag",y.textContent="\u283F",y.title="Move preview pane",y.setAttribute("aria-hidden","true"),y.addEventListener("pointerdown",C=>{r&&(r.classList.remove("wf-preview-pane-bottom"),o?.(),o=ze(r,C,{draggingClass:"wf-preview-pane-dragging",onMove:N=>{i=N},onEnd:()=>{o=null}}))});let w=document.createElement("button");w.className="wf-preview-pane-action",w.type="button",w.textContent="\u2197",w.title="Open in new tab",w.setAttribute("aria-label","Open previewed page in a new tab"),w.addEventListener("click",()=>c());let T=document.createElement("button");T.className="wf-preview-pane-close",T.type="button",T.textContent="\u2715",T.title="Close preview",T.setAttribute("aria-label","Close page preview"),T.addEventListener("click",()=>s(!0)),g.appendChild(y),g.appendChild(w),g.appendChild(T),R.appendChild(v),R.appendChild(g);let A=document.createElement("iframe");A.className="wf-preview-pane-frame",A.title=`Preview: ${O(d)}`,A.referrerPolicy="no-referrer",A.setAttribute("sandbox","allow-forms allow-popups allow-scripts"),A.src=d.url,b.appendChild(R),b.appendChild(A),p.appendChild(b),u(b),r=b,a=f,T.focus({preventScroll:!0})}}}var q=[];function Ke(e){return q.some(t=>t.id===e)}function j(){return Ke("nameDialog")||Ke("library")}function K(e,t){E(e),q.push({id:e,close:t})}function E(e){let t=q.findIndex(n=>n.id===e);if(t===-1)return;let[r]=q.splice(t,1);r.close()}function Ye(e){let t=q.findIndex(r=>r.id===e);t!==-1&&q.splice(t,1)}function Nr(){let e=q.pop();return e?(e.close(),!0):!1}function kr(){for(;q.length>0;)q.pop()?.close()}var mi={name:30,title:20,url:10},pi=1e5,Ir=typeof Intl.Segmenter=="function"?new Intl.Segmenter(void 0,{granularity:"grapheme"}):null;function gi(e){return/[\p{L}\p{N}]/u.test(e)}function hi(e){return/\p{Ll}/u.test(e)}function bi(e){return/\p{Lu}/u.test(e)}function vi(e){let t=e.codePointAt(0)??0;return/\p{M}/u.test(e)||e==="\u200D"||t>=65024&&t<=65039||t>=127995&&t<=127999}function Fr(e){if(Ir)return[...Ir.segment(e)].map(o=>({value:o.segment,start:o.index,end:o.index+o.segment.length}));let t=[],r="",n=0,i=0;for(let o of e)!(r!==""&&(vi(o)||r.endsWith("\u200D")))&&r!==""&&(t.push({value:r,start:n,end:i}),r="",n=i),r+=o,i+=o.length;return r!==""&&t.push({value:r,start:n,end:i}),t}function yi(e){return[...e.normalize("NFKD").toUpperCase().toLowerCase().normalize("NFKD")].filter(r=>!/\p{M}/u.test(r))}function Vr(e){let t=[],r="";for(let n of Fr(e)){let i=n.start===0||!gi(r)||hi(r)&&bi(n.value),o=yi(n.value),a=!0;for(let s of o)t.push({char:s,start:n.start,end:n.end,boundary:i&&a}),a=!1;r=n.value}return t}function wi(e){return Vr(e).map(t=>t.char)}function Ti(e){let t=e.trim();if(t.length>160)return null;let n=t.split(/\s+/u).filter(Boolean).map(wi);if(n.some(o=>o.length===0))return null;let i=new Set;return n.filter(o=>{let a=JSON.stringify(o);return i.has(a)?!1:(i.add(a),!0)})}function xi(e,t){let r=t[t.length-1]-t[0]+1,n=r-t.length,i=e[t[0]].boundary,o=e.length===t.length&&t[0]===0&&n===0,a=n===0,s=101e3-n*pi+(o?1200:0)+(a?240:0)+(i?40:0);return{positions:t,score:s,span:r}}function Ei(e){let t=new Array(e.length).fill(0);for(let r=1,n=0;r<e.length;r+=1){for(;n>0&&e[r]!==e[n];)n=t[n-1];e[r]===e[n]&&(n+=1),t[r]=n}return t}function Si(e,t){if(t.length===0||e.length===0)return null;let r=Ei(t),n=0,i=-1,o=Number.NEGATIVE_INFINITY;for(let u=0;u<e.length;u+=1){for(;n>0&&e[u].char!==t[n];)n=r[n-1];if(e[u].char===t[n]&&(n+=1),n!==t.length)continue;let l=u-t.length+1,c=101e3+(e.length===t.length&&l===0?1200:0)+240+(e[l].boundary?40:0);c>o&&(i=l,o=c),n=r[n-1]}if(i>=0)return{positions:Array.from({length:t.length},(l,d)=>i+d),score:o,span:t.length};let a=null,s=0;for(;s<e.length;){let u=0,l=-1;for(let f=s;f<e.length;f+=1)if(e[f].char===t[u]&&(u+=1,u===t.length)){l=f;break}if(l<0)break;let d=new Array(t.length);u=t.length-1;for(let f=l;f>=s&&u>=0;f-=1)e[f].char===t[u]&&(d[u]=f,u-=1);let c=xi(e,d);(!a||c.score>a.score||c.score===a.score&&c.span<a.span||c.score===a.score&&c.span===a.span&&c.positions[0]<a.positions[0])&&(a=c),s=d[0]+1}return a}function Ai(e,t){let r=t.map(i=>({start:e[i].start,end:e[i].end})).sort((i,o)=>i.start-o.start||i.end-o.end),n=[];for(let i of r){let o=n[n.length-1];o&&i.start<=o.end?o.end=Math.max(o.end,i.end):n.push({...i})}return n}function vt(e,t,r,n){if(t==="")return null;let i=Vr(t),o=[];for(let f of n){let p=Si(i,f);if(!p)return null;o.push(p)}let a=o.flatMap(f=>f.positions),s=i.map(f=>f.char).join(""),u=n.map(f=>f.join("")).join(" "),l=s===u,d=!l&&u!==""&&s.includes(u),c=o.reduce((f,p)=>f+p.score,0)+(l?1600:0)+(d?500:0)+mi[e];return{field:e,entryIndex:r,value:t,ranges:Ai(i,a),score:c}}function Dr(e){return e==="name"?0:e==="title"?1:2}function Ri(e,t){let r=e.entryIndex??-1,n=t.entryIndex??-1;return t.score-e.score||Dr(e.field)-Dr(t.field)||n-r||e.ranges[0].start-t.ranges[0].start}function Li(e,t){let r=[],n=vt("name",e.name,null,t);n&&r.push(n);for(let i=0;i<e.entries.length;i+=1){let o=e.entries[i],a=vt("title",o.title,i,t);a&&r.push(a);let s=vt("url",o.url,i,t);s&&r.push(s)}return r.sort(Ri),r[0]??null}function Hr(e,t){let r=e.toLowerCase(),n=t.toLowerCase();return r<n?-1:r>n?1:e<t?-1:e>t?1:0}function Mi(e,t){return e.trail.pinned!==t.trail.pinned?e.trail.pinned?-1:1:t.trail.updatedAt-e.trail.updatedAt||t.trail.createdAt-e.trail.createdAt||Hr(e.trail.name,t.trail.name)||Hr(e.trail.id,t.trail.id)||e.sourceIndex-t.sourceIndex}function yt(e,t,r=64){let n=Fr(e),i=Math.max(8,Math.floor(r));if(t.length===0||n.length<=i)return{value:e,ranges:t.map(g=>({...g}))};let o=[...t].sort((g,y)=>g.start-y.start),a=n.findIndex(g=>g.end>o[0].start),s=-1;for(let g=n.length-1;g>=0;g-=1)if(n[g].start<o[o.length-1].end){s=g;break}if(a<0||s<a)return{value:e,ranges:o.map(g=>({...g}))};let u=s-a+1,l=Math.min(8,Math.floor(i/4)),d=Math.max(0,a-l);u<=i&&(d=Math.max(d,s-i+1));let c=Math.min(n.length,d+i),f=n[d].start,p=n[c-1].end,b=f>0,R=p<e.length,v=b?"\u2026":"",x=R?"\u2026":"",M=v.length-f,_=o.filter(g=>g.end>f&&g.start<p).map(g=>({start:Math.max(f,g.start)+M,end:Math.min(p,g.end)+M}));return{value:`${v}${e.slice(f,p)}${x}`,ranges:_}}function Br(e,t){let r=Ti(t);if(r===null)return[];let n=[];for(let i=0;i<e.length;i+=1){let o=e[i];if(r.length===0){n.push({trail:o,score:0,match:null,sourceIndex:i});continue}let a=Li(o,r);a&&n.push({trail:o,score:a.score,match:a,sourceIndex:i})}return n.sort((i,o)=>r.length>0&&i.score!==o.score?o.score-i.score:Mi(i,o)),n.map(({trail:i,score:o,match:a})=>({trail:i,score:o,match:a}))}var X=10,Ge=12,de=8e3,Tt="Open \u22EF on any page in your trail, then choose Save trail up to this point in path.",wt=class{host=null;librarySession=null;libraryDragStop=null;treePreviewElement=null;pendingTrailIds=new Set;pendingTrailOwners=new Map;nextDialogId=0;renderLibraryImpl=null;setHost(t){this.host=t}setLibrarySession(t){this.librarySession=t}setLibraryDragStop(t){this.libraryDragStop=t}setTreePreviewElement(t){this.treePreviewElement=t}allocateDialogId(){return this.nextDialogId+=1,this.nextDialogId}registerRenderLibrary(t){this.renderLibraryImpl=t}renderLibrary(t){this.renderLibraryImpl?.(t)}beginTrailMutation(t){if(this.pendingTrailOwners.has(t))return null;let r=Symbol(t);return this.pendingTrailOwners.set(t,r),this.pendingTrailIds.add(t),r}finishTrailMutation(t,r){return this.pendingTrailOwners.get(t)!==r?!1:(this.pendingTrailOwners.delete(t),this.pendingTrailIds.delete(t),!0)}clear(){this.libraryDragStop?.(),this.libraryDragStop=null,this.librarySession=null,this.treePreviewElement=null,this.host=null}},m=new wt;function $r(e){m.setHost(e)}function Ur(){return m.allocateDialogId()}function Wr(e){m.registerRenderLibrary(e)}function re(e){m.renderLibrary(e)}function ue(e){e.setLiveInteractionBlocked(j())}function Q(e){let t=e.layer.getRootNode();return t instanceof ShadowRoot&&t.activeElement instanceof HTMLElement?t.activeElement:null}function xt(e){B(()=>e)}function Me(e){let t=e?.closest(".wf-library-row"),r=e?.dataset.libraryAction??e?.dataset.libraryFocusAction;return!t?.dataset.trailId||r!=="pin"&&r!=="more"?null:{trailId:t.dataset.trailId,action:r}}function Oi(e,t="more"){let r=m.librarySession;return r?[...r.list.querySelectorAll(".wf-library-row")].find(i=>i.dataset.trailId===e)?.querySelector(`[data-library-action="${t}"]`)??null:null}function zr(){let e=m.librarySession;return e?e.list.querySelector(".wf-library-row .wf-row-more:not(:disabled), .wf-library-state-action:not(:disabled)")??e.search:null}function J(e,t=!1){e&&B(()=>{let r=Oi(e.trailId,e.action);if(r&&!r.matches(":disabled"))return r;let n=r?.closest('.wf-library-row[aria-busy="true"]');return n?(n.dataset.libraryFocusAction=e.action,n):t?zr():null})}function fe(e,t){let r=Me(t);if(r){J(r,!0);return}if(t?.dataset.liveControl){e.restoreLiveFocus(t);return}xt(t)}function je(e){B(()=>m.librarySession!==e?null:zr())}function me(e,t,r){let n=m.librarySession;!n||t!==void 0&&n!==t||r!==void 0&&n.loadRequest!==r||(E("treePreview"),n.trails=z(e),n.state="ready",re(n))}function Xe(){let e=m.host;if(!e)return null;let t=e.getState();return ce(t,t.cursor)}function _i(e){let t=`${e.idPrefix}-${Ur()}`,r=`${t}-title`,n=`${t}-summary`,i=document.createElement("div");i.id=t,i.className="wf-dialog",i.dataset.tabtrailHitSurface="",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","false"),i.setAttribute("aria-labelledby",r),i.setAttribute("aria-describedby",n);let o=document.createElement("div");o.id=r,o.className="wf-dialog-title",o.textContent=e.title,i.appendChild(o);let a=document.createElement("div");a.id=n,a.className="wf-dialog-summary",a.textContent=e.summary,i.appendChild(a);let s=e.input?document.createElement("input"):null;s&&e.input&&(s.className="wf-dialog-input",s.type="text",s.maxLength=e.input.maxLength,s.value=e.input.initialValue,s.setAttribute("aria-label",e.input.ariaLabel),i.appendChild(s));let u=document.createElement("div");u.className="wf-dialog-error",u.setAttribute("role","alert"),u.hidden=!0,i.appendChild(u);let l=document.createElement("div");l.className="wf-dialog-actions";let d=document.createElement("button");d.type="button",d.className="wf-dialog-btn",d.textContent="Cancel",d.addEventListener("click",()=>E("nameDialog"));let c=document.createElement("button");c.type="button",c.className="wf-dialog-btn wf-dialog-btn-primary",c.textContent=e.submitLabel,l.appendChild(d),l.appendChild(c),i.appendChild(l);let f=b=>{i.toggleAttribute("aria-busy",b),b&&(u.hidden=!0),s&&(s.disabled=b),d.disabled=b,c.disabled=b,c.textContent=b?e.pendingLabel:e.submitLabel};return{dialog:i,input:s,cancel:d,submit:c,setPending:f,showError:b=>{u.textContent=b,u.hidden=!1,f(!1),s?.focus()}}}function qr(e){if(!m.host)return;let t=m.host,r=m.librarySession;e.closeLiveSurfaces&&t.closeLiveSurfaces(),e.closeLibrary&&(m.librarySession&&(m.librarySession.restoreFocusOnClose=!1),E("library")),E("treePreview"),E("menu"),E("nameDialog");let n=_i(e.shell),{dialog:i,input:o,submit:a}=n,s=!1,u=null,l=()=>{if(s)return;if(e.trailId&&(u=m.beginTrailMutation(e.trailId),!u)){n.showError("Another change to this trail is still in progress");return}s=!0,n.setPending(!0);let d=r?.loadRequest;u&&m.librarySession&&re(m.librarySession),e.submit(o?.value).then(c=>{if(m.host===t){if(!c.ok){i.isConnected?(n.showError(c.reason),s=!1):t.showNotice(c.reason,{tone:"error",durationMs:5e3});return}me(c.trails,r,d),i.isConnected&&E("nameDialog"),e.onSuccess(c,t,r)}}).catch(()=>{if(m.host===t){if(!i.isConnected){t.showNotice(e.failureMessage,{tone:"error",durationMs:5e3});return}n.showError(e.failureMessage),s=!1}}).finally(()=>{if(!e.trailId||!u)return;let c=m.finishTrailMutation(e.trailId,u);u=null;let f=m.librarySession;c&&f&&re(f),m.host===t&&r&&f===r&&!i.isConnected&&J({trailId:e.trailId,action:"more"},!0)})};a.addEventListener("click",l),o?.addEventListener("keydown",d=>{d.key==="Enter"&&(d.preventDefault(),l())}),t.layer.appendChild(i),K("nameDialog",()=>{i.remove(),m.host===t&&(ue(t),t.flushLiveTrailUpdates(),!(e.trailId&&s)&&(e.trailId?J({trailId:e.trailId,action:"more"},!0):fe(t,e.opener)))}),ue(t),o?(o.focus({preventScroll:!0}),o.select()):a.focus({preventScroll:!0})}function Kr(e){qr({shell:{idPrefix:"tabtrail-name-dialog",title:e.title,summary:e.summary,submitLabel:e.submitLabel,pendingLabel:e.pendingLabel,input:{initialValue:e.initialName,ariaLabel:"Trail name",maxLength:Be}},opener:e.opener,trailId:e.trailId,closeLibrary:e.closeLibrary,closeLiveSurfaces:!0,failureMessage:"Could not save changes",submit:t=>e.submit(t??""),onSuccess:(t,r)=>{r.showNotice(e.successMessage(t.trail))}})}function Yr(e,t){if(!m.host)return;let r=m.host.client;if(!e||e.length===0){m.host.showNotice("Nothing to save on this row",{tone:"error"});return}let n=e[e.length-1];Kr({title:"Name this trail",summary:`${F(e.length)} \xB7 ends at \u201C${O(n)}\u201D`,initialName:at(n),submitLabel:"Save",pendingLabel:"Saving\u2026",opener:t,closeLibrary:!0,submit:i=>r.save(e,i),successMessage:i=>`Saved \u201C${i.name}\u201D`})}function Et(e,t){if(!m.host)return;let r=m.host.getState();Yr(ce(r,e),t??Q(m.host))}function Gr(e){if(!m.host)return;let t=m.host.getState();Yr(ce(t,t.cursor),e)}function jr(e,t){if(!m.host)return;let r=m.host.client;Kr({title:"Rename saved trail",summary:`${F(e.entries.length)} \xB7 current name \u201C${e.name}\u201D`,initialName:e.name,submitLabel:"Rename",pendingLabel:"Renaming\u2026",opener:t,closeLibrary:!1,trailId:e.id,submit:n=>r.rename(e.id,n),successMessage:n=>`Renamed to \u201C${n.name}\u201D`})}function Xr(e,t){if(!m.host)return;let r=m.host.client,n=Xe();if(!n||n.length===0){m.host.showNotice("The current trail has no path to save",{tone:"error"});return}let i=le(e),o=n[n.length-1];qr({shell:{idPrefix:"tabtrail-update-dialog",title:`Update \u201C${e.name}\u201D?`,summary:`${F(e.entries.length)} ending at \u201C${i?O(i):"Unknown"}\u201D will become ${F(n.length)} ending at \u201C${O(o)}\u201D.`,submitLabel:"Replace path",pendingLabel:"Updating\u2026"},opener:t,trailId:e.id,failureMessage:"Could not update trail",submit:()=>r.replace(e.id,n,e.entries),onSuccess:(a,s,u)=>{let l=a.previousTrail;if(!l){s.showNotice("Could not read the previous trail path",{tone:"error"});return}if($e(l.entries,a.trail.entries)){s.showNotice(`\u201C${a.trail.name}\u201D already matches the current path`);return}Ci(s,a.trail,l,u)}})}function Ci(e,t,r,n){e.showNotice(`Updated \u201C${t.name}\u201D`,{actionLabel:"Undo",durationMs:de,undo:!0,action:async()=>{let i=n?.loadRequest;try{let o=await e.client.replace(t.id,r.entries,t.entries);if(m.host!==e)return;if(!o.ok){e.showNotice(o.reason,{tone:"error",durationMs:6e3});return}me(o.trails,n,i),e.showNotice(`Restored the previous path for \u201C${o.trail.name}\u201D`)}catch{if(m.host!==e)return;e.showNotice("Could not undo the update",{tone:"error",durationMs:6e3})}}})}async function Qr(e,t,r){let n=m.beginTrailMutation(t);if(!n)return null;E("menu");let i=Me(Q(e.host)),o=e.loadRequest;re(e);try{let a=await r();return a.ok?(a.trails&&me(a.trails,e,o),a):(m.host===e.host&&e.host.showNotice(a.reason||"Could not save changes",{tone:"error",durationMs:5e3}),a)}catch{return m.host===e.host&&e.host.showNotice("Could not save changes",{tone:"error",durationMs:5e3}),null}finally{let a=m.finishTrailMutation(t,n),s=m.librarySession;a&&s&&re(s),m.host===e.host&&s===e&&J(i)}}async function At(e,t){let r=await Qr(e,t.id,()=>e.host.client.setPinned(t.id,!t.pinned));m.host===e.host&&r?.ok&&e.host.showNotice(t.pinned?`Unpinned \u201C${t.name}\u201D`:`Pinned \u201C${t.name}\u201D`)}async function Jr(e,t){let r=await Qr(e,t.id,()=>e.host.client.delete(t.id));if(m.host!==e.host||!r?.ok||!("trail"in r))return;let n=r.trail;Pi(e.host,n,e),xt(e.list.querySelector(".wf-library-row .wf-row-more")??e.search)}function Pi(e,t,r){e.showNotice(`Removed \u201C${t.name}\u201D`,{actionLabel:"Undo",durationMs:de,undo:!0,action:()=>St(e,t,r)})}async function St(e,t,r){let n=r.loadRequest;try{let i=await e.client.restore(t);if(m.host!==e)return;if(!i.ok){e.showNotice(i.reason,{tone:"error",actionLabel:"Retry",durationMs:de,undo:!0,action:()=>St(e,t,r)});return}me(i.trails,r,n),e.showNotice(`Restored \u201C${i.trail.name}\u201D`)}catch{if(m.host!==e)return;e.showNotice("Could not restore trail",{tone:"error",actionLabel:"Retry",durationMs:de,undo:!0,action:()=>St(e,t,r)})}}async function Rt(e,t){if(!m.host)return;let r=m.host;try{let n=await r.client.open(e.entries,t);if(m.host!==r)return;if(!n.ok){r.showNotice(n.reason||"Could not open trail",{tone:"error"});return}t==="current"?r.hideTrail():r.showNotice("Opened in new tab")}catch{m.host===r&&r.showNotice("Could not open trail",{tone:"error"})}}function Zr(e,t){if(!m.host)return;let r=m.host;r.closeLiveSurfaces(),E("menu"),E("treePreview");let n=document.createElement("div");n.className="wf-trail-tree-preview",n.dataset.tabtrailHitSurface="",n.dataset.tabtrailWheelSurface="",n.setAttribute("role","dialog"),n.setAttribute("aria-modal","false"),n.setAttribute("aria-label",`Preview path: ${e.name}`);let i=document.createElement("div");i.className="wf-trail-tree-preview-header";let o=document.createElement("div");o.className="wf-trail-tree-preview-identity";let a=document.createElement("div");a.className="wf-trail-tree-preview-kicker",a.textContent="Preview",o.appendChild(a);let s=document.createElement("div");s.className="wf-trail-tree-preview-title",s.textContent=e.name,o.appendChild(s);let u=document.createElement("div");u.className="wf-trail-tree-preview-meta";let l=e.entries.some((f,p)=>p>0&&!f.historyBacked);u.textContent=`${F(e.entries.length)}${l?" \xB7 Contains direct-navigation steps":""}`,o.appendChild(u);let d=document.createElement("button");d.type="button",d.className="wf-trail-tree-preview-close",d.textContent="\u2715",d.title="Close preview",d.setAttribute("aria-label","Close path preview"),d.addEventListener("click",()=>E("treePreview")),i.appendChild(o),i.appendChild(d),n.appendChild(i);let c=document.createElement("div");c.className="wf-trail-tree-preview-list",c.dataset.tabtrailScrollRegion="";for(let f=0;f<e.entries.length;f+=1){let p=e.entries[f];f>0&&c.appendChild(Le(p)),c.appendChild(Mr(p,f===e.entries.length-1))}n.appendChild(c),r.layer.appendChild(n),m.setTreePreviewElement(n),Ni(n),K("treePreview",()=>{n.remove(),m.setTreePreviewElement(null),m.host===r&&fe(r,t)}),d.focus({preventScroll:!0})}function Ni(e){if(!m.host)return;let t=Ge,r=Math.min(360,Math.max(260,m.host.bar.getBoundingClientRect().width));e.style.width=`${r}px`;let i=(m.librarySession?.panel??m.host.bar).getBoundingClientRect(),o=window.innerWidth-i.right-X-t,a=i.left-X-t,s;o>=r?s=i.right+X:a>=r?s=i.left-X-r:s=Math.min(Math.max(t,i.left),Math.max(t,window.innerWidth-r-t));let u=Math.max(160,window.innerHeight-t*2);e.style.maxHeight=`${Math.min(u,420)}px`;let l=Math.min(e.getBoundingClientRect().height||280,u),d=Math.min(Math.max(t,i.top),Math.max(t,window.innerHeight-l-t)),c=Ae(s,d,r,l||200,t);e.style.left=`${c.left}px`,e.style.top=`${c.top}px`}function tn(){if(!m.host)return;let e=m.host,t=Q(e);e.closeLiveSurfaces(),E("nameDialog"),E("treePreview"),E("menu"),E("library");let r=document.createElement("div");r.id="tabtrail-saved-trails-library",r.className="wf-library-panel",r.dataset.tabtrailHitSurface="",r.dataset.tabtrailWheelSurface="",r.setAttribute("role","dialog"),r.setAttribute("aria-modal","false"),r.setAttribute("aria-label","Saved trails");let n=document.createElement("div");n.className="wf-library-header";let i=document.createElement("div");i.className="wf-library-heading";let o=document.createElement("span");o.className="wf-library-title",o.textContent="Saved trails";let a=document.createElement("span");a.className="wf-library-count",a.textContent=`0/${G}`,a.setAttribute("aria-live","polite"),a.setAttribute("aria-atomic","true"),i.appendChild(o),i.appendChild(a),n.appendChild(i);let s=document.createElement("span");s.className="wf-grip",s.textContent="\u283F",s.title="Drag to move",s.setAttribute("aria-hidden","true"),s.addEventListener("pointerdown",b=>{m.libraryDragStop?.(),m.setLibraryDragStop(ze(r,b,{draggingClass:"wf-library-panel-dragging",onEnd:()=>{m.setLibraryDragStop(null)}}))}),n.appendChild(s);let u=document.createElement("button");u.type="button",u.className="wf-library-close",u.textContent="\u2715",u.title="Close",u.setAttribute("aria-label","Close saved trails"),u.addEventListener("click",()=>E("library")),n.appendChild(u),r.appendChild(n);let l=document.createElement("div");l.className="wf-library-tools";let d=document.createElement("input");d.type="search",d.className="wf-library-search",d.placeholder="Search trails\u2026",d.setAttribute("aria-label","Fuzzy-search saved trails"),d.maxLength=160,l.appendChild(d),r.appendChild(l);let c=document.createElement("div");c.className="wf-library-list",c.dataset.tabtrailScrollRegion="",c.setAttribute("role","list"),r.appendChild(c),e.layer.appendChild(r),t?.dataset.liveControl==="library"&&(t.setAttribute("aria-expanded","true"),t.setAttribute("aria-controls",r.id));let f=b=>{let R=m.librarySession;!R||R.panel!==r||(E("treePreview"),R.loadRequest+=1,R.trails=z(b),R.state="ready",Z(R))},p={host:e,panel:r,list:c,search:d,count:a,trails:[],query:"",loadRequest:0,state:"loading",opener:t,restoreFocusOnClose:!0,unsubscribe:()=>{}};m.setLibrarySession(p),d.addEventListener("input",()=>{m.librarySession===p&&(p.query=d.value.trim(),Z(p))}),p.unsubscribe=e.client.subscribe(f),Ii(r),K("library",()=>{p.loadRequest+=1,p.unsubscribe(),m.libraryDragStop?.(),m.setLibraryDragStop(null),E("treePreview"),E("menu"),r.remove(),t?.dataset.liveControl==="library"&&(t.setAttribute("aria-expanded","false"),t.removeAttribute("aria-controls")),m.librarySession===p&&m.setLibrarySession(null),m.host===e&&(ue(e),e.flushLiveTrailUpdates(),p.restoreFocusOnClose&&fe(e,t))}),ue(e),Z(p),d.focus({preventScroll:!0}),rn(p)}async function rn(e,t=!1){let r=++e.loadRequest;e.state="loading",Z(e);try{let n=await e.host.client.load();if(m.librarySession!==e||e.loadRequest!==r||!e.panel.isConnected||m.host!==e.host)return;e.trails=n,e.state="ready",Z(e),t&&je(e)}catch{if(m.librarySession!==e||e.loadRequest!==r||!e.panel.isConnected||m.host!==e.host)return;e.state="error",Z(e),t&&je(e)}}function Z(e){if(m.librarySession!==e||!e.panel.isConnected)return;E("menu");let t=Q(e.host),r=Me(t),n=t!==null&&e.panel.contains(t),i=()=>{r?J(r,!0):n&&je(e)};if(e.count.textContent=`${e.trails.length}/${G}`,e.panel.setAttribute("aria-busy",e.state==="loading"?"true":"false"),e.search.disabled=!1,e.list.textContent="",e.state==="loading"){e.list.appendChild(Qe("Loading saved trails\u2026","status")),i();return}if(e.state==="error"){let a=Qe("Couldn\u2019t load saved trails.","alert"),s=document.createElement("button");s.type="button",s.className="wf-library-state-action",s.textContent="Retry",s.addEventListener("click",()=>void rn(e,!0)),a.appendChild(s),e.list.appendChild(a),i();return}let o=Br(e.trails,e.query);if(e.query!==""&&(e.count.textContent=`${o.length} ${o.length===1?"match":"matches"} \xB7 ${e.trails.length}/${G}`),o.length===0){if(e.query!==""){let l=Qe("No trails match your search."),d=document.createElement("button");d.type="button",d.className="wf-library-state-action",d.textContent="Clear search",d.addEventListener("click",()=>{e.search.value="",e.query="",Z(e),e.search.focus({preventScroll:!0})}),l.appendChild(d),e.list.appendChild(l),i();return}let a=Qe("No saved trails yet"),s=document.createElement("span");if(s.className="wf-library-state-copy",s.textContent=Tt,a.appendChild(s),e.host.getState().cursor>=0){let l=document.createElement("button");l.type="button",l.className="wf-library-state-action",l.textContent="Save current trail",l.addEventListener("click",()=>Gr(e.opener)),a.appendChild(l)}e.list.appendChild(a),i();return}if(e.trails.length>=G){let a=document.createElement("div");a.className="wf-library-limit",a.textContent="Saved-trail limit reached. Remove one before saving.",e.list.appendChild(a)}for(let a of o)e.list.appendChild(Di(e,a));i()}Wr(Z);function Qe(e,t){let r=document.createElement("div");r.className="wf-library-state",t&&r.setAttribute("role",t);let n=document.createElement("strong");return n.textContent=e,r.appendChild(n),r}function Ii(e){if(!m.host)return;let t=m.host.bar.getBoundingClientRect(),r=Ge,n=Math.max(0,window.innerWidth-r*2),i=Math.min(380,Math.max(280,t.width),n);e.style.width=`${i}px`,e.style.left=`${Math.min(Math.max(r,t.left),Math.max(r,window.innerWidth-i-r))}px`;let o=t.bottom+X,a=Math.min(e.getBoundingClientRect().height||340,window.innerHeight-r*2),s=o;s+a>window.innerHeight-r&&(s=Math.max(r,t.top-a-X)),e.style.top=`${s}px`,e.style.maxHeight=`${Math.max(180,window.innerHeight-s-r)}px`}function en(e,t,r){let n=0;for(let i of r){let o=Math.max(n,Math.min(t.length,i.start)),a=Math.max(o,Math.min(t.length,i.end));if(o>n&&e.appendChild(document.createTextNode(t.slice(n,o))),a>o){let s=document.createElement("mark");s.className="wf-library-search-match",s.textContent=t.slice(o,a),e.appendChild(s)}n=a}n<t.length&&e.appendChild(document.createTextNode(t.slice(n)))}function Di(e,t){let{trail:r,match:n}=t,i=le(r),o=m.pendingTrailIds.has(r.id),a=document.createElement("div");a.className="wf-library-row",a.dataset.trailId=r.id,a.setAttribute("role","listitem"),r.pinned&&a.classList.add("wf-library-row-pinned"),o&&(a.setAttribute("aria-busy","true"),a.tabIndex=-1);let s=document.createElement("div");s.className="wf-library-row-main";let u=document.createElement("span");if(u.className="wf-library-row-name",n?.field==="name"){let f=yt(r.name,n.ranges,48);en(u,f.value,f.ranges)}else u.textContent=r.name;s.appendChild(u);let l=document.createElement("span");if(l.className="wf-library-row-meta",n&&n.field!=="name"){let f=n.entryIndex===null?"":` \xB7 Page ${n.entryIndex+1}`;l.appendChild(document.createTextNode(`${F(r.entries.length)}${f} \xB7 `));let p=yt(n.value,n.ranges,52);en(l,p.value,p.ranges)}else{let f=i?O(i):"";l.textContent=f?`${F(r.entries.length)} \xB7 ${f}`:F(r.entries.length)}s.appendChild(l),a.appendChild(s);let d=document.createElement("button");d.type="button",d.className="wf-library-pin",d.dataset.libraryAction="pin",d.textContent=r.pinned?"\u2605":"\u2606",d.title=r.pinned?"Unpin trail":"Pin trail",d.setAttribute("aria-label",`${r.pinned?"Unpin":"Pin"} ${r.name}`),d.setAttribute("aria-pressed",r.pinned?"true":"false"),d.disabled=o,d.addEventListener("click",()=>void At(e,r)),a.appendChild(d);let c=document.createElement("button");return c.type="button",c.className="wf-row-more",c.dataset.libraryAction="more",c.textContent=o?"\u2026":"\u22EF",c.title="More",c.setAttribute("aria-label",`More options for ${r.name}`),c.disabled=o,c.addEventListener("click",f=>{f.preventDefault(),f.stopPropagation(),Hi(e,a,c,r,f.detail===0)}),a.appendChild(c),a.addEventListener("contextmenu",f=>{f.preventDefault();let p=Q(e.host);o||nn(e,a,c,r,!!p&&a.contains(p))}),a}var Lt=null;function Hi(e,t,r,n,i){if(Lt===r){E("menu");return}nn(e,t,r,n,i)}function nn(e,t,r,n,i){let o=le(n),a=Xe()!==null;Fi(t,r,{title:n.name,subtitle:o?.url,meta:F(n.entries.length)},[{label:"Preview",action:()=>Zr(n,r)},{label:"Open in current tab",disabled:!o,action:()=>void Rt(n,"current")},{label:"Open in new tab",disabled:!o,action:()=>void Rt(n,"new")},{label:"Update from current path",disabled:!a,action:()=>Xr(n,r)},{label:"Rename",action:()=>jr(n,r)},{label:n.pinned?"Unpin":"Pin",action:()=>void At(e,n)},{label:"Remove trail",danger:!0,action:()=>void Jr(e,n)}],i)}function Fi(e,t,r,n,i=!0){if(!m.host)return;E("menu");let o=!1;Lt=t;let a=We({layer:m.host.layer,anchor:e,trigger:t,detail:r,items:n,focusOnOpen:i,onClose:()=>{o||(o=!0,Lt=null,Ye("menu"))}});K("menu",()=>{o||a.close()})}function on(e){$r(e)}function an(){Vi(),m.clear()}function Vi(){E("menu"),E("treePreview"),E("nameDialog"),E("library")}function sn(){if(Ke("library")){E("library");return}tn()}var Bi={xPercent:50,yPercent:8},h=null,ne=null,_e=null,Je=null;function he(){return h!==null}function pe(){h&&ht()}function Ot(e){if(!h)return;let t=h.state;if(h.state=e,j()){h.liveRenderPending=!0,Ce(!0);return}if(Wi(t,e,h)){zi(t,e);return}ge()}function _t(e){if(!h)return;let t=h.options.settings.maxVisibleSegments!==e.maxVisibleSegments;if(h.options.settings=e,!!t){if(j()){h.liveRenderPending=!0,Ce(!0);return}ge()}}function cn(e,t){let{host:r,shadow:n}=hr(),i=Sr(n);r.style.pointerEvents="none";let o=document.createElement("style");o.textContent=br()+ar+sr,n.appendChild(o);let a=document.createElement("div");a.className="wf-layer",n.appendChild(a);let s=document.createElement("div");s.className="wf-bar",s.dataset.tabtrailHitSurface="",s.dataset.tabtrailWheelSurface="",s.setAttribute("role","navigation"),s.setAttribute("aria-label","Navigation trail"),a.appendChild(s);let u=document.createElement("div");u.className="wf-notice-stack",u.dataset.tabtrailWheelSurface="",u.dataset.tabtrailScrollRegion="",a.appendChild(u);let l=Pr(()=>h?.layer??null,()=>h?.bar??null);h={shadow:n,bar:s,layer:a,options:t,state:e,expanded:!1,position:t.settings.overlayPosition??Bi,noticeStack:u,statusNoticeCleanup:null,undoNoticeCleanups:new Set,liveRenderPending:!1,preview:l},on({layer:a,bar:s,client:t.savedTrailsClient??dr,getState:()=>h?.state??{entries:[],cursor:-1},showNotice:$i,hideTrail:pe,closeLiveSurfaces:()=>{E("menu"),l.close()},flushLiveTrailUpdates:()=>{queueMicrotask(()=>{!h?.liveRenderPending||j()||ge()})},restoreLiveFocus:Oe,setLiveInteractionBlocked:Ce}),dn(),ge();let d=c=>{if(!(c.key!=="Escape"||!h)&&(c.preventDefault(),c.stopImmediatePropagation(),!Nr())){if(h.preview.isOpen()){h.preview.close(!0);return}pe()}};document.addEventListener("keydown",d,!0),gr(()=>{document.removeEventListener("keydown",d,!0),ne?.(),ne=null,i(),Ar(h),kr(),h?.preview.close(),an();let c=h;h=null,_e=null,Je=null,c?.options.callbacks.onClose()})}function $i(e,t={}){if(!h)return;let r=h;bt(r,()=>h===r,e,t)}function dn(){if(!h)return;let{xPercent:e,yPercent:t}=h.position;h.bar.style.left=`${e}%`,h.bar.style.top=`${t}%`,h.preview.reposition()}function Ce(e){h&&(h.bar.inert=e,h.bar.classList.toggle("wf-bar-blocked",e),e?h.bar.setAttribute("aria-disabled","true"):h.bar.removeAttribute("aria-disabled"))}function Ze(e){return`${e.timestamp}:${e.url}`}function Ui(e){let t=e?.dataset.liveControl;return t?{control:t,entryKey:e.dataset.liveEntryKey}:null}function Oe(e){let t=Ui(e);B(()=>{if(!h)return null;let r=null;return t?(r=[...h.bar.querySelectorAll(`[data-live-control="${t.control}"]`)].find(i=>!t.entryKey||i.dataset.liveEntryKey===t.entryKey)??null,r||(r=h.bar.querySelector("[data-live-control=library]"))):e?.isConnected&&(r=e),r})}function un(e){let t=document.createElement("span");t.dataset.liveControl=e,Oe(t)}function Mt(e,t,r){let n=e.entries.length;if(r||n<=t)return e.entries.map((s,u)=>u);let i=Math.min(Math.max(1,t),n),o=new Set([0]),a=s=>{o.size>=i||s<0||s>=n||o.add(s)};a(e.cursor),a(n-1);for(let s=1;o.size<i&&s<n;s+=1)a(e.cursor-s),a(e.cursor+s);return[...o].sort((s,u)=>s-u)}function ln(e){return e.entries.map(t=>`${t.url}\0${t.historyBacked?1:0}\0${t.redirected?1:0}`).join(`
`)}function Wi(e,t,r){if(e.cursor!==t.cursor||ln(e)!==ln(t))return!1;let n=r.options.settings.maxVisibleSegments,i=Mt(e,n,r.expanded).join(","),o=Mt(t,n,r.expanded).join(",");return i===o}function fn(e){return e.entries.reduce((t,r,n)=>n>0&&!r.historyBacked?n:t,-1)}function zi(e,t){if(!h)return;h.liveRenderPending=!1,Ce(j());let r=fn(t),n=h.bar.querySelectorAll(".wf-branch-row[data-trail-index]");for(let i of n){let o=Number(i.dataset.trailIndex);if(!Number.isInteger(o)||o<0||o>=t.entries.length)continue;let a=t.entries[o],s=e.entries[o],u=o===t.cursor,l=o>t.cursor,d=o===r;i.classList.toggle("wf-branch-row-current",u),i.classList.toggle("wf-branch-row-forward",l),i.classList.toggle("wf-branch-row-fork",d),d?i.title="Direct-navigation boundary \u2014 earlier pages are outside native browser history":i.removeAttribute("title");let c=i.querySelector(".wf-branch-row-main");c&&(c.dataset.liveEntryKey=Ze(a),u?c.setAttribute("aria-current","page"):c.removeAttribute("aria-current"),d?c.setAttribute("aria-label",u?`${O(a)}. Current page. Direct-navigation boundary; earlier pages are outside native browser history.`:`${O(a)}. Direct-navigation boundary; selecting this page navigates directly.`):c.removeAttribute("aria-label"));let f=i.querySelector(".wf-row-more");if(f&&(f.dataset.liveEntryKey=Ze(a)),h.preview.update(i,a),Je===o&&ro(a),!s||s.title!==a.title||s.url!==a.url){let p=i.querySelector(".wf-branch-entry-title"),b=i.querySelector(".wf-branch-entry-url");p&&(p.textContent=O(a)),b&&(b.textContent=te(a))}}}function ge(){if(!h)return;Ce(j()),h.liveRenderPending=!1;let{bar:e,state:t,options:r}=h,{settings:n,callbacks:i}=r,o=h.shadow.activeElement instanceof HTMLElement?h.shadow.activeElement:null,a=_e,s=h.preview.focusedReturnTarget();E("menu"),h.preview.close(),o?.dataset.liveControl&&Oe(o),a&&Oe(a),s&&Oe(s),e.textContent="",e.appendChild(qi(i));let u=Ki();if(e.appendChild(u),t.entries.length===0){let f=document.createElement("span");f.className="wf-empty",f.textContent="No trail yet. Start clicking links to build one.",u.appendChild(f);return}let l=Mt(t,n.maxVisibleSegments,h.expanded),d=fn(t),c=null;for(let f of l){if(c!==null){if(f>c+1){let p=c+1;u.appendChild(Le(t.entries[p])),u.appendChild(Qi(f-c-1))}u.appendChild(Le(t.entries[f]))}u.appendChild(Zi(f,t,i,f===d)),c=f}h.expanded&&t.entries.length>n.maxVisibleSegments&&u.appendChild(Ji())}function qi(e){let t=document.createElement("div");t.className="wf-branch-header";let r=document.createElement("div");r.className="wf-header-left",r.appendChild(Gi(e)),r.appendChild(ji()),t.appendChild(r);let n=document.createElement("span");return n.className="wf-branch-title",n.textContent="In-Page Trail",t.appendChild(n),t.appendChild(Yi()),t.appendChild(Xi()),t}function Ki(){let e=document.createElement("div");return e.className="wf-branch-list",e.dataset.tabtrailScrollRegion="",e}function Yi(){let e=document.createElement("span");return e.className="wf-grip",e.textContent="\u283F",e.title="Drag to move",e.setAttribute("aria-hidden","true"),e.addEventListener("pointerdown",io),e}function Gi(e){let t=document.createElement("button");return t.className="wf-settings",t.type="button",t.textContent="\u2699",t.title="Open settings",t.setAttribute("aria-label","Open settings"),t.dataset.liveControl="settings",t.addEventListener("click",()=>e.onOpenOptions()),t}function ji(){let e=document.createElement("button");return e.className="wf-library",e.type="button",e.textContent="\u2630",e.title="Saved trails",e.setAttribute("aria-label","Saved trails"),e.setAttribute("aria-haspopup","dialog"),e.setAttribute("aria-expanded","false"),e.dataset.liveControl="library",e.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),sn()}),e}function Xi(){let e=document.createElement("button");return e.className="wf-close",e.type="button",e.textContent="\u2715",e.title="Hide (Esc)",e.setAttribute("aria-label","Hide trail"),e.dataset.liveControl="close",e.addEventListener("click",()=>pe()),e}function Qi(e){let t=document.createElement("button");return t.type="button",t.className="wf-more",t.dataset.liveControl="expand",t.textContent=`+${e} more`,t.title="Show the full trail",t.addEventListener("click",()=>{h&&(h.expanded=!0,ge(),un("collapse"))}),t}function Ji(){let e=document.createElement("button");return e.type="button",e.className="wf-more wf-more-collapse",e.dataset.liveControl="collapse",e.textContent="Show less",e.title="Collapse the trail",e.addEventListener("click",()=>{h&&(h.expanded=!1,ge(),un("expand"))}),e}function Zi(e,t,r,n){let i=t.entries[e],o=e===t.cursor,a=document.createElement("div");a.className="wf-branch-row",a.dataset.trailIndex=String(e),o&&a.classList.add("wf-branch-row-current"),e>t.cursor&&a.classList.add("wf-branch-row-forward"),n&&(a.classList.add("wf-branch-row-fork"),a.title="Direct-navigation boundary \u2014 earlier pages are outside native browser history");let s=document.createElement(o?"div":"button");o||(s.type="button"),s.className="wf-branch-row-main",s.dataset.liveControl="row-main",s.dataset.liveEntryKey=Ze(i),o&&(s.setAttribute("role","group"),s.setAttribute("aria-current","page")),n&&s.setAttribute("aria-label",o?`${O(i)}. Current page. Direct-navigation boundary; earlier pages are outside native browser history.`:`${O(i)}. Direct-navigation boundary; selecting this page navigates directly.`);let u=document.createElement("span");u.className="wf-branch-node",u.setAttribute("aria-hidden","true"),s.appendChild(u);let l=document.createElement("div");l.className="wf-branch-entry";let d=document.createElement("span");d.className="wf-branch-entry-title",d.textContent=O(i),l.appendChild(d);let c=document.createElement("span");c.className="wf-branch-entry-url",c.textContent=te(i),l.appendChild(c),s.appendChild(l),a.appendChild(s);let f=eo(a,e,i,r);return a.appendChild(f),o||s.addEventListener("click",p=>{p.preventDefault(),r.onJump(e)}),a.addEventListener("contextmenu",p=>{p.preventDefault(),p.stopPropagation();let b=h?.shadow.activeElement instanceof HTMLElement&&a.contains(h.shadow.activeElement);mn(a,e,r,f,b)}),a}function eo(e,t,r,n){let i=document.createElement("button");return i.className="wf-row-more",i.type="button",i.textContent="\u22EF",i.title="More",i.setAttribute("aria-label","More options for this page"),i.dataset.liveControl="row-more",i.dataset.liveEntryKey=Ze(r),i.addEventListener("click",o=>{o.preventDefault(),o.stopPropagation(),to(e,i,t,n,o.detail===0)}),i}function to(e,t,r,n,i){if(_e===t){E("menu");return}mn(e,r,n,t,i)}function mn(e,t,r,n,i){if(!h)return;let o=h.state.entries[t];if(!o)return;E("menu");let a=!1;_e=n,Je=t;let s=h,u=()=>h!==s?null:s.state.entries[t]??null,l=We({layer:h.layer,anchor:e,trigger:n,detail:{title:O(o),subtitle:o.url,meta:`Visited ${ut(o.timestamp,Date.now())}`},items:[{label:"Preview",action:()=>{let d=u();d&&s.preview.open(e,d,()=>r.onOpenInNewTab(t),n)}},{label:"Open in new tab",action:()=>r.onOpenInNewTab(t)},{label:"Open in new window",action:()=>r.onOpenInNewWindow(t)},{label:"Copy URL",action:()=>{let d=u();d&&no(d.url)}},{label:"Save trail up to this point in path",action:()=>Et(t,n)}],focusOnOpen:i,onClose:()=>{a||(a=!0,_e=null,Je=null,Ye("menu"))}});l.element.dataset.liveTrailIndex=String(t),K("menu",()=>{a||l.close()})}function ro(e){if(!h)return;let t=h.layer.querySelector(".wf-menu[data-live-trail-index]");if(!t)return;let r=t.querySelector(".wf-menu-detail-title"),n=t.querySelector(".wf-menu-detail-url"),i=t.querySelector(".wf-menu-detail-time");r&&(r.textContent=O(e)),n&&(n.textContent=e.url),i&&(i.textContent=`Visited ${ut(e.timestamp,Date.now())}`)}async function no(e){try{await navigator.clipboard.writeText(e);return}catch{}let t=document.createElement("textarea");t.value=e,t.style.cssText="position:fixed;opacity:0;pointer-events:none;",document.body.appendChild(t),t.select();try{document.execCommand("copy")}finally{t.remove()}}function io(e){if(!h)return;ne?.(),ne=null,e.preventDefault();let t=h,{bar:r}=t,n=e.currentTarget instanceof HTMLElement?e.currentTarget:r,i=e.pointerId;try{n.setPointerCapture(i)}catch{}let o=r.getBoundingClientRect(),a=e.clientX-(o.left+o.width/2),s=e.clientY-o.top;r.classList.add("wf-dragging");let u=p=>{if(p.pointerId!==i||h!==t)return;let b=(p.clientX-a)/window.innerWidth*100,R=(p.clientY-s)/window.innerHeight*100;t.position={xPercent:Math.min(Math.max(b,0),100),yPercent:Math.min(Math.max(R,0),96)},dn()},l=!1,d=p=>{if(!l){l=!0,window.removeEventListener("pointermove",u,!0),window.removeEventListener("pointerup",c,!0),window.removeEventListener("pointercancel",c,!0);try{n.hasPointerCapture(i)&&n.releasePointerCapture(i)}catch{}r.classList.remove("wf-dragging"),ne===f&&(ne=null),p&&h===t&&t.options.callbacks.onPositionChange(t.position)}},c=p=>{p.pointerId===i&&d(!0)},f=()=>d(!1);ne=f,window.addEventListener("pointermove",u,!0),window.addEventListener("pointerup",c,!0),window.addEventListener("pointercancel",c,!0)}var ao=15e3,so="[data-tabtrail-hit-surface]",H=null,Ne=!1,be=!1,Ct=!1,ve=null,lo=0,co=0,ie=0,ke=!1,Pt=[],Nt="",oe=!1,Ie=null,bn=or(document),ye=new Map,tt=new Set,De=new Set;function U(e){H&&H.postMessage(e)}function uo(e){for(let t of ye.values())window.clearTimeout(t.timeout),t.reject(new Error(e));ye.clear()}function k(e,t){if(!H||be)return Promise.reject(new Error("Overlay host disconnected"));let r=++lo,n={requestId:r,method:e,params:t};return new Promise((i,o)=>{let a=window.setTimeout(()=>{ye.delete(r),o(new Error("Overlay request timed out"))},ao);ye.set(r,{method:e,timeout:a,resolve:i,reject:o}),U({type:"FRAME_RPC_REQUEST",version:2,request:n})})}function kt(e,t){return e.reason||t}function Pe(e,t){return e.ok?e:{ok:!1,reason:kt(e,t)}}var fo={load:async()=>{let e=await k("SAVED_LOAD",{});if(e.ok)return e.trails;throw new Error(kt(e,"Could not load saved trails"))},subscribe:e=>(tt.add(e),()=>{tt.delete(e)}),open:(e,t)=>k("SAVED_OPEN",{path:e,mode:t}),save:async(e,t)=>Pe(await k("SAVED_SAVE",{path:e,name:t}),"Could not save trail"),rename:async(e,t)=>Pe(await k("SAVED_RENAME",{id:e,name:t}),"Could not rename trail"),replace:async(e,t,r)=>{let n=await k("SAVED_REPLACE",{id:e,path:t,expectedPath:r});return n.ok?n:{ok:!1,reason:kt(n,"Could not update trail")}},setPinned:async(e,t)=>Pe(await k("SAVED_SET_PINNED",{id:e,pinned:t}),"Could not change pinned state"),delete:async e=>Pe(await k("SAVED_DELETE",{id:e}),"Could not remove trail"),restore:async e=>Pe(await k("SAVED_RESTORE",{trail:e}),"Could not restore trail")};function vn(){return document.getElementById("ht-panel-host")?.shadowRoot??null}function mo(){let e=vn();if(!e)return[];let t=[],r=null;for(let n of e.querySelectorAll(so)){if(n.getClientRects().length===0)continue;let i=n.getBoundingClientRect();if(!Number.isFinite(i.x)||!Number.isFinite(i.y)||!Number.isFinite(i.width)||!Number.isFinite(i.height)||i.width<=0||i.height<=0)continue;let o={x:i.x,y:i.y,width:i.width,height:i.height};if(n.classList.contains("wf-notice")){if(!r)r=o;else{let a=Math.min(r.x,o.x),s=Math.min(r.y,o.y),u=Math.max(r.x+r.width,o.x+o.width),l=Math.max(r.y+r.height,o.y+o.height);r={x:a,y:s,width:u-a,height:l-s}}continue}t.push(o)}return r&&t.push(r),t}function po(e){return`${window.innerWidth}x${window.innerHeight}:`+e.map(t=>`${t.x.toFixed(2)},${t.y.toFixed(2)},${t.width.toFixed(2)},${t.height.toFixed(2)}`).join(";")}function go(e){let t=new Set,r=[];for(let n of e){let i=`${n.x}:${n.y}:${n.width}:${n.height}`;t.has(i)||(t.add(i),r.push(n))}return r}function ho(e,t){let r=new Set(e.map(i=>`${i.x}:${i.y}:${i.width}:${i.height}`)),n=new Set(t.map(i=>`${i.x}:${i.y}:${i.width}:${i.height}`));if(r.size!==n.size)return!1;for(let i of r)if(!n.has(i))return!1;return!0}function It(e){if(e.length>32){U({type:"FRAME_ERROR",version:2,reason:"Overlay produced too many interaction surfaces"});return}U({type:"FRAME_SURFACES_UPDATED",version:2,sequence:co++,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,rects:e})}function Dt(e){let t=mo(),r=po(t);if(r!==Nt){let n=go([...Pt,...t]);It(n),Pt=t,Nt=r,oe=!ho(n,t)}else(e||oe)&&(It(t),oe=!1)}function Y(e=!1){e&&(ke=!0),!(!H||be)&&(ie||(ie=requestAnimationFrame(()=>{if(ie=0,!H||be)return;let t=ke;ke=!1,Dt(t),oe&&Y(!0)})))}function pn(e=!1){e&&(ke=!1),Dt(e),oe&&Y(!0)}function bo(){Ie?.();let e=[],t=()=>Y();window.addEventListener("resize",t),window.visualViewport?.addEventListener("resize",t),e.push(()=>{window.removeEventListener("resize",t),window.visualViewport?.removeEventListener("resize",t)});let r=document.getElementById("ht-panel-host"),n=r?.shadowRoot;if(n&&typeof MutationObserver=="function"){let i=new MutationObserver(()=>Y());i.observe(n,{subtree:!0,childList:!0,attributes:!0,characterData:!0}),e.push(()=>i.disconnect())}if(r&&typeof ResizeObserver=="function"){let i=new ResizeObserver(()=>Y());i.observe(r);let o=n?.querySelector(".wf-layer");o instanceof Element&&i.observe(o),e.push(()=>i.disconnect())}Ie=()=>{for(let i of e)i();Ie=null}}function vo(){let e=document.activeElement;for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement;return e}function yo(){let e=vn();if(!e)return[];let t=["button:not(:disabled)","input:not(:disabled)","select:not(:disabled)","textarea:not(:disabled)","a[href]","[tabindex]:not([tabindex='-1'])"].join(",");return[...e.querySelectorAll(t)].filter(r=>!r.hidden&&r.getClientRects().length>0&&r.closest("[inert]")===null)}function wo(e){if(e.key!=="Tab")return;let t=yo(),r=vo();t.length===0||!(r instanceof HTMLElement)||!(e.shiftKey?r===t[0]:r===t[t.length-1])||U({type:"FRAME_FOCUS_OWNERSHIP",version:2,owned:!1})}function To(e){wo(e),!(!ve||!dt(ct(e),ve.trigger))&&(e.preventDefault(),e.stopImmediatePropagation(),k("LIVE_CLOSE",{}).catch(()=>{}))}function xo(e){!ve||!dt(ct(e),ve.trigger)||(e.preventDefault(),e.stopImmediatePropagation(),bn.arm(e.button),k("LIVE_CLOSE",{mouseButton:e.button}).catch(()=>{}))}function gn(){U({type:"FRAME_FOCUS_OWNERSHIP",version:2,owned:!0})}function Eo(){document.dispatchEvent(new KeyboardEvent("keydown",{key:"Escape",code:"Escape",bubbles:!0,cancelable:!0}))}function et(e){be||(be=!0,cancelAnimationFrame(ie),ie=0,Ie?.(),bn.dispose(),uo(e),tt.clear(),he()&&pe(),H?.close(),H=null)}function yn(e,t){if(ve=t,he()){Ot(e),_t(t),pn(!0);return}cn(e,{settings:t,savedTrailsClient:fo,callbacks:{onJump:r=>{k("LIVE_JUMP",{index:r}).catch(()=>{})},onOpenInNewTab:r=>{k("LIVE_OPEN_NEW_TAB",{index:r}).catch(()=>{})},onOpenInNewWindow:r=>{k("LIVE_OPEN_NEW_WINDOW",{index:r}).catch(()=>{})},onOpenOptions:()=>{k("LIVE_OPEN_OPTIONS",{}).catch(()=>{})},onClose:()=>{!be&&!Ct&&k("LIVE_CLOSE",{}).catch(()=>{})},onPositionChange:r=>{k("LIVE_SET_POSITION",{position:r}).catch(()=>{})}}}),bo(),pn(!0)}function hn(e,t){if(Ne)throw new Error("Overlay frame initialized twice");Ne=!0,yn(e,t)}function So(){Ct=!0;try{he()&&pe()}finally{Ct=!1}Ie?.(),cancelAnimationFrame(ie),ie=0,ke=!1,Pt=[],Nt="",oe=!1,It([])}function Ao(e){if(!er(e)){U({type:"FRAME_ERROR",version:2,reason:"Invalid overlay host message"}),et("Invalid overlay host message");return}let t=e;switch(t.type){case"HOST_INIT":try{hn(t.state,t.settings)}catch{U({type:"FRAME_ERROR",version:2,reason:"Overlay UI failed to initialize"})}return;case"HOST_SHOW":try{Ne?yn(t.state,t.settings):hn(t.state,t.settings)}catch{U({type:"FRAME_ERROR",version:2,reason:"Overlay UI failed to show"})}return;case"HOST_HIBERNATE":So();return;case"HOST_TRAIL_UPDATED":Ne&&he()&&(Ot(t.state),Y());return;case"HOST_SETTINGS_UPDATED":ve=t.settings,Ne&&he()&&(_t(t.settings),Y());return;case"HOST_SAVED_TRAILS_UPDATED":for(let r of tt)r(t.trails);Y();return;case"HOST_RPC_RESPONSE":{let r=ye.get(t.response.requestId);if(!r)return;if(r.method!==t.response.method){et("Overlay response method mismatch");return}ye.delete(t.response.requestId),window.clearTimeout(r.timeout),r.resolve(t.response.result);return}case"HOST_DISMISS_TRANSIENTS":E("menu");return;case"HOST_FOCUS_RELEASED":return;case"HOST_REQUEST_SURFACES":Dt(!0),oe&&Y(!0);return;case"HOST_ESCAPE":Eo();return;case"HOST_PING":U({type:"FRAME_PONG",version:2,heartbeatId:t.heartbeatId});return;case"HOST_SHUTDOWN":et(t.reason||"Overlay host closed");return}}function Ro(e){H=e.port;for(let t of De)t!==H&&t.close();De.clear(),window.removeEventListener("message",wn),H.addEventListener("message",t=>Ao(t.data)),H.addEventListener("messageerror",()=>et("Overlay message could not be decoded")),H.start(),document.addEventListener("focusin",gn,!0),document.addEventListener("pointerdown",gn,!0),document.addEventListener("keydown",To,!0),document.addEventListener("mousedown",xo,!0),U({type:"FRAME_READY",version:2})}function wn(e){if(e.source!==window.parent||H)return;let t=Zt(e);t&&(De.add(t.port),Ut(t.message.nonce).then(r=>{if(H||!r.ok){De.delete(t.port),t.port.close();return}Ro(t)}).catch(()=>{De.delete(t.port),t.port.close()}))}window.addEventListener("message",wn);})();
