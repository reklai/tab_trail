"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  function isReceiverUnavailableError(error) {
    const message = error instanceof Error ? error.message : String(error);
    const lowered = message.toLowerCase();
    return lowered.includes("receiving end does not exist") || lowered.includes("could not establish connection");
  }
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
        if (!isReceiverUnavailableError(error)) throw error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/tabtrailApi.ts
  async function claimOverlayFrame(nonce) {
    return sendRuntimeMessageWithRetry({
      type: "OVERLAY_FRAME_CLAIM",
      nonce
    });
  }
  async function openSavedTrail(path, mode) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_OPEN",
      path,
      mode
    });
  }
  async function saveNamedTrail(path, name) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_SAVE",
      path,
      name
    });
  }
  async function renameNamedTrail(id, name) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_RENAME",
      id,
      name
    });
  }
  async function duplicateNamedTrail(id) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_DUPLICATE",
      id
    });
  }
  async function replaceNamedTrail(id, path, expectedPath) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_REPLACE",
      id,
      path,
      expectedPath
    });
  }
  async function setNamedTrailPinned(id, pinned) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_SET_PINNED",
      id,
      pinned
    });
  }
  async function deleteNamedTrail(id) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_DELETE",
      id
    });
  }
  async function restoreNamedTrail(trail) {
    return sendRuntimeMessageWithRetry({
      type: "SAVED_TRAIL_RESTORE",
      trail
    });
  }

  // src/lib/common/contracts/overlayFrame.ts
  var OVERLAY_FRAME_PROTOCOL_VERSION = 1;
  var OVERLAY_FRAME_MAX_SURFACES = 32;
  var OVERLAY_FRAME_NONCE_PATTERN = /^[a-f0-9]{32}$/;
  var TRIGGER_KEY_CODE_PATTERN = /^(?:Key[A-Z]|Digit[0-9])$/;
  var MAX_TRAIL_ENTRIES_ON_WIRE = 100;
  var MAX_SAVED_TRAILS_ON_WIRE = 50;
  var MIN_VISIBLE_SEGMENTS = 5;
  var MAX_VISIBLE_SEGMENTS = 12;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function hasOnlyKeys(value, required, optional = []) {
    const keys = Object.keys(value);
    if (!required.every((key) => Object.prototype.hasOwnProperty.call(value, key))) return false;
    const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
    return keys.every((key) => allowed.has(key));
  }
  function isFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value);
  }
  function isNonNegativeSafeInteger(value) {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  }
  function isOptionalString(value) {
    return value === void 0 || typeof value === "string";
  }
  function isOverlayPosition(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["xPercent", "yPercent"])) return false;
    return isFiniteNumber(value.xPercent) && value.xPercent >= 0 && value.xPercent <= 100 && isFiniteNumber(value.yPercent) && value.yPercent >= 0 && value.yPercent <= 100;
  }
  var TRAIL_TRANSITIONS = /* @__PURE__ */ new Set([
    "link",
    "typed",
    "reload",
    "spa",
    "fragment",
    "form",
    "back_forward",
    "other"
  ]);
  function isTrailEntry(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, [
      "url",
      "title",
      "favIconUrl",
      "timestamp",
      "transition",
      "redirected",
      "historyBacked"
    ])) return false;
    return typeof value.url === "string" && value.url.length > 0 && typeof value.title === "string" && typeof value.favIconUrl === "string" && isFiniteNumber(value.timestamp) && typeof value.transition === "string" && TRAIL_TRANSITIONS.has(value.transition) && typeof value.redirected === "boolean" && typeof value.historyBacked === "boolean";
  }
  function isTrailEntries(value) {
    return Array.isArray(value) && value.length <= MAX_TRAIL_ENTRIES_ON_WIRE && value.every(isTrailEntry);
  }
  function isTrailState(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["entries", "cursor"])) return false;
    if (!isTrailEntries(value.entries) || !Number.isSafeInteger(value.cursor)) return false;
    const cursor = value.cursor;
    return value.entries.length === 0 ? cursor === -1 : cursor >= 0 && cursor < value.entries.length;
  }
  function isTrigger(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["modifier", "withShift", "kind", "keyCode", "mouseButton"])) return false;
    return (value.modifier === "alt" || value.modifier === "ctrl" || value.modifier === "super") && typeof value.withShift === "boolean" && (value.kind === "key" || value.kind === "mouse") && typeof value.keyCode === "string" && TRIGGER_KEY_CODE_PATTERN.test(value.keyCode) && typeof value.mouseButton === "number" && [0, 1, 2].includes(value.mouseButton);
  }
  function isSettings(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["trigger", "overlayPosition", "maxVisibleSegments"])) return false;
    return isTrigger(value.trigger) && (value.overlayPosition === null || isOverlayPosition(value.overlayPosition)) && Number.isSafeInteger(value.maxVisibleSegments) && value.maxVisibleSegments >= MIN_VISIBLE_SEGMENTS && value.maxVisibleSegments <= MAX_VISIBLE_SEGMENTS;
  }
  function isSavedTrail(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["id", "name", "pinned", "createdAt", "updatedAt", "entries"])) return false;
    return typeof value.id === "string" && value.id.length > 0 && typeof value.name === "string" && value.name.length > 0 && typeof value.pinned === "boolean" && isFiniteNumber(value.createdAt) && isFiniteNumber(value.updatedAt) && isTrailEntries(value.entries) && value.entries.length > 0;
  }
  function isSavedTrails(value) {
    return Array.isArray(value) && value.length <= MAX_SAVED_TRAILS_ON_WIRE && value.every(isSavedTrail);
  }
  function isActionResult(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["ok"], ["reason"])) return false;
    if (value.ok === true) return value.reason === void 0;
    return value.ok === false && isOptionalString(value.reason);
  }
  function isSavedTrailsLoadResult(value) {
    if (!isRecord(value) || typeof value.ok !== "boolean") return false;
    if (value.ok === false) {
      return hasOnlyKeys(value, ["ok"], ["reason"]) && isOptionalString(value.reason);
    }
    return hasOnlyKeys(value, ["ok", "trails"]) && isSavedTrails(value.trails);
  }
  function isMutationResult(value) {
    if (!isRecord(value) || typeof value.ok !== "boolean") return false;
    if (value.ok === false) {
      return hasOnlyKeys(value, ["ok"], ["reason"]) && isOptionalString(value.reason);
    }
    return hasOnlyKeys(value, ["ok", "trail", "trails"]) && isSavedTrail(value.trail) && isSavedTrails(value.trails);
  }
  function isReplaceResult(value) {
    if (!isRecord(value) || typeof value.ok !== "boolean") return false;
    if (value.ok === false) {
      return hasOnlyKeys(value, ["ok"], ["reason"]) && isOptionalString(value.reason);
    }
    return hasOnlyKeys(value, ["ok", "trail", "previousTrail", "trails"]) && isSavedTrail(value.trail) && isSavedTrail(value.previousTrail) && isSavedTrails(value.trails);
  }
  function isBaseProtocolMessage(value) {
    return isRecord(value) && typeof value.type === "string" && value.version === OVERLAY_FRAME_PROTOCOL_VERSION;
  }
  function isOverlayFrameConnectMessage(value) {
    return isBaseProtocolMessage(value) && hasOnlyKeys(value, ["type", "version", "nonce"]) && value.type === "TABTRAIL_OVERLAY_CONNECT" && typeof value.nonce === "string" && OVERLAY_FRAME_NONCE_PATTERN.test(value.nonce);
  }
  function isMessagePortLike(value) {
    if (!isRecord(value)) return false;
    return typeof value.postMessage === "function" && typeof value.start === "function" && typeof value.close === "function" && typeof value.addEventListener === "function" && typeof value.removeEventListener === "function";
  }
  function parseOverlayFrameConnectEvent(event) {
    if (!isRecord(event) || !isOverlayFrameConnectMessage(event.data)) return null;
    if (!Array.isArray(event.ports) || event.ports.length !== 1) return null;
    const port2 = event.ports[0];
    if (!isMessagePortLike(port2)) return null;
    return { message: event.data, port: port2 };
  }
  function isRpcMethod(value) {
    return typeof value === "string" && [
      "LIVE_JUMP",
      "LIVE_OPEN_NEW_TAB",
      "LIVE_OPEN_NEW_WINDOW",
      "LIVE_OPEN_OPTIONS",
      "LIVE_CLOSE",
      "LIVE_SET_POSITION",
      "SAVED_LOAD",
      "SAVED_OPEN",
      "SAVED_SAVE",
      "SAVED_RENAME",
      "SAVED_DUPLICATE",
      "SAVED_REPLACE",
      "SAVED_SET_PINNED",
      "SAVED_DELETE",
      "SAVED_RESTORE"
    ].includes(value);
  }
  function isRpcResult(method, result) {
    switch (method) {
      case "SAVED_LOAD":
        return isSavedTrailsLoadResult(result);
      case "SAVED_SAVE":
      case "SAVED_RENAME":
      case "SAVED_DUPLICATE":
      case "SAVED_SET_PINNED":
      case "SAVED_DELETE":
      case "SAVED_RESTORE":
        return isMutationResult(result);
      case "SAVED_REPLACE":
        return isReplaceResult(result);
      default:
        return isActionResult(result);
    }
  }
  function isOverlayRpcResponse(value) {
    if (!isRecord(value) || !hasOnlyKeys(value, ["requestId", "method", "result"])) return false;
    return isNonNegativeSafeInteger(value.requestId) && isRpcMethod(value.method) && isRpcResult(value.method, value.result);
  }
  function isOverlayHostToFrameMessage(value) {
    if (!isBaseProtocolMessage(value)) return false;
    switch (value.type) {
      case "HOST_INIT":
        return hasOnlyKeys(value, ["type", "version", "state", "settings"]) && isTrailState(value.state) && isSettings(value.settings);
      case "HOST_TRAIL_UPDATED":
        return hasOnlyKeys(value, ["type", "version", "state"]) && isTrailState(value.state);
      case "HOST_SETTINGS_UPDATED":
        return hasOnlyKeys(value, ["type", "version", "settings"]) && isSettings(value.settings);
      case "HOST_SAVED_TRAILS_UPDATED":
        return hasOnlyKeys(value, ["type", "version", "trails"]) && isSavedTrails(value.trails);
      case "HOST_RPC_RESPONSE":
        return hasOnlyKeys(value, ["type", "version", "response"]) && isOverlayRpcResponse(value.response);
      case "HOST_DISMISS_TRANSIENTS":
      case "HOST_ESCAPE":
      case "HOST_FOCUS_RELEASED":
      case "HOST_REQUEST_SURFACES":
        return hasOnlyKeys(value, ["type", "version"]);
      case "HOST_PING":
        return hasOnlyKeys(value, ["type", "version", "heartbeatId"]) && isNonNegativeSafeInteger(value.heartbeatId);
      case "HOST_SHUTDOWN":
        return hasOnlyKeys(value, ["type", "version"], ["reason"]) && isOptionalString(value.reason);
      default:
        return false;
    }
  }

  // src/lib/core/trail/savedTrailCore.ts
  var MAX_SAVED_TRAILS = 50;
  var SAVED_TRAIL_NAME_MAX_LENGTH = 80;
  function normalizeSavedTrailName(value) {
    if (typeof value !== "string") return "";
    return value.trim().replace(/\s+/g, " ").slice(0, SAVED_TRAIL_NAME_MAX_LENGTH);
  }
  function savedTrailNameKey(name) {
    return normalizeSavedTrailName(name).toLowerCase();
  }
  function suggestSavedTrailName(entry) {
    if (!entry) return "Saved trail";
    const title = entry.title.trim();
    if (title !== "") return normalizeSavedTrailName(title) || "Saved trail";
    try {
      const host2 = new URL(entry.url).hostname;
      return normalizeSavedTrailName(host2) || "Saved trail";
    } catch (_) {
      return "Saved trail";
    }
  }
  function savedTrailEndpoint(trail) {
    if (trail.entries.length === 0) return null;
    return trail.entries[trail.entries.length - 1];
  }
  function normalizeSavedTrailEntries(value) {
    return normalizeTrailState({
      entries: value,
      cursor: Array.isArray(value) ? value.length - 1 : -1
    }).entries;
  }
  function savedTrailEntriesEqual(left, right) {
    if (left.length !== right.length) return false;
    return left.every((entry, index) => {
      const other = right[index];
      return entry.url === other.url && entry.title === other.title && entry.favIconUrl === other.favIconUrl && entry.timestamp === other.timestamp && entry.transition === other.transition && entry.redirected === other.redirected && entry.historyBacked === other.historyBacked;
    });
  }
  function normalizeSavedTrail(value) {
    if (typeof value !== "object" || value === null) return null;
    const raw = value;
    const name = normalizeSavedTrailName(raw.name);
    if (name === "") return null;
    const id = typeof raw.id === "string" && raw.id !== "" ? raw.id : null;
    if (!id) return null;
    const entries = normalizeSavedTrailEntries(raw.entries);
    if (entries.length === 0) return null;
    const createdAt = typeof raw.createdAt === "number" && Number.isFinite(raw.createdAt) ? raw.createdAt : 0;
    const updatedAt = typeof raw.updatedAt === "number" && Number.isFinite(raw.updatedAt) ? raw.updatedAt : createdAt;
    return { id, name, pinned: raw.pinned === true, createdAt, updatedAt, entries };
  }
  function normalizeSavedTrails(value) {
    if (!Array.isArray(value)) return [];
    const seenIds = /* @__PURE__ */ new Set();
    const seenNames = /* @__PURE__ */ new Set();
    const trails = [];
    for (const item of value) {
      const trail = normalizeSavedTrail(item);
      if (!trail) continue;
      const key = savedTrailNameKey(trail.name);
      if (seenIds.has(trail.id) || seenNames.has(key)) continue;
      seenIds.add(trail.id);
      seenNames.add(key);
      trails.push(trail);
      if (trails.length >= MAX_SAVED_TRAILS) break;
    }
    return trails.sort((a, b) => b.updatedAt - a.updatedAt || b.createdAt - a.createdAt);
  }

  // src/lib/core/trail/trailCore.ts
  var TRAIL_MAX_ENTRIES = 100;
  var MODIFIER_KEYS = ["alt", "ctrl", "super"];
  function matchesToggleTrigger(event, trigger) {
    if (!event.isTrusted) return false;
    if (event.shiftKey !== trigger.withShift) return false;
    const modifierHeld = {
      alt: event.altKey,
      ctrl: event.ctrlKey,
      super: event.metaKey
    };
    for (const modifier of MODIFIER_KEYS) {
      const shouldBeHeld = modifier === trigger.modifier;
      if (modifierHeld[modifier] !== shouldBeHeld) return false;
    }
    if (trigger.kind === "key") {
      return event.type === "keydown" && event.repeat !== true && event.code === trigger.keyCode;
    }
    return event.type === "mousedown" && event.button === trigger.mouseButton;
  }
  var KNOWN_TRANSITIONS = [
    "link",
    "typed",
    "reload",
    "spa",
    "fragment",
    "form",
    "back_forward",
    "other"
  ];
  function normalizeTrailTransition(value) {
    return KNOWN_TRANSITIONS.includes(value) ? value : "other";
  }
  function formatTrailTimestamp(timestamp, now) {
    const elapsed = Math.max(0, now - timestamp);
    const seconds = Math.floor(elapsed / 1e3);
    if (seconds < 45) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${Math.max(1, minutes)}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }
  function normalizeTrailState(value) {
    if (typeof value !== "object" || value === null) {
      return { entries: [], cursor: -1 };
    }
    const raw = value;
    if (!Array.isArray(raw.entries)) return { entries: [], cursor: -1 };
    const rawEntries = raw.entries;
    const windowed = rawEntries.slice(-TRAIL_MAX_ENTRIES);
    const droppedFromFront = rawEntries.length - windowed.length;
    const rawCursor = typeof raw.cursor === "number" && Number.isInteger(raw.cursor) ? raw.cursor : rawEntries.length - 1;
    const cursorInWindow = rawCursor - droppedFromFront;
    const entries = [];
    let cursor = -1;
    for (let i = 0; i < windowed.length; i += 1) {
      const item = windowed[i];
      if (typeof item !== "object" || item === null) continue;
      const entry = item;
      if (typeof entry.url !== "string" || entry.url === "") continue;
      if (i <= cursorInWindow) cursor = entries.length;
      entries.push({
        url: entry.url,
        title: typeof entry.title === "string" ? entry.title : "",
        favIconUrl: typeof entry.favIconUrl === "string" ? entry.favIconUrl : "",
        timestamp: typeof entry.timestamp === "number" && Number.isFinite(entry.timestamp) ? entry.timestamp : 0,
        transition: normalizeTrailTransition(entry.transition),
        redirected: entry.redirected === true,
        historyBacked: entry.historyBacked !== false
      });
    }
    if (entries.length === 0) return { entries: [], cursor: -1 };
    if (cursor === -1) cursor = 0;
    return { entries, cursor };
  }
  function slicePathToIndex(state, index) {
    const { entries } = state;
    if (!Number.isInteger(index) || index < 0 || index >= entries.length) return null;
    return entries.slice(0, index + 1).map((entry) => ({ ...entry }));
  }

  // src/lib/ui/panels/breadcrumbTrail/breadcrumbTrail.css
  var breadcrumbTrail_default = '.wf-layer {\n  position: fixed;\n  inset: 0;\n  pointer-events: none;\n  overflow: hidden;\n  overscroll-behavior: none;\n}\n\n.wf-bar {\n  pointer-events: auto;\n  position: fixed;\n  transform: translateX(-50%) translateZ(0);\n  width: min(90vw, 390px);\n  max-height: min(82vh, 560px);\n  display: flex;\n  flex-direction: column;\n  overflow: visible;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  font-size: 12px;\n  line-height: 1.35;\n  user-select: none;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n  animation: wf-branch-in 0.14s ease-out;\n}\n\n.wf-branch-header {\n  min-height: 42px;\n  display: grid;\n  grid-template-columns: auto minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 10px;\n  background: #252525;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  border-radius: 8px 8px 0 0;\n}\n\n.wf-header-left {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  flex-shrink: 0;\n}\n\n.wf-settings,\n.wf-library {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  background: var(--ht-color-surface);\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  padding: 0;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n  line-height: 1;\n}\n\n.wf-settings:hover,\n.wf-library:hover {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-accent-soft);\n  border-color: var(--ht-color-accent);\n}\n\n.wf-settings:focus-visible,\n.wf-library:focus-visible,\n.wf-close:focus-visible,\n.wf-preview-pane-action:focus-visible,\n.wf-preview-pane-close:focus-visible,\n.wf-trail-tree-preview-close:focus-visible,\n.wf-notice-action:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 2px;\n}\n\n.wf-notice-stack {\n  pointer-events: none;\n  position: fixed;\n  z-index: 16;\n  left: 50%;\n  bottom: 18px;\n  transform: translateX(-50%);\n  width: min(92vw, 380px);\n  max-height: calc(100vh - 36px);\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  padding: 3px;\n  box-sizing: border-box;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n}\n\n.wf-notice {\n  pointer-events: auto;\n  width: 100%;\n  box-sizing: border-box;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  padding: 8px 10px;\n  border-radius: 6px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text-strong);\n  border: 1px solid var(--ht-color-accent);\n  box-shadow: var(--ht-shadow-overlay);\n  font-size: 11px;\n  line-height: 1.3;\n}\n\n.wf-notice-error {\n  border-color: rgba(255, 95, 87, 0.72);\n}\n\n.wf-notice-copy {\n  min-width: 0;\n}\n\n.wf-notice-action {\n  flex: 0 0 auto;\n  border: 0;\n  border-radius: 5px;\n  padding: 5px 8px;\n  background: var(--ht-color-accent);\n  color: #fff;\n  font: inherit;\n  font-weight: 700;\n  cursor: pointer;\n}\n\n.wf-notice-action:disabled {\n  cursor: wait;\n  opacity: 0.7;\n}\n\n.wf-branch-title {\n  min-width: 0;\n  color: var(--ht-color-text-title);\n  font-size: 11px;\n  font-weight: 700;\n  text-align: center;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-branch-list {\n  min-height: 0;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr);\n  gap: 0;\n  padding: 10px 10px 12px;\n  overflow-x: hidden;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n}\n\n.wf-bar.wf-dragging {\n  cursor: grabbing;\n  opacity: 0.92;\n}\n\n.wf-bar-blocked {\n  pointer-events: none;\n  background: #1a1a1a;\n}\n\n.wf-bar-blocked .wf-branch-header {\n  background: #1d1d1d;\n}\n\n.wf-bar-blocked .wf-branch-row-current {\n  color: #b8b8b8;\n  background: #202020;\n  box-shadow: inset 0 0 0 1px rgba(255,255,255,0.07);\n}\n\n.wf-bar-blocked .wf-branch-row-current .wf-branch-node {\n  background: #686868;\n  box-shadow: 0 0 0 3px rgba(255,255,255,0.04);\n}\n\n.wf-bar-blocked .wf-branch-row-current .wf-branch-entry-url {\n  color: #777;\n}\n\n@keyframes wf-branch-in {\n  from { opacity: 0; transform: translateX(-50%) translateY(-6px); }\n  to { opacity: 1; transform: translateX(-50%) translateY(0); }\n}\n\n.wf-grip {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: grab;\n  color: #ffdf8a;\n  background: rgba(254,188,46,0.16);\n  border: 1px solid rgba(254,188,46,0.36);\n  border-radius: 6px;\n  padding: 0;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-grip:hover {\n  color: #fff;\n  background: rgba(254,188,46,0.26);\n  border-color: rgba(254,188,46,0.62);\n}\n\n.wf-bar.wf-dragging .wf-grip {\n  color: #fff;\n  background: rgba(254,188,46,0.34);\n  border-color: rgba(254,188,46,0.74);\n}\n\n.wf-close {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: #ffd6d3;\n  background: rgba(255,95,87,0.14);\n  border: 1px solid rgba(255,95,87,0.3);\n  padding: 0;\n  border-radius: 6px;\n  flex-shrink: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-close:hover {\n  color: #fff;\n  background: rgba(255,95,87,0.28);\n  border-color: rgba(255,95,87,0.56);\n}\n\n.wf-empty {\n  color: var(--ht-color-text-muted);\n  padding: 4px 6px;\n  line-height: 1.45;\n}\n\n.wf-branch-row {\n  min-width: 0;\n  position: relative;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto;\n  column-gap: 4px;\n  align-items: start;\n  margin: 2px 0;\n  padding: 7px 6px 7px 6px;\n  border-radius: 7px;\n  color: #d6d6d6;\n}\n\n.wf-branch-row:hover,\n.wf-branch-row:focus-within {\n  background: var(--ht-color-hover);\n  color: var(--ht-color-text-strong);\n}\n\n.wf-branch-row-main {\n  min-width: 0;\n  display: grid;\n  grid-template-columns: 14px minmax(0, 1fr);\n  column-gap: 8px;\n  align-items: start;\n  padding: 0;\n  border: 0;\n  background: transparent;\n  color: inherit;\n  font: inherit;\n  text-align: left;\n  cursor: pointer;\n}\n\n.wf-branch-row-main:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 3px;\n  border-radius: 4px;\n}\n\n.wf-branch-row-current .wf-branch-row-main {\n  cursor: default;\n}\n\n.wf-branch-node {\n  width: 7px;\n  height: 7px;\n  margin-top: 6px;\n  border-radius: 999px;\n  background: #8f8f8f;\n  box-shadow: 0 0 0 3px rgba(255,255,255,0.05);\n}\n\n.wf-branch-row-current {\n  color: #f2f7ff;\n  font-weight: 700;\n  background: rgba(10,132,255,0.18);\n  box-shadow: inset 0 0 0 1px rgba(10,132,255,0.3);\n  cursor: default;\n}\n\n.wf-branch-row-current .wf-branch-node {\n  background: #30d158;\n  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);\n}\n\n.wf-branch-row-fork .wf-branch-node {\n  outline: 1px dashed rgba(142, 192, 255, 0.8);\n  outline-offset: 3px;\n}\n\n.wf-branch-row-current .wf-branch-entry-url {\n  color: #aacdff;\n}\n\n.wf-branch-row-previewed {\n  box-shadow: inset 3px 0 0 #ffb340, inset 0 0 0 1px rgba(255,179,64,0.24);\n}\n\n.wf-branch-row-previewed:not(.wf-branch-row-current) {\n  background: rgba(255,179,64,0.1);\n}\n\n.wf-branch-row-previewed .wf-branch-node {\n  background: #ffb340;\n  box-shadow: 0 0 0 3px rgba(255,179,64,0.18);\n}\n\n.wf-branch-row-current.wf-branch-row-previewed .wf-branch-node {\n  background: #30d158;\n  box-shadow: 0 0 0 3px rgba(48,209,88,0.2);\n}\n\n.wf-branch-row-forward {\n  opacity: 0.52;\n}\n\n.wf-branch-entry {\n  min-width: 0;\n  display: grid;\n  gap: 2px;\n}\n\n.wf-branch-entry-title {\n  min-width: 0;\n  color: inherit;\n  line-height: 1.3;\n  overflow: hidden;\n  display: -webkit-box;\n  -webkit-line-clamp: 2;\n  -webkit-box-orient: vertical;\n  word-break: break-word;\n}\n\n.wf-branch-entry-url {\n  min-width: 0;\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  line-height: 1.25;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-row-more {\n  align-self: start;\n  width: 28px;\n  height: 28px;\n  margin-top: -1px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  color: var(--ht-color-text-muted);\n  background: transparent;\n  border: 1px solid transparent;\n  border-radius: 6px;\n  padding: 0;\n  font-size: 16px;\n  font-weight: 800;\n  line-height: 1;\n}\n\n.wf-row-more:hover,\n.wf-row-more:focus-visible {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-surface);\n  border-color: var(--ht-color-border-soft);\n  outline: none;\n}\n\n.wf-branch-connector {\n  position: relative;\n  width: 20px;\n  height: 16px;\n  margin: 3px 0 3px 6px;\n  color: #838383;\n}\n\n.wf-branch-connector::before {\n  content: "";\n  position: absolute;\n  left: 6px;\n  top: 0;\n  bottom: 2px;\n  border-left: 1px solid currentColor;\n}\n\n.wf-branch-connector::after {\n  content: "";\n  position: absolute;\n  left: 3px;\n  bottom: 1px;\n  width: 6px;\n  height: 6px;\n  border-right: 1px solid currentColor;\n  border-bottom: 1px solid currentColor;\n  transform: rotate(45deg);\n}\n\n.wf-branch-connector-typed {\n  color: var(--ht-color-warning);\n}\n\n.wf-branch-connector-spa {\n  color: var(--ht-color-accent);\n}\n\n.wf-branch-connector-inherited {\n  color: #7894b5;\n  opacity: 0.65;\n}\n\n.wf-branch-connector-inherited::before {\n  border-left-style: dashed;\n}\n\n.wf-more {\n  justify-self: start;\n  padding: 3px 9px;\n  margin-left: 12px;\n  border-radius: 999px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-muted);\n  cursor: pointer;\n  font-size: 11px;\n  border: 0;\n  font-family: inherit;\n}\n\n.wf-more:hover {\n  background: var(--ht-color-surface-strong);\n  color: var(--ht-color-text-strong);\n}\n\n.wf-more:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 2px;\n}\n\n.wf-more-collapse {\n  margin-top: 4px;\n}\n\n.wf-preview-pane {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 12;\n  width: min(88vw, 640px);\n  height: min(72vh, 520px);\n  display: grid;\n  grid-template-rows: auto minmax(0, 1fr);\n  overflow: hidden;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  contain: layout style paint;\n}\n\n.wf-preview-pane-bottom {\n  border-radius: 8px 8px 0 0;\n}\n\n.wf-preview-pane-header {\n  min-width: 0;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto;\n  gap: 8px;\n  align-items: center;\n  padding: 8px 8px 8px 10px;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  background: #252525;\n}\n\n.wf-preview-pane-identity {\n  min-width: 0;\n}\n\n.wf-preview-pane-kicker {\n  color: var(--ht-color-text-title);\n  font-size: 10px;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n  margin-bottom: 2px;\n}\n\n.wf-preview-pane-title {\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n  font-weight: 700;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-preview-pane-url {\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  margin-top: 2px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-preview-pane-actions {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n}\n\n.wf-preview-pane-drag,\n.wf-preview-pane-action,\n.wf-preview-pane-close {\n  width: 22px;\n  height: 22px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  background: var(--ht-color-surface);\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  padding: 0;\n  font-size: 12px;\n  font-weight: 800;\n}\n\n.wf-preview-pane-drag {\n  cursor: grab;\n  color: #ffdf8a;\n  background: rgba(254,188,46,0.16);\n  border-color: rgba(254,188,46,0.36);\n}\n\n.wf-preview-pane-drag:hover,\n.wf-preview-pane-dragging .wf-preview-pane-drag {\n  color: #fff;\n  background: rgba(254,188,46,0.28);\n  border-color: rgba(254,188,46,0.62);\n}\n\n.wf-preview-pane-dragging {\n  opacity: 0.96;\n}\n\n.wf-preview-pane-action:hover {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-accent-soft);\n  border-color: var(--ht-color-accent);\n}\n\n.wf-preview-pane-close {\n  color: #ffd6d3;\n  background: rgba(255,95,87,0.14);\n  border-color: rgba(255,95,87,0.3);\n}\n\n.wf-preview-pane-close:hover {\n  color: #fff;\n  background: rgba(255,95,87,0.28);\n  border-color: rgba(255,95,87,0.56);\n}\n\n.wf-preview-pane-frame {\n  width: 100%;\n  height: 100%;\n  border: 0;\n  background: #fff;\n}\n\n.wf-menu {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 14;\n  width: min(320px, calc(100vw - 16px));\n  padding: 6px;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  contain: layout style paint;\n}\n\n.wf-menu-detail {\n  padding: 9px 10px;\n  margin-bottom: 6px;\n  border-radius: 6px;\n  background: var(--ht-color-surface-dim);\n  border: 1px solid var(--ht-color-border-soft);\n}\n\n.wf-menu-detail-title {\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n  font-weight: 700;\n  line-height: 1.35;\n  word-break: break-word;\n}\n\n.wf-menu-detail-url {\n  color: var(--ht-color-text-soft);\n  font-size: 11px;\n  line-height: 1.35;\n  margin-top: 4px;\n  word-break: break-all;\n}\n\n.wf-menu-detail-time {\n  color: var(--ht-color-text-muted);\n  font-size: 10px;\n  margin-top: 4px;\n}\n\n.wf-menu-actions {\n  display: grid;\n  gap: 1px;\n  padding-bottom: 2px;\n}\n\n.wf-menu-item {\n  width: 100%;\n  border: 0;\n  background: transparent;\n  padding: 6px 10px;\n  border-radius: 5px;\n  cursor: pointer;\n  color: var(--ht-color-text-soft);\n  font-family: inherit;\n  font-size: 12px;\n  text-align: left;\n}\n\n.wf-menu-item:hover,\n.wf-menu-item:focus-visible {\n  background: var(--ht-color-accent-soft);\n  color: var(--ht-color-text-strong);\n  outline: none;\n}\n\n.wf-menu-item:disabled {\n  cursor: default;\n  opacity: 0.45;\n  background: transparent;\n}\n\n.wf-menu-item-danger:not(:disabled) {\n  color: #ffb4ae;\n}\n\n.wf-menu-item-danger:not(:disabled):hover,\n.wf-menu-item-danger:not(:disabled):focus-visible {\n  background: rgba(255, 95, 87, 0.14);\n  color: #ffd6d3;\n}\n\n@media (max-width: 520px) {\n  .wf-bar {\n    width: min(96vw, 360px);\n    max-height: 78vh;\n    font-size: 11px;\n  }\n\n  .wf-branch-header {\n    min-height: 38px;\n    padding: 7px 8px;\n  }\n\n  .wf-branch-list {\n    padding: 8px;\n  }\n\n  .wf-preview-pane {\n    width: calc(100vw - 24px);\n    height: min(66vh, 520px);\n  }\n}\n';

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsPanel.css
  var savedTrailsPanel_default = '/* Saved trails library, dialogs, and path tree preview.\n   Mounted alongside the live-bar stylesheet in the overlay shadow root. */\n\n/* Name dialog (save trail up to this point) */\n.wf-dialog {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 14;\n  left: 50%;\n  top: 18%;\n  transform: translateX(-50%);\n  width: min(92vw, 320px);\n  padding: 12px;\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  display: grid;\n  gap: 8px;\n}\n\n.wf-dialog-title {\n  font-size: 12px;\n  font-weight: 700;\n  color: var(--ht-color-text-title);\n}\n\n.wf-dialog-summary {\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n  line-height: 1.35;\n}\n\n.wf-dialog-input {\n  width: 100%;\n  box-sizing: border-box;\n  padding: 7px 8px;\n  border-radius: 6px;\n  border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n}\n\n.wf-dialog-input:focus {\n  outline: none;\n  border-color: var(--ht-color-accent);\n}\n\n.wf-dialog-error {\n  font-size: 11px;\n  color: #ffb4ae;\n  line-height: 1.3;\n}\n\n.wf-dialog-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 8px;\n  margin-top: 2px;\n}\n\n.wf-dialog-btn {\n  padding: 6px 10px;\n  border-radius: 6px;\n  border: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-soft);\n  cursor: pointer;\n  font-size: 12px;\n  font-weight: 600;\n}\n\n.wf-dialog-btn:hover {\n  color: var(--ht-color-text-strong);\n  background: var(--ht-color-surface-strong);\n}\n\n.wf-dialog-btn:focus-visible,\n.wf-dialog-input:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 2px;\n}\n\n.wf-dialog-btn:disabled,\n.wf-dialog-input:disabled {\n  cursor: wait;\n  opacity: 0.65;\n}\n\n.wf-dialog-btn-primary {\n  background: var(--ht-color-accent-soft);\n  border-color: var(--ht-color-accent);\n  color: var(--ht-color-text-strong);\n}\n\n/* Saved trails library */\n.wf-library-panel {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 13;\n  box-sizing: border-box;\n  display: flex;\n  flex-direction: column;\n  min-height: 120px;\n  max-height: min(76vh, 480px);\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  overflow: hidden;\n  backface-visibility: hidden;\n  will-change: transform;\n  contain: layout style paint;\n}\n\n.wf-library-header {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto auto;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 10px;\n  background: #252525;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n}\n\n.wf-library-heading {\n  min-width: 0;\n  display: flex;\n  align-items: baseline;\n  gap: 8px;\n}\n\n.wf-library-panel-dragging {\n  opacity: 0.94;\n  cursor: grabbing;\n}\n\n.wf-library-panel-dragging .wf-grip {\n  cursor: grabbing;\n}\n\n.wf-library-title {\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.04em;\n  text-transform: uppercase;\n  color: var(--ht-color-text-title);\n}\n\n.wf-library-count {\n  color: var(--ht-color-text-muted);\n  font-size: 10px;\n  font-variant-numeric: tabular-nums;\n}\n\n.wf-library-close {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: #ffd6d3;\n  background: rgba(255, 95, 87, 0.14);\n  border: 1px solid rgba(255, 95, 87, 0.3);\n  border-radius: 6px;\n  padding: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-library-close:hover,\n.wf-library-close:focus-visible {\n  color: #fff;\n  background: rgba(255, 95, 87, 0.28);\n  outline: none;\n}\n\n.wf-library-tools {\n  display: block;\n  padding: 8px;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n  background: var(--ht-color-surface-dim);\n}\n\n.wf-library-search {\n  width: 100%;\n  min-width: 0;\n  height: 30px;\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-strong);\n  padding: 0 8px;\n  font-family: inherit;\n  font-size: 11px;\n}\n\n.wf-library-search:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 1px;\n}\n\n.wf-library-search:disabled {\n  opacity: 0.55;\n}\n\n.wf-library-list {\n  min-height: 0;\n  flex: 1;\n  overflow-x: hidden;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n  padding: 8px;\n  display: grid;\n  gap: 4px;\n  max-height: min(58vh, 350px);\n}\n\n.wf-library-state {\n  color: var(--ht-color-text-muted);\n  font-size: 11px;\n  line-height: 1.45;\n  padding: 14px 8px;\n  display: grid;\n  justify-items: start;\n  gap: 7px;\n}\n\n.wf-library-state strong {\n  color: var(--ht-color-text-strong);\n  font-size: 12px;\n}\n\n.wf-library-state-copy {\n  max-width: 32ch;\n}\n\n.wf-library-state-action {\n  border: 1px solid var(--ht-color-border-soft);\n  border-radius: 6px;\n  padding: 6px 9px;\n  background: var(--ht-color-surface);\n  color: var(--ht-color-text-strong);\n  font-family: inherit;\n  font-size: 11px;\n  cursor: pointer;\n}\n\n.wf-library-state-action:hover,\n.wf-library-state-action:focus-visible {\n  border-color: var(--ht-color-accent);\n  background: var(--ht-color-accent-soft);\n  outline: none;\n}\n\n.wf-library-limit {\n  padding: 6px 8px;\n  border-radius: 5px;\n  background: rgba(255, 179, 64, 0.1);\n  color: #ffd28a;\n  font-size: 10px;\n  line-height: 1.4;\n}\n\n.wf-library-row {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto auto;\n  align-items: start;\n  column-gap: 4px;\n  padding: 7px 4px 7px 8px;\n  border-radius: 6px;\n  border: 1px solid transparent;\n}\n\n.wf-library-row:hover,\n.wf-library-row:focus-within {\n  background: var(--ht-color-surface);\n  border-color: var(--ht-color-border-soft);\n}\n\n.wf-library-row-pinned {\n  border-color: rgba(255, 179, 64, 0.2);\n}\n\n.wf-library-row[aria-busy="true"] {\n  opacity: 0.65;\n}\n\n.wf-library-row-main {\n  min-width: 0;\n  display: grid;\n  gap: 2px;\n  border: 0;\n  background: transparent;\n  padding: 0;\n  color: inherit;\n  font-family: inherit;\n  text-align: left;\n  cursor: pointer;\n}\n\n.wf-library-row-main:focus-visible {\n  outline: 2px solid var(--ht-color-accent);\n  outline-offset: 3px;\n  border-radius: 3px;\n}\n\n.wf-library-row-name {\n  font-size: 12px;\n  font-weight: 600;\n  color: var(--ht-color-text-strong);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-library-row-meta {\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-library-search-match {\n  padding: 0;\n  border-radius: 2px;\n  background: #ffe16a;\n  color: #241d00;\n  box-shadow: 0 0 0 1px rgba(255, 225, 106, 0.28);\n}\n\n.wf-library-pin {\n  width: 28px;\n  height: 28px;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  color: var(--ht-color-text-muted);\n  background: transparent;\n  border: 1px solid transparent;\n  border-radius: 6px;\n  padding: 0;\n  font-size: 15px;\n  line-height: 1;\n}\n\n.wf-library-pin:hover,\n.wf-library-pin:focus-visible,\n.wf-library-pin[aria-pressed="true"] {\n  color: #ffd28a;\n  background: rgba(255, 179, 64, 0.12);\n  border-color: rgba(255, 179, 64, 0.3);\n  outline: none;\n}\n\n/* Saved trail path tree preview (node list, not page iframe) */\n.wf-trail-tree-preview {\n  pointer-events: auto;\n  position: fixed;\n  z-index: 14;\n  display: flex;\n  flex-direction: column;\n  min-height: 120px;\n  max-height: min(70vh, 420px);\n  border-radius: 8px;\n  background: var(--ht-color-bg-elevated);\n  color: var(--ht-color-text);\n  border: 1px solid var(--ht-color-border);\n  box-shadow: var(--ht-shadow-overlay);\n  overflow: hidden;\n}\n\n.wf-trail-tree-preview-header {\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto;\n  align-items: start;\n  gap: 8px;\n  padding: 8px 10px;\n  background: #252525;\n  border-bottom: 1px solid var(--ht-color-border-soft);\n}\n\n.wf-trail-tree-preview-identity {\n  min-width: 0;\n  display: grid;\n  gap: 2px;\n}\n\n.wf-trail-tree-preview-kicker {\n  font-size: 10px;\n  font-weight: 700;\n  letter-spacing: 0.04em;\n  text-transform: uppercase;\n  color: var(--ht-color-text-muted);\n}\n\n.wf-trail-tree-preview-title {\n  font-size: 12px;\n  font-weight: 700;\n  color: var(--ht-color-text-title);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.wf-trail-tree-preview-meta {\n  font-size: 11px;\n  color: var(--ht-color-text-muted);\n}\n\n.wf-trail-tree-preview-close {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  cursor: pointer;\n  color: #ffd6d3;\n  background: rgba(255, 95, 87, 0.14);\n  border: 1px solid rgba(255, 95, 87, 0.3);\n  border-radius: 6px;\n  padding: 0;\n  font-size: 13px;\n  font-weight: 800;\n}\n\n.wf-trail-tree-preview-close:hover {\n  color: #fff;\n  background: rgba(255, 95, 87, 0.28);\n}\n\n.wf-trail-tree-preview-list {\n  min-height: 0;\n  flex: 1;\n  overflow-x: hidden;\n  overflow-y: auto;\n  overscroll-behavior: contain;\n  padding: 10px;\n  display: grid;\n  gap: 0;\n}\n\n.wf-trail-tree-node {\n  cursor: default;\n  grid-template-columns: 14px minmax(0, 1fr);\n}\n\n.wf-trail-tree-node:hover {\n  background: transparent;\n  border-color: transparent;\n}\n\n@media (max-width: 520px) {\n  .wf-library-panel {\n    max-height: min(66vh, 380px);\n  }\n\n  .wf-library-list {\n    max-height: min(48vh, 280px);\n  }\n\n  .wf-trail-tree-preview {\n    max-height: min(66vh, 380px);\n  }\n\n  .wf-dialog {\n    top: 12%;\n    width: min(94vw, 320px);\n  }\n}\n';

  // src/lib/adapters/runtime/savedTrailsClient.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/tabtrail.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());
  var TABTRAIL_STORAGE_KEYS = {
    settings: "tabtrailSettings",
    // Durable named path snapshots (library). Distinct from session trail mirrors.
    savedTrails: "tabtrailSavedTrails"
  };

  // src/lib/adapters/storage/savedTrailsStore.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var mutationTail = Promise.resolve();
  async function loadSavedTrails() {
    const data = await import_webextension_polyfill3.default.storage.local.get(TABTRAIL_STORAGE_KEYS.savedTrails);
    return normalizeSavedTrails(data[TABTRAIL_STORAGE_KEYS.savedTrails]);
  }

  // src/lib/adapters/runtime/savedTrailsClient.ts
  function subscribeToSavedTrails(onChanged) {
    const storageChanged = (changes, areaName) => {
      if (areaName !== "local") return;
      const savedChange = changes[TABTRAIL_STORAGE_KEYS.savedTrails];
      if (!savedChange) return;
      onChanged(normalizeSavedTrails(savedChange.newValue));
    };
    import_webextension_polyfill4.default.storage.onChanged.addListener(storageChanged);
    return () => import_webextension_polyfill4.default.storage.onChanged.removeListener(storageChanged);
  }
  var browserSavedTrailsClient = {
    load: loadSavedTrails,
    subscribe: subscribeToSavedTrails,
    open: openSavedTrail,
    save: saveNamedTrail,
    rename: renameNamedTrail,
    duplicate: duplicateNamedTrail,
    replace: replaceNamedTrail,
    setPinned: setNamedTrailPinned,
    delete: deleteNamedTrail,
    restore: restoreNamedTrail
  };

  // src/lib/common/utils/panelHost.ts
  var activePanelCleanup = null;
  var activePanelFailSafeCleanup = null;
  function invokeCleanupSafely(label, cleanup) {
    if (!cleanup) return;
    try {
      cleanup();
    } catch (error) {
      console.error(`[TabTrail] ${label}:`, error);
    }
  }
  function cleanupPanelFailSafe() {
    const cleanup = activePanelFailSafeCleanup;
    activePanelFailSafeCleanup = null;
    invokeCleanupSafely("Panel fail-safe cleanup failed", cleanup);
  }
  function handlePanelRuntimeFault(label, reason) {
    if (!document.getElementById("ht-panel-host")) return;
    console.error(`[TabTrail] ${label}; dismissing panel.`, reason);
    dismissPanel();
  }
  var EXTENSION_ORIGIN_PATTERN = /(?:chrome|moz|safari-web)-extension:\/\/[^/\s)]+/i;
  function extensionOriginIn(value) {
    return value.match(EXTENSION_ORIGIN_PATTERN)?.[0] ?? null;
  }
  var PANEL_EXTENSION_ORIGIN = extensionOriginIn(new Error().stack ?? "");
  function valueLooksExtensionScoped(value) {
    if (PANEL_EXTENSION_ORIGIN) return value.includes(PANEL_EXTENSION_ORIGIN);
    return EXTENSION_ORIGIN_PATTERN.test(value);
  }
  function reasonLooksExtensionScoped(reason) {
    if (!reason) return false;
    if (typeof reason === "string") return valueLooksExtensionScoped(reason);
    if (typeof reason === "object") {
      const maybeError = reason;
      if (typeof maybeError.stack === "string" && valueLooksExtensionScoped(maybeError.stack)) {
        return true;
      }
      if (typeof maybeError.message === "string" && valueLooksExtensionScoped(maybeError.message)) {
        return true;
      }
    }
    return false;
  }
  function isPanelRuntimeFaultFromExtension(event) {
    if (typeof event.filename === "string" && valueLooksExtensionScoped(event.filename)) {
      return true;
    }
    if (reasonLooksExtensionScoped(event.error)) return true;
    return reasonLooksExtensionScoped(event.message);
  }
  function registerPanelCleanup(fn) {
    activePanelCleanup = fn;
  }
  function createPanelHost() {
    if (activePanelCleanup) {
      const cleanup = activePanelCleanup;
      activePanelCleanup = null;
      invokeCleanupSafely("Panel cleanup failed while opening a new panel", cleanup);
    }
    cleanupPanelFailSafe();
    const existing = document.getElementById("ht-panel-host");
    if (existing) existing.remove();
    const host2 = document.createElement("div");
    host2.id = "ht-panel-host";
    host2.style.cssText = "position:fixed;inset:0;z-index:2147483647;pointer-events:auto;overflow:hidden;overscroll-behavior:none;isolation:isolate;";
    const shadow = host2.attachShadow({ mode: "open" });
    document.body.appendChild(host2);
    const onError = (event) => {
      if (!isPanelRuntimeFaultFromExtension(event)) return;
      handlePanelRuntimeFault("Panel runtime error", event.error || event.message);
    };
    const onUnhandledRejection = (event) => {
      if (!reasonLooksExtensionScoped(event.reason)) return;
      handlePanelRuntimeFault("Panel unhandled rejection", event.reason);
    };
    let lastAnimationFrameAt = performance.now();
    let frameProbeId = 0;
    const frameProbe = (ts) => {
      lastAnimationFrameAt = ts;
      frameProbeId = requestAnimationFrame(frameProbe);
    };
    frameProbeId = requestAnimationFrame(frameProbe);
    const watchdogIntervalId = window.setInterval(() => {
      if (!document.getElementById("ht-panel-host")) return;
      if (document.visibilityState !== "visible") return;
      const gapMs = performance.now() - lastAnimationFrameAt;
      if (gapMs > 3e3) {
        handlePanelRuntimeFault("Panel watchdog detected UI stall", { gapMs });
      }
    }, 1e3);
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onUnhandledRejection);
    activePanelFailSafeCleanup = () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onUnhandledRejection);
      cancelAnimationFrame(frameProbeId);
      window.clearInterval(watchdogIntervalId);
    };
    return { host: host2, shadow };
  }
  function removePanelHost() {
    cleanupPanelFailSafe();
    const host2 = document.getElementById("ht-panel-host");
    if (host2) host2.remove();
    activePanelCleanup = null;
  }
  function dismissPanel() {
    const cleanup = activePanelCleanup;
    activePanelCleanup = null;
    invokeCleanupSafely("Panel cleanup failed during dismiss", cleanup);
    removePanelHost();
  }
  function getBaseStyles() {
    return `
    * { margin: 0; padding: 0; box-sizing: border-box; }

    :host {
      all: initial;
      --ht-font-mono: 'SF Mono', 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
      --ht-color-bg: #1e1e1e;
      --ht-color-bg-elevated: #252525;
      --ht-color-bg-soft: #3a3a3c;
      --ht-color-bg-detail-focus: #1a2230;
      --ht-color-bg-detail-focus-header: #1e2a3a;
      --ht-color-bg-code: #1a1a1a;
      --ht-color-text: #e0e0e0;
      --ht-color-text-soft: #c0c0c0;
      --ht-color-text-muted: #808080;
      --ht-color-text-title: #a0a0a0;
      --ht-color-text-detail-focus: #a0c0e0;
      --ht-color-text-dim: #666;
      --ht-color-text-faint: #555;
      --ht-color-text-strong: #fff;
      --ht-color-accent: #0a84ff;
      --ht-color-accent-soft: rgba(10,132,255,0.1);
      --ht-color-accent-active: rgba(10,132,255,0.15);
      --ht-color-accent-soft-strong: rgba(10,132,255,0.12);
      --ht-color-accent-soft-faint: rgba(10,132,255,0.08);
      --ht-color-accent-alt: #af82ff;
      --ht-color-accent-alt-soft: rgba(175,130,255,0.15);
      --ht-color-success: #32d74b;
      --ht-color-tree-cursor: #4ec970;
      --ht-color-tree-cursor-bg: rgba(78,201,112,0.15);
      --ht-color-tree-cursor-bg-soft: rgba(78,201,112,0.18);
      --ht-color-tree-cursor-bg-strong: rgba(78,201,112,0.20);
      --ht-color-danger: #ff5f57;
      --ht-color-warning: #febc2e;
      --ht-color-mark-bg: #f9d45c;
      --ht-color-mark-fg: #1e1e1e;
      --ht-color-border: rgba(255,255,255,0.1);
      --ht-color-border-soft: rgba(255,255,255,0.06);
      --ht-color-border-faint: rgba(255,255,255,0.04);
      --ht-color-border-ultra-faint: rgba(255,255,255,0.03);
      --ht-color-hover: rgba(255,255,255,0.06);
      --ht-color-focus-active: rgba(255,255,255,0.13);
      --ht-color-surface: rgba(255,255,255,0.08);
      --ht-color-surface-dim: rgba(255,255,255,0.04);
      --ht-color-surface-strong: rgba(255,255,255,0.15);
      --ht-shadow-overlay: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.05);
      --ht-radius: 10px;
      --ht-input-row-pad-y: 8px;
      --ht-input-row-pad-x: 14px;
      --ht-input-row-pad-x-compact: 10px;
      --ht-input-prompt-gap: 8px;
      --ht-input-prompt-size: 14px;
      --ht-input-prompt-weight: 600;
      --ht-input-font-size: 13px;
      --ht-input-caret-color: var(--ht-color-text-strong);
      --ht-pane-header-pad-y: 5px;
      --ht-pane-header-pad-x: 14px;
      --ht-pane-header-font-size: 11px;
      --ht-pane-header-weight: 500;
      font-family: var(--ht-font-mono);
      font-size: 13px;
      color: var(--ht-color-text);
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
    }

    .ht-backdrop {
      position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
      width: 100dvw; height: 100dvh;
      background: rgba(0, 0, 0, 0.55);
    }

    /* Keep every overlay shell truly centered, even if panel-specific
       rules regress or are partially overridden. */
    .ht-help-container {
      position: fixed !important;
      top: 50% !important;
      left: 50% !important;
      transform: translate(-50%, -50%) !important;
      margin: 0 !important;
    }

    .ht-titlebar {
      display: flex; align-items: center;
      padding: 10px 14px;
      background: var(--ht-color-bg-soft);
      border-bottom: 1px solid var(--ht-color-border-soft);
      border-radius: var(--ht-radius) var(--ht-radius) 0 0;
      user-select: none;
    }
    .ht-traffic-lights {
      display: flex; gap: 7px; margin-right: 14px; flex-shrink: 0;
    }
    .ht-dot {
      width: 12px; height: 12px; border-radius: 50%;
      cursor: pointer; border: none;
      transition: filter 0.15s;
    }
    .ht-dot:hover { filter: brightness(1.2); }
    .ht-dot-close { background: var(--ht-color-danger); }
    .ht-titlebar-text {
      flex: 1; text-align: center; font-size: 12px;
      color: var(--ht-color-text-title); font-weight: 500;
    }

    /* Reusable UI primitives (input rows + pane headers) for panel consistency */
    .ht-ui-input-wrap {
      display: flex;
      align-items: center;
      padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x);
      border-bottom: 1px solid var(--ht-color-border-soft);
      background: var(--ht-color-bg-elevated);
    }
    .ht-ui-input-prompt {
      color: var(--ht-color-accent);
      margin-right: var(--ht-input-prompt-gap);
      font-weight: var(--ht-input-prompt-weight);
      font-size: var(--ht-input-prompt-size);
    }
    .ht-ui-input-field {
      flex: 1;
      background: transparent;
      border: none;
      outline: none;
      color: var(--ht-color-text);
      font-family: inherit;
      font-size: var(--ht-input-font-size);
      caret-color: var(--ht-input-caret-color);
    }
    input,
    textarea {
      user-select: text;
      -webkit-user-select: text;
    }
    .ht-ui-input-field::placeholder {
      color: var(--ht-color-text-dim);
    }
    .ht-ui-pane-header {
      padding: var(--ht-pane-header-pad-y) var(--ht-pane-header-pad-x);
      font-size: var(--ht-pane-header-font-size);
      color: var(--ht-color-text-muted);
      background: var(--ht-color-bg-elevated);
      border-bottom: 1px solid var(--ht-color-border-faint);
      font-weight: var(--ht-pane-header-weight);
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .ht-ui-pane-header-text {
      flex: 1;
    }
    .ht-ui-pane-header-meta {
      font-size: 10px;
      color: var(--ht-color-text-dim);
      flex-shrink: 0;
    }

    .ht-vim-badge {
      font-size: 9px; font-weight: 700; letter-spacing: 0.5px;
      padding: 2px 6px; border-radius: 4px;
      text-transform: uppercase; flex-shrink: 0;
      line-height: 1; margin-left: 8px;
    }
    .ht-vim-badge.on {
      background: var(--ht-color-success); color: #1a1a1a;
    }
    .ht-vim-badge.off {
      background: var(--ht-color-surface); color: var(--ht-color-text-dim);
    }

    .ht-footer {
      display: flex; gap: 16px; padding: 8px 14px;
      background: var(--ht-color-bg-elevated); border-top: 1px solid var(--ht-color-border-soft);
      font-size: 11px; color: var(--ht-color-text-muted); flex-wrap: wrap;
      border-radius: 0 0 var(--ht-radius) var(--ht-radius); justify-content: center;
    }
    .ht-footer-row {
      display: flex; gap: 8px; justify-content: center; width: 100%; flex-wrap: wrap;
      align-items: center;
    }
    .ht-footer-hint {
      display: inline-flex;
      align-items: baseline;
      gap: 4px;
      white-space: nowrap;
      color: var(--ht-color-text-muted);
    }
    .ht-footer-key {
      color: var(--ht-color-text-soft);
      font-weight: 700;
    }
    .ht-footer-sep {
      color: var(--ht-color-text-dim);
      font-weight: 600;
    }

    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.25); }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
      }
    }

    @media (max-width: 520px), (max-height: 560px) {
      .ht-ui-input-wrap {
        padding: var(--ht-input-row-pad-y) var(--ht-input-row-pad-x-compact);
      }
    }
  `;
  }

  // src/lib/ui/panels/breadcrumbTrail/contextMenu.ts
  var nextMenuId = 0;
  function showContextMenu(options) {
    const menuId = `tabtrail-context-menu-${++nextMenuId}`;
    const menu = document.createElement("div");
    menu.id = menuId;
    menu.className = "wf-menu";
    menu.dataset.tabtrailHitSurface = "";
    menu.setAttribute("role", "menu");
    menu.tabIndex = -1;
    const detail = document.createElement("div");
    detail.className = "wf-menu-detail";
    detail.setAttribute("role", "presentation");
    const title = document.createElement("div");
    title.id = `${menuId}-title`;
    title.className = "wf-menu-detail-title";
    title.textContent = options.detail.title;
    detail.appendChild(title);
    menu.setAttribute("aria-labelledby", title.id);
    const descriptionIds = [];
    if (options.detail.subtitle) {
      const subtitle = document.createElement("div");
      subtitle.id = `${menuId}-subtitle`;
      subtitle.className = "wf-menu-detail-url";
      subtitle.textContent = options.detail.subtitle;
      detail.appendChild(subtitle);
      descriptionIds.push(subtitle.id);
    }
    if (options.detail.meta) {
      const meta = document.createElement("div");
      meta.id = `${menuId}-meta`;
      meta.className = "wf-menu-detail-time";
      meta.textContent = options.detail.meta;
      detail.appendChild(meta);
      descriptionIds.push(meta.id);
    }
    if (descriptionIds.length > 0) {
      menu.setAttribute("aria-describedby", descriptionIds.join(" "));
    }
    menu.appendChild(detail);
    const actions = document.createElement("div");
    actions.className = "wf-menu-actions";
    actions.setAttribute("role", "presentation");
    const itemButtons = [];
    for (const item of options.items) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "wf-menu-item";
      row.setAttribute("role", "menuitem");
      row.textContent = item.label;
      row.disabled = item.disabled === true;
      row.tabIndex = -1;
      if (item.danger) {
        row.classList.add("wf-menu-item-danger");
        row.dataset.danger = "true";
      }
      row.addEventListener("click", (event) => {
        event.stopPropagation();
        closeMenu(event.detail === 0);
        item.action();
      });
      actions.appendChild(row);
      itemButtons.push(row);
    }
    menu.appendChild(actions);
    options.layer.appendChild(menu);
    positionPopover(menu, options.anchor);
    if (options.trigger) {
      options.trigger.setAttribute("aria-haspopup", "menu");
      options.trigger.setAttribute("aria-expanded", "true");
      options.trigger.setAttribute("aria-controls", menuId);
    }
    let closed = false;
    const closeMenu = (restoreFocus2) => {
      if (closed) return;
      closed = true;
      document.removeEventListener("pointerdown", onOutsidePointer, true);
      menu.remove();
      if (options.trigger) {
        options.trigger.setAttribute("aria-expanded", "false");
        options.trigger.removeAttribute("aria-controls");
      }
      try {
        options.onClose();
      } finally {
        if (restoreFocus2 && options.trigger?.isConnected && !options.trigger.matches(":disabled")) {
          options.trigger.focus({ preventScroll: true });
        }
      }
    };
    const onOutsidePointer = (event) => {
      const path = event.composedPath();
      if (path.includes(menu)) return;
      if (options.trigger && path.includes(options.trigger)) return;
      closeMenu(false);
    };
    document.addEventListener("pointerdown", onOutsidePointer, true);
    const enabledItems = () => itemButtons.filter((item) => !item.disabled);
    const focusItem = (item) => {
      for (const candidate of itemButtons) candidate.tabIndex = candidate === item ? 0 : -1;
      item.focus({ preventScroll: true });
    };
    menu.addEventListener("keydown", (event) => {
      const items = enabledItems();
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        closeMenu(true);
        return;
      }
      if (event.key === "Tab") {
        closeMenu(false);
        return;
      }
      if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key) || items.length === 0) {
        return;
      }
      event.preventDefault();
      event.stopPropagation();
      const currentIndex = items.indexOf(event.target);
      let nextIndex;
      if (event.key === "Home") {
        nextIndex = 0;
      } else if (event.key === "End") {
        nextIndex = items.length - 1;
      } else if (event.key === "ArrowDown") {
        nextIndex = currentIndex < 0 ? 0 : (currentIndex + 1) % items.length;
      } else {
        nextIndex = currentIndex < 0 ? items.length - 1 : (currentIndex - 1 + items.length) % items.length;
      }
      const next = items[nextIndex];
      if (next) focusItem(next);
    });
    const firstItem = enabledItems()[0];
    if (options.focusOnOpen !== false) {
      if (firstItem) focusItem(firstItem);
      else menu.focus({ preventScroll: true });
    }
    const menuHasFocus = () => {
      const root = menu.getRootNode();
      const active = "activeElement" in root ? root.activeElement : document.activeElement;
      return active instanceof HTMLElement && menu.contains(active);
    };
    return { element: menu, close: () => closeMenu(menuHasFocus()) };
  }
  function positionPopover(popover, anchor) {
    const anchorRect = anchor.getBoundingClientRect();
    popover.style.left = "0px";
    popover.style.top = "0px";
    const popoverRect = popover.getBoundingClientRect();
    const width = popoverRect.width || 240;
    const left = Math.min(
      Math.max(8, anchorRect.left),
      Math.max(8, window.innerWidth - width - 8)
    );
    let top = anchorRect.bottom + 6;
    if (top + popoverRect.height > window.innerHeight - 8) {
      top = Math.max(8, anchorRect.top - popoverRect.height - 6);
    }
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  }

  // src/lib/ui/panels/breadcrumbTrail/freePixelDrag.ts
  function clampInViewport(left, top, width, height, margin = 12) {
    const maxLeft = Math.max(margin, window.innerWidth - width - margin);
    const maxTop = Math.max(margin, window.innerHeight - height - margin);
    return {
      left: Math.min(Math.max(margin, left), maxLeft),
      top: Math.min(Math.max(margin, top), maxTop)
    };
  }
  function startFreePixelDrag(element, event, options = {}) {
    event.preventDefault();
    event.stopPropagation();
    const rect = element.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    const draggingClass = options.draggingClass;
    const pointerId = event.pointerId;
    try {
      element.setPointerCapture(pointerId);
    } catch (_) {
    }
    if (draggingClass) element.classList.add(draggingClass);
    element.style.width = `${rect.width}px`;
    element.style.height = `${rect.height}px`;
    const apply = (left, top) => {
      const position = clampInViewport(left, top, rect.width, rect.height);
      element.style.left = `${position.left}px`;
      element.style.top = `${position.top}px`;
      options.onMove?.(position);
    };
    apply(rect.left, rect.top);
    const move = (moveEvent) => {
      if (moveEvent.pointerId !== pointerId) return;
      apply(moveEvent.clientX - offsetX, moveEvent.clientY - offsetY);
    };
    let stopped = false;
    const finish = () => {
      if (stopped) return;
      stopped = true;
      window.removeEventListener("pointermove", move, true);
      window.removeEventListener("pointerup", end, true);
      window.removeEventListener("pointercancel", end, true);
      try {
        if (element.hasPointerCapture(pointerId)) element.releasePointerCapture(pointerId);
      } catch (_) {
      }
      if (draggingClass) element.classList.remove(draggingClass);
      options.onEnd?.();
    };
    const end = (endEvent) => {
      if (endEvent.pointerId === pointerId) finish();
    };
    const stop = () => finish();
    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", end, true);
    window.addEventListener("pointercancel", end, true);
    return stop;
  }

  // src/lib/ui/panels/breadcrumbTrail/focusRestore.ts
  function scheduleFocusWhenIdle(resolve) {
    queueMicrotask(() => {
      const target = resolve();
      if (!target?.isConnected || target.matches(":disabled") || target.inert || target.closest("[inert]") !== null) return;
      const root = target.getRootNode();
      const rootActive = "activeElement" in root ? root.activeElement : null;
      if (rootActive === target) return;
      const ownerDocument = target.ownerDocument;
      const shadowHost = "host" in root ? root.host : null;
      const hasMeaningfulFocus = (active) => active instanceof HTMLElement && active.isConnected && active !== ownerDocument.body && active !== ownerDocument.documentElement && active !== shadowHost;
      if (hasMeaningfulFocus(rootActive) || hasMeaningfulFocus(ownerDocument.activeElement)) return;
      target.focus({ preventScroll: true });
    });
  }

  // src/lib/ui/panels/breadcrumbTrail/interactionShield.ts
  var CONTAINED_EVENT_TYPES = [
    "keydown",
    "keyup",
    "keypress",
    "beforeinput",
    "input",
    "change",
    "compositionstart",
    "compositionupdate",
    "compositionend",
    "focusin",
    "focusout",
    "copy",
    "cut",
    "paste",
    "pointerdown",
    "pointerup",
    "pointermove",
    "pointercancel",
    "pointerover",
    "pointerout",
    "pointerenter",
    "pointerleave",
    "mousedown",
    "mouseup",
    "mousemove",
    "mouseover",
    "mouseout",
    "mouseenter",
    "mouseleave",
    "click",
    "dblclick",
    "auxclick",
    "contextmenu",
    "touchstart",
    "touchmove",
    "touchend",
    "touchcancel",
    "drag",
    "dragstart",
    "dragend",
    "dragenter",
    "dragleave",
    "dragover",
    "drop"
  ];
  var SCROLL_REGION_SELECTOR = "[data-tabtrail-scroll-region]";
  var WHEEL_SURFACE_SELECTOR = "[data-tabtrail-wheel-surface]";
  var LINE_DELTA_PIXELS = 16;
  function isElement(target) {
    return typeof target.matches === "function";
  }
  function eventPathElements(event) {
    return event.composedPath().filter(isElement);
  }
  function canScrollAxis(position, viewportSize, contentSize, delta) {
    if (delta < 0) return position > 0;
    if (delta > 0) return position + viewportSize < contentSize;
    return false;
  }
  function canScrollInWheelDirection(region, event) {
    return canScrollAxis(
      region.scrollTop,
      region.clientHeight,
      region.scrollHeight,
      event.deltaY
    ) || canScrollAxis(
      region.scrollLeft,
      region.clientWidth,
      region.scrollWidth,
      event.deltaX
    );
  }
  function deltaMultiplier(event, region, axis) {
    if (event.deltaMode === WheelEvent.DOM_DELTA_LINE) return LINE_DELTA_PIXELS;
    if (event.deltaMode === WheelEvent.DOM_DELTA_PAGE) {
      const viewportSize = axis === "y" ? region.clientHeight : region.clientWidth;
      return viewportSize || 1;
    }
    return 1;
  }
  function clamp(value, minimum, maximum) {
    return Math.min(Math.max(value, minimum), maximum);
  }
  function manuallyScrollRegion(region, event) {
    const deltaX = event.deltaX * deltaMultiplier(event, region, "x");
    const deltaY = event.deltaY * deltaMultiplier(event, region, "y");
    const maxScrollLeft = Math.max(0, region.scrollWidth - region.clientWidth);
    const maxScrollTop = Math.max(0, region.scrollHeight - region.clientHeight);
    region.scrollLeft = clamp(region.scrollLeft + deltaX, 0, maxScrollLeft);
    region.scrollTop = clamp(region.scrollTop + deltaY, 0, maxScrollTop);
  }
  function installOverlayInteractionShield(shadow) {
    const containEvent = (event) => {
      event.stopPropagation();
    };
    const containWheel = (event) => {
      const wheelEvent = event;
      wheelEvent.stopPropagation();
      const pathElements = eventPathElements(wheelEvent);
      const pathRegion = pathElements.find((element) => element.matches(SCROLL_REGION_SELECTOR));
      if (pathRegion instanceof HTMLElement) {
        if (canScrollInWheelDirection(pathRegion, wheelEvent)) {
          if (wheelEvent.defaultPrevented) manuallyScrollRegion(pathRegion, wheelEvent);
        } else {
          wheelEvent.preventDefault();
        }
        return;
      }
      const wheelSurface = pathElements.find((element) => element.matches(WHEEL_SURFACE_SELECTOR));
      const fallbackRegion = wheelSurface?.querySelector(
        SCROLL_REGION_SELECTOR
      );
      if (fallbackRegion) manuallyScrollRegion(fallbackRegion, wheelEvent);
      wheelEvent.preventDefault();
    };
    for (const eventType of CONTAINED_EVENT_TYPES) {
      shadow.addEventListener(eventType, containEvent);
    }
    shadow.addEventListener("wheel", containWheel, { passive: false });
    return () => {
      for (const eventType of CONTAINED_EVENT_TYPES) {
        shadow.removeEventListener(eventType, containEvent);
      }
      shadow.removeEventListener("wheel", containWheel);
    };
  }

  // src/lib/ui/panels/breadcrumbTrail/overlaySurfaces.ts
  var stack = [];
  function hasOverlaySurface(id) {
    return stack.some((surface) => surface.id === id);
  }
  function isOverlaySurfaceBlockingLiveRender() {
    return hasOverlaySurface("nameDialog") || hasOverlaySurface("library");
  }
  function pushOverlaySurface(id, close) {
    closeOverlaySurface(id);
    stack.push({ id, close });
  }
  function closeOverlaySurface(id) {
    const index = stack.findIndex((surface2) => surface2.id === id);
    if (index === -1) return;
    const [surface] = stack.splice(index, 1);
    surface.close();
  }
  function dropOverlaySurface(id) {
    const index = stack.findIndex((surface) => surface.id === id);
    if (index === -1) return;
    stack.splice(index, 1);
  }
  function closeTopOverlaySurface() {
    const surface = stack.pop();
    if (!surface) return false;
    surface.close();
    return true;
  }
  function closeAllOverlaySurfaces() {
    while (stack.length > 0) {
      const surface = stack.pop();
      surface?.close();
    }
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsSearch.ts
  var MAX_TRAIL_SEARCH_QUERY_LENGTH = 160;
  var FIELD_BONUS = {
    name: 30,
    title: 20,
    url: 10
  };
  var TOKEN_GAP_PENALTY = 1e5;
  var graphemeSegmenter = typeof Intl.Segmenter === "function" ? new Intl.Segmenter(void 0, { granularity: "grapheme" }) : null;
  function isWordCharacter(value) {
    return /[\p{L}\p{N}]/u.test(value);
  }
  function isLowercaseLetter(value) {
    return /\p{Ll}/u.test(value);
  }
  function isUppercaseLetter(value) {
    return /\p{Lu}/u.test(value);
  }
  function isGraphemeContinuation(value) {
    const codePoint = value.codePointAt(0) ?? 0;
    return /\p{M}/u.test(value) || value === "\u200D" || codePoint >= 65024 && codePoint <= 65039 || codePoint >= 127995 && codePoint <= 127999;
  }
  function sourceClusters(value) {
    if (graphemeSegmenter) {
      return [...graphemeSegmenter.segment(value)].map((part) => ({
        value: part.segment,
        start: part.index,
        end: part.index + part.segment.length
      }));
    }
    const clusters = [];
    let current = "";
    let start = 0;
    let offset = 0;
    for (const character of value) {
      const continues = current !== "" && (isGraphemeContinuation(character) || current.endsWith("\u200D"));
      if (!continues && current !== "") {
        clusters.push({ value: current, start, end: offset });
        current = "";
        start = offset;
      }
      current += character;
      offset += character.length;
    }
    if (current !== "") clusters.push({ value: current, start, end: offset });
    return clusters;
  }
  function foldCluster(value) {
    const folded = value.normalize("NFKD").toUpperCase().toLowerCase().normalize("NFKD");
    return [...folded].filter((character) => !/\p{M}/u.test(character));
  }
  function foldWithOffsets(value) {
    const units = [];
    let previous = "";
    for (const cluster of sourceClusters(value)) {
      const boundary = cluster.start === 0 || !isWordCharacter(previous) || isLowercaseLetter(previous) && isUppercaseLetter(cluster.value);
      const folded = foldCluster(cluster.value);
      let firstExpansionUnit = true;
      for (const foldedCharacter of folded) {
        units.push({
          char: foldedCharacter,
          start: cluster.start,
          end: cluster.end,
          boundary: boundary && firstExpansionUnit
        });
        firstExpansionUnit = false;
      }
      previous = cluster.value;
    }
    return units;
  }
  function foldQueryToken(token) {
    return foldWithOffsets(token).map((unit) => unit.char);
  }
  function queryTokens(query) {
    const trimmed = query.trim();
    if (trimmed.length > MAX_TRAIL_SEARCH_QUERY_LENGTH) return null;
    const rawTokens = trimmed.split(/\s+/u).filter(Boolean);
    const tokens = rawTokens.map(foldQueryToken);
    if (tokens.some((token) => token.length === 0)) return null;
    const seen = /* @__PURE__ */ new Set();
    return tokens.filter((token) => {
      const key = JSON.stringify(token);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function scoreTokenPositions(units, positions) {
    const span = positions[positions.length - 1] - positions[0] + 1;
    const gaps = span - positions.length;
    const startsAtBoundary = units[positions[0]].boundary;
    const exact = units.length === positions.length && positions[0] === 0 && gaps === 0;
    const contiguous = gaps === 0;
    const score = 101e3 - gaps * TOKEN_GAP_PENALTY + (exact ? 1200 : 0) + (contiguous ? 240 : 0) + (startsAtBoundary ? 40 : 0);
    return { positions, score, span };
  }
  function tokenPrefixTable(token) {
    const prefix = new Array(token.length).fill(0);
    for (let index = 1, matched = 0; index < token.length; index += 1) {
      while (matched > 0 && token[index] !== token[matched]) matched = prefix[matched - 1];
      if (token[index] === token[matched]) matched += 1;
      prefix[index] = matched;
    }
    return prefix;
  }
  function matchToken(units, token) {
    if (token.length === 0 || units.length === 0) return null;
    const prefix = tokenPrefixTable(token);
    let matched = 0;
    let bestContiguousStart = -1;
    let bestContiguousScore = Number.NEGATIVE_INFINITY;
    for (let index = 0; index < units.length; index += 1) {
      while (matched > 0 && units[index].char !== token[matched]) matched = prefix[matched - 1];
      if (units[index].char === token[matched]) matched += 1;
      if (matched !== token.length) continue;
      const start = index - token.length + 1;
      const exact = units.length === token.length && start === 0;
      const score = 101e3 + (exact ? 1200 : 0) + 240 + (units[start].boundary ? 40 : 0);
      if (score > bestContiguousScore) {
        bestContiguousStart = start;
        bestContiguousScore = score;
      }
      matched = prefix[matched - 1];
    }
    if (bestContiguousStart >= 0) {
      const positions = Array.from(
        { length: token.length },
        (_, index) => bestContiguousStart + index
      );
      return { positions, score: bestContiguousScore, span: token.length };
    }
    let best = null;
    let searchStart = 0;
    while (searchStart < units.length) {
      let tokenIndex = 0;
      let matchEnd = -1;
      for (let index = searchStart; index < units.length; index += 1) {
        if (units[index].char !== token[tokenIndex]) continue;
        tokenIndex += 1;
        if (tokenIndex === token.length) {
          matchEnd = index;
          break;
        }
      }
      if (matchEnd < 0) break;
      const tightened = new Array(token.length);
      tokenIndex = token.length - 1;
      for (let index = matchEnd; index >= searchStart && tokenIndex >= 0; index -= 1) {
        if (units[index].char !== token[tokenIndex]) continue;
        tightened[tokenIndex] = index;
        tokenIndex -= 1;
      }
      const candidate = scoreTokenPositions(units, tightened);
      if (!best || candidate.score > best.score || candidate.score === best.score && candidate.span < best.span || candidate.score === best.score && candidate.span === best.span && candidate.positions[0] < best.positions[0]) best = candidate;
      searchStart = tightened[0] + 1;
    }
    return best;
  }
  function rangesForPositions(units, positions) {
    const sourceRanges = positions.map((position) => ({
      start: units[position].start,
      end: units[position].end
    })).sort((left, right) => left.start - right.start || left.end - right.end);
    const merged = [];
    for (const range of sourceRanges) {
      const previous = merged[merged.length - 1];
      if (previous && range.start <= previous.end) {
        previous.end = Math.max(previous.end, range.end);
      } else {
        merged.push({ ...range });
      }
    }
    return merged;
  }
  function matchField(field, value, entryIndex, tokens) {
    if (value === "") return null;
    const units = foldWithOffsets(value);
    const tokenMatches = [];
    for (const token of tokens) {
      const match = matchToken(units, token);
      if (!match) return null;
      tokenMatches.push(match);
    }
    const allPositions = tokenMatches.flatMap((match) => match.positions);
    const foldedValue = units.map((unit) => unit.char).join("");
    const foldedQuery = tokens.map((token) => token.join("")).join(" ");
    const exactQuery = foldedValue === foldedQuery;
    const contiguousQuery = !exactQuery && foldedQuery !== "" && foldedValue.includes(foldedQuery);
    const score = tokenMatches.reduce((total, match) => total + match.score, 0) + (exactQuery ? 1600 : 0) + (contiguousQuery ? 500 : 0) + FIELD_BONUS[field];
    return {
      field,
      entryIndex,
      value,
      ranges: rangesForPositions(units, allPositions),
      score
    };
  }
  function fieldOrder(field) {
    if (field === "name") return 0;
    if (field === "title") return 1;
    return 2;
  }
  function compareFieldHits(left, right) {
    const leftEntry = left.entryIndex ?? -1;
    const rightEntry = right.entryIndex ?? -1;
    return right.score - left.score || fieldOrder(left.field) - fieldOrder(right.field) || rightEntry - leftEntry || left.ranges[0].start - right.ranges[0].start;
  }
  function bestTrailMatch(trail, tokens) {
    const candidates = [];
    const nameMatch = matchField("name", trail.name, null, tokens);
    if (nameMatch) candidates.push(nameMatch);
    for (let entryIndex = 0; entryIndex < trail.entries.length; entryIndex += 1) {
      const entry = trail.entries[entryIndex];
      const titleMatch = matchField("title", entry.title, entryIndex, tokens);
      if (titleMatch) candidates.push(titleMatch);
      const urlMatch = matchField("url", entry.url, entryIndex, tokens);
      if (urlMatch) candidates.push(urlMatch);
    }
    candidates.sort(compareFieldHits);
    return candidates[0] ?? null;
  }
  function compareText(left, right) {
    const foldedLeft = left.toLowerCase();
    const foldedRight = right.toLowerCase();
    if (foldedLeft < foldedRight) return -1;
    if (foldedLeft > foldedRight) return 1;
    if (left < right) return -1;
    if (left > right) return 1;
    return 0;
  }
  function compareTrailTies(left, right) {
    if (left.trail.pinned !== right.trail.pinned) return left.trail.pinned ? -1 : 1;
    return right.trail.updatedAt - left.trail.updatedAt || right.trail.createdAt - left.trail.createdAt || compareText(left.trail.name, right.trail.name) || compareText(left.trail.id, right.trail.id) || left.sourceIndex - right.sourceIndex;
  }
  function createTrailSearchSnippet(value, ranges, maxLength = 64) {
    const clusters = sourceClusters(value);
    const safeMaximum = Math.max(8, Math.floor(maxLength));
    if (ranges.length === 0 || clusters.length <= safeMaximum) {
      return { value, ranges: ranges.map((range) => ({ ...range })) };
    }
    const sortedRanges = [...ranges].sort((left, right) => left.start - right.start);
    const firstMatch = clusters.findIndex((cluster) => cluster.end > sortedRanges[0].start);
    let lastMatch = -1;
    for (let index = clusters.length - 1; index >= 0; index -= 1) {
      if (clusters[index].start < sortedRanges[sortedRanges.length - 1].end) {
        lastMatch = index;
        break;
      }
    }
    if (firstMatch < 0 || lastMatch < firstMatch) {
      return { value, ranges: sortedRanges.map((range) => ({ ...range })) };
    }
    const matchSpan = lastMatch - firstMatch + 1;
    const leadingContext = Math.min(8, Math.floor(safeMaximum / 4));
    let start = Math.max(0, firstMatch - leadingContext);
    if (matchSpan <= safeMaximum) start = Math.max(start, lastMatch - safeMaximum + 1);
    const end = Math.min(clusters.length, start + safeMaximum);
    const sourceStart = clusters[start].start;
    const sourceEnd = clusters[end - 1].end;
    const hasPrefix = sourceStart > 0;
    const hasSuffix = sourceEnd < value.length;
    const prefix = hasPrefix ? "\u2026" : "";
    const suffix = hasSuffix ? "\u2026" : "";
    const offset = prefix.length - sourceStart;
    const adjustedRanges = sortedRanges.filter((range) => range.end > sourceStart && range.start < sourceEnd).map((range) => ({
      start: Math.max(sourceStart, range.start) + offset,
      end: Math.min(sourceEnd, range.end) + offset
    }));
    return {
      value: `${prefix}${value.slice(sourceStart, sourceEnd)}${suffix}`,
      ranges: adjustedRanges
    };
  }
  function searchSavedTrails(trails, query) {
    const tokens = queryTokens(query);
    if (tokens === null) return [];
    const hits = [];
    for (let sourceIndex = 0; sourceIndex < trails.length; sourceIndex += 1) {
      const trail = trails[sourceIndex];
      if (tokens.length === 0) {
        hits.push({ trail, score: 0, match: null, sourceIndex });
        continue;
      }
      const match = bestTrailMatch(trail, tokens);
      if (match) hits.push({ trail, score: match.score, match, sourceIndex });
    }
    hits.sort((left, right) => {
      if (tokens.length > 0 && left.score !== right.score) return right.score - left.score;
      return compareTrailTies(left, right);
    });
    return hits.map(({ trail, score, match }) => ({ trail, score, match }));
  }

  // src/lib/common/utils/helpers.ts
  var DOMAIN_CACHE_MAX = 500;
  var domainCache = /* @__PURE__ */ new Map();
  function cacheDomain(url, value) {
    if (domainCache.size >= DOMAIN_CACHE_MAX) {
      const firstKey = domainCache.keys().next().value;
      if (firstKey !== void 0) domainCache.delete(firstKey);
    }
    domainCache.set(url, value);
    return value;
  }
  function extractDomain(url) {
    const cached = domainCache.get(url);
    if (cached) return cached;
    try {
      return cacheDomain(url, new URL(url).hostname);
    } catch (_) {
      return cacheDomain(url, url.length > 30 ? url.substring(0, 30) + "\u2026" : url);
    }
  }

  // src/lib/ui/panels/breadcrumbTrail/trailPresentation.ts
  function entryTitle(entry) {
    if (entry.title.trim() !== "") return entry.title.trim();
    const domain = extractDomain(entry.url);
    return domain !== "" ? domain : entry.url;
  }
  function entryUrlSubtitle(entry) {
    try {
      const parsed = new URL(entry.url);
      const path = parsed.pathname === "/" ? "" : parsed.pathname;
      const query = parsed.search ? "?..." : "";
      const hash = parsed.hash ? "#..." : "";
      return `${parsed.hostname}${path}${query}${hash}`;
    } catch (_) {
      return entry.url;
    }
  }
  function branchConnectorElement(nextEntry) {
    const connector = document.createElement("div");
    connector.className = "wf-branch-connector";
    connector.setAttribute("aria-hidden", "true");
    if (!nextEntry.historyBacked) {
      connector.classList.add("wf-branch-connector-inherited");
      connector.title = "Direct-navigation boundary";
    }
    if (nextEntry.transition === "typed") {
      connector.classList.add("wf-branch-connector-typed");
    } else if (nextEntry.transition === "spa" || nextEntry.transition === "fragment") {
      connector.classList.add("wf-branch-connector-spa");
    }
    if (nextEntry.historyBacked) connector.title = nextEntry.transition;
    return connector;
  }
  function buildReadOnlyTreeNode(entry, isEndpoint) {
    const row = document.createElement("div");
    row.className = "wf-branch-row wf-trail-tree-node";
    if (isEndpoint) row.classList.add("wf-branch-row-current");
    const node = document.createElement("span");
    node.className = "wf-branch-node";
    node.setAttribute("aria-hidden", "true");
    row.appendChild(node);
    const content = document.createElement("div");
    content.className = "wf-branch-entry";
    const title = document.createElement("span");
    title.className = "wf-branch-entry-title";
    title.textContent = entryTitle(entry);
    content.appendChild(title);
    const url = document.createElement("span");
    url.className = "wf-branch-entry-url";
    url.textContent = entryUrlSubtitle(entry);
    content.appendChild(url);
    row.appendChild(content);
    return row;
  }
  function pagesLabel(count) {
    return `${count} page${count === 1 ? "" : "s"}`;
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsSession.ts
  var LIBRARY_PANEL_GAP = 10;
  var VIEWPORT_MARGIN = 12;
  var UNDO_DURATION_MS = 8e3;
  var LIBRARY_EMPTY_COPY = "Open \u22EF on any page in your trail, then choose Save trail up to this point in path.";
  var host = null;
  var librarySession = null;
  var libraryDragStop = null;
  var treePreviewElement = null;
  var pendingTrailIds = /* @__PURE__ */ new Set();
  var nextDialogId = 0;
  var nextLibraryMetaId = 0;
  var renderLibraryImpl = null;
  function setHost(next) {
    host = next;
  }
  function setLibrarySession(next) {
    librarySession = next;
  }
  function setLibraryDragStop(next) {
    libraryDragStop = next;
  }
  function setTreePreviewElement(next) {
    treePreviewElement = next;
  }
  function allocateDialogId() {
    return ++nextDialogId;
  }
  function allocateLibraryMetaId() {
    return ++nextLibraryMetaId;
  }
  function registerRenderLibrary(fn) {
    renderLibraryImpl = fn;
  }
  function renderLibrary(session2) {
    renderLibraryImpl?.(session2);
  }
  function syncLiveInteraction(boundHost) {
    boundHost.setLiveInteractionBlocked(isOverlaySurfaceBlockingLiveRender());
  }
  function activeShadowElement(boundHost) {
    const root = boundHost.layer.getRootNode();
    if (!(root instanceof ShadowRoot)) return null;
    return root.activeElement instanceof HTMLElement ? root.activeElement : null;
  }
  function restoreFocus(element) {
    scheduleFocusWhenIdle(() => element);
  }
  function libraryFocusIdentity(element) {
    const row = element?.closest(".wf-library-row");
    const action = element?.dataset.libraryAction ?? element?.dataset.libraryFocusAction;
    if (!row?.dataset.trailId || action !== "main" && action !== "pin" && action !== "more") {
      return null;
    }
    return { trailId: row.dataset.trailId, action };
  }
  function findTrailControl(trailId, action = "more") {
    if (!librarySession) return null;
    const row = [...librarySession.list.querySelectorAll(".wf-library-row")].find((candidate) => candidate.dataset.trailId === trailId);
    return row?.querySelector(`[data-library-action="${action}"]`) ?? null;
  }
  function libraryPrimaryControl() {
    if (!librarySession) return null;
    return librarySession.list.querySelector(
      ".wf-library-row-main:not(:disabled), .wf-library-state-action:not(:disabled)"
    ) ?? librarySession.search;
  }
  function restoreLibraryFocus(identity, fallbackToLibrary = false) {
    if (!identity) return;
    scheduleFocusWhenIdle(() => {
      const exact = findTrailControl(identity.trailId, identity.action);
      if (exact && !exact.matches(":disabled")) return exact;
      const pendingRow = exact?.closest('.wf-library-row[aria-busy="true"]');
      if (pendingRow) {
        pendingRow.dataset.libraryFocusAction = identity.action;
        return pendingRow;
      }
      return fallbackToLibrary ? libraryPrimaryControl() : null;
    });
  }
  function restoreSurfaceFocus(boundHost, element) {
    const savedIdentity = libraryFocusIdentity(element);
    if (savedIdentity) {
      restoreLibraryFocus(savedIdentity, true);
      return;
    }
    if (element?.dataset.liveControl) {
      boundHost.restoreLiveFocus(element);
      return;
    }
    restoreFocus(element);
  }
  function restoreLibraryPrimaryFocus(session2) {
    scheduleFocusWhenIdle(() => {
      if (librarySession !== session2) return null;
      return libraryPrimaryControl();
    });
  }
  function acceptAuthoritativeTrails(trails, expectedSession, expectedGeneration) {
    const current = librarySession;
    if (!current || expectedSession !== void 0 && current !== expectedSession || expectedGeneration !== void 0 && current.loadRequest !== expectedGeneration) return;
    closeOverlaySurface("treePreview");
    current.trails = normalizeSavedTrails(trails);
    current.state = "ready";
    renderLibrary(current);
  }
  function currentCapturedPath() {
    if (!host) return null;
    const state = host.getState();
    return slicePathToIndex(state, state.cursor);
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsDialogs.ts
  function createManagedDialogShell(options) {
    const dialogId = `${options.idPrefix}-${allocateDialogId()}`;
    const titleId = `${dialogId}-title`;
    const summaryId = `${dialogId}-summary`;
    const dialog = document.createElement("div");
    dialog.id = dialogId;
    dialog.className = "wf-dialog";
    dialog.dataset.tabtrailHitSurface = "";
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "false");
    dialog.setAttribute("aria-labelledby", titleId);
    dialog.setAttribute("aria-describedby", summaryId);
    const heading = document.createElement("div");
    heading.id = titleId;
    heading.className = "wf-dialog-title";
    heading.textContent = options.title;
    dialog.appendChild(heading);
    const summary = document.createElement("div");
    summary.id = summaryId;
    summary.className = "wf-dialog-summary";
    summary.textContent = options.summary;
    dialog.appendChild(summary);
    const input = options.input ? document.createElement("input") : null;
    if (input && options.input) {
      input.className = "wf-dialog-input";
      input.type = "text";
      input.maxLength = options.input.maxLength;
      input.value = options.input.initialValue;
      input.setAttribute("aria-label", options.input.ariaLabel);
      dialog.appendChild(input);
    }
    const error = document.createElement("div");
    error.className = "wf-dialog-error";
    error.setAttribute("role", "alert");
    error.hidden = true;
    dialog.appendChild(error);
    const actions = document.createElement("div");
    actions.className = "wf-dialog-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "wf-dialog-btn";
    cancel.textContent = "Cancel";
    cancel.addEventListener("click", () => closeOverlaySurface("nameDialog"));
    const submit = document.createElement("button");
    submit.type = "button";
    submit.className = "wf-dialog-btn wf-dialog-btn-primary";
    submit.textContent = options.submitLabel;
    actions.appendChild(cancel);
    actions.appendChild(submit);
    dialog.appendChild(actions);
    const setPending = (pending) => {
      dialog.toggleAttribute("aria-busy", pending);
      if (pending) error.hidden = true;
      if (input) input.disabled = pending;
      cancel.disabled = pending;
      submit.disabled = pending;
      submit.textContent = pending ? options.pendingLabel : options.submitLabel;
    };
    const showError = (message) => {
      error.textContent = message;
      error.hidden = false;
      setPending(false);
      input?.focus();
    };
    return { dialog, input, cancel, submit, setPending, showError };
  }
  function openMutationDialog(options) {
    if (!host) return;
    const dialogHost = host;
    const dialogSession = librarySession;
    if (options.closeLiveSurfaces) dialogHost.closeLiveSurfaces();
    if (options.closeLibrary) {
      if (librarySession) librarySession.restoreFocusOnClose = false;
      closeOverlaySurface("library");
    }
    closeOverlaySurface("treePreview");
    closeOverlaySurface("menu");
    closeOverlaySurface("nameDialog");
    const shell = createManagedDialogShell(options.shell);
    const { dialog, input, submit: submitButton } = shell;
    let submitting = false;
    const submit = () => {
      if (submitting) return;
      submitting = true;
      shell.setPending(true);
      const mutationGeneration = dialogSession?.loadRequest;
      if (options.trailId) {
        pendingTrailIds.add(options.trailId);
        if (librarySession) renderLibrary(librarySession);
      }
      void options.submit(input?.value).then((result) => {
        if (host !== dialogHost) return;
        if (!result.ok) {
          if (dialog.isConnected) {
            shell.showError(result.reason);
            submitting = false;
          } else {
            dialogHost.showNotice(result.reason, { tone: "error", durationMs: 5e3 });
          }
          return;
        }
        acceptAuthoritativeTrails(result.trails, dialogSession, mutationGeneration);
        if (dialog.isConnected) closeOverlaySurface("nameDialog");
        options.onSuccess(result, dialogHost, dialogSession);
      }).catch(() => {
        if (host !== dialogHost) return;
        if (!dialog.isConnected) {
          dialogHost.showNotice(options.failureMessage, { tone: "error", durationMs: 5e3 });
          return;
        }
        shell.showError(options.failureMessage);
        submitting = false;
      }).finally(() => {
        if (!options.trailId) return;
        pendingTrailIds.delete(options.trailId);
        if (host === dialogHost && dialogSession && librarySession === dialogSession) {
          renderLibrary(dialogSession);
        }
        if (host === dialogHost && dialogSession && librarySession === dialogSession && !dialog.isConnected) {
          restoreLibraryFocus({ trailId: options.trailId, action: "more" }, true);
        }
      });
    };
    submitButton.addEventListener("click", submit);
    input?.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      submit();
    });
    dialogHost.layer.appendChild(dialog);
    pushOverlaySurface("nameDialog", () => {
      dialog.remove();
      if (host !== dialogHost) return;
      syncLiveInteraction(dialogHost);
      dialogHost.flushLiveTrailUpdates();
      if (options.trailId && submitting) return;
      if (options.trailId) {
        restoreLibraryFocus({ trailId: options.trailId, action: "more" }, true);
      } else {
        restoreSurfaceFocus(dialogHost, options.opener);
      }
    });
    syncLiveInteraction(dialogHost);
    if (input) {
      input.focus({ preventScroll: true });
      input.select();
    } else {
      submitButton.focus({ preventScroll: true });
    }
  }
  function openNameDialog(options) {
    openMutationDialog({
      shell: {
        idPrefix: "tabtrail-name-dialog",
        title: options.title,
        summary: options.summary,
        submitLabel: options.submitLabel,
        pendingLabel: options.pendingLabel,
        input: {
          initialValue: options.initialName,
          ariaLabel: "Trail name",
          maxLength: SAVED_TRAIL_NAME_MAX_LENGTH
        }
      },
      opener: options.opener,
      trailId: options.trailId,
      closeLibrary: options.closeLibrary,
      closeLiveSurfaces: true,
      failureMessage: "Could not save changes",
      submit: (value) => options.submit(value ?? ""),
      onSuccess: (result, boundHost) => {
        boundHost.showNotice(options.successMessage(result.trail));
      }
    });
  }
  function openSaveCapturedPathDialog(path, opener) {
    if (!host) return;
    const client = host.client;
    if (!path || path.length === 0) {
      host.showNotice("Nothing to save on this row", { tone: "error" });
      return;
    }
    const endpoint = path[path.length - 1];
    openNameDialog({
      title: "Name this trail",
      summary: `${pagesLabel(path.length)} \xB7 ends at \u201C${entryTitle(endpoint)}\u201D`,
      initialName: suggestSavedTrailName(endpoint),
      submitLabel: "Save",
      pendingLabel: "Saving\u2026",
      opener,
      closeLibrary: true,
      submit: (name) => client.save(path, name),
      successMessage: (trail) => `Saved \u201C${trail.name}\u201D`
    });
  }
  function openSaveTrailDialog(index, opener) {
    if (!host) return;
    const state = host.getState();
    openSaveCapturedPathDialog(
      slicePathToIndex(state, index),
      opener ?? activeShadowElement(host)
    );
  }
  function openSaveCurrentTrailDialog(opener) {
    if (!host) return;
    const state = host.getState();
    openSaveCapturedPathDialog(slicePathToIndex(state, state.cursor), opener);
  }
  function openRenameDialog(trail, opener) {
    if (!host) return;
    const client = host.client;
    openNameDialog({
      title: "Rename saved trail",
      summary: `${pagesLabel(trail.entries.length)} \xB7 current name \u201C${trail.name}\u201D`,
      initialName: trail.name,
      submitLabel: "Rename",
      pendingLabel: "Renaming\u2026",
      opener,
      closeLibrary: false,
      trailId: trail.id,
      submit: (name) => client.rename(trail.id, name),
      successMessage: (renamed) => `Renamed to \u201C${renamed.name}\u201D`
    });
  }
  function openUpdateDialog(trail, opener) {
    if (!host) return;
    const client = host.client;
    const path = currentCapturedPath();
    if (!path || path.length === 0) {
      host.showNotice("The current trail has no path to save", { tone: "error" });
      return;
    }
    const oldEndpoint = savedTrailEndpoint(trail);
    const newEndpoint = path[path.length - 1];
    openMutationDialog({
      shell: {
        idPrefix: "tabtrail-update-dialog",
        title: `Update \u201C${trail.name}\u201D?`,
        summary: `${pagesLabel(trail.entries.length)} ending at \u201C${oldEndpoint ? entryTitle(oldEndpoint) : "Unknown"}\u201D will become ${pagesLabel(path.length)} ending at \u201C${entryTitle(newEndpoint)}\u201D.`,
        submitLabel: "Replace path",
        pendingLabel: "Updating\u2026"
      },
      opener,
      trailId: trail.id,
      failureMessage: "Could not update trail",
      submit: () => client.replace(trail.id, path, trail.entries),
      onSuccess: (result, boundHost, originSession) => {
        const previousTrail = result.previousTrail;
        if (!previousTrail) {
          boundHost.showNotice("Could not read the previous trail path", { tone: "error" });
          return;
        }
        if (savedTrailEntriesEqual(previousTrail.entries, result.trail.entries)) {
          boundHost.showNotice(`\u201C${result.trail.name}\u201D already matches the current path`);
          return;
        }
        offerUpdateUndo(boundHost, result.trail, previousTrail, originSession);
      }
    });
  }
  function offerUpdateUndo(boundHost, updated, previous, originSession) {
    boundHost.showNotice(`Updated \u201C${updated.name}\u201D`, {
      actionLabel: "Undo",
      durationMs: UNDO_DURATION_MS,
      undo: true,
      action: async () => {
        const mutationGeneration = originSession?.loadRequest;
        try {
          const reverted = await boundHost.client.replace(
            updated.id,
            previous.entries,
            updated.entries
          );
          if (host !== boundHost) return;
          if (!reverted.ok) {
            boundHost.showNotice(reverted.reason, { tone: "error", durationMs: 6e3 });
            return;
          }
          acceptAuthoritativeTrails(reverted.trails, originSession, mutationGeneration);
          boundHost.showNotice(`Restored the previous path for \u201C${reverted.trail.name}\u201D`);
        } catch (_) {
          if (host !== boundHost) return;
          boundHost.showNotice("Could not undo the update", { tone: "error", durationMs: 6e3 });
        }
      }
    });
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsMutations.ts
  async function runTrailMutation(session2, trailId, task) {
    if (pendingTrailIds.has(trailId)) return null;
    pendingTrailIds.add(trailId);
    closeOverlaySurface("menu");
    const operationFocus = libraryFocusIdentity(activeShadowElement(session2.host));
    const mutationGeneration = session2.loadRequest;
    renderLibrary(session2);
    try {
      const result = await task();
      if (!result.ok) {
        if (host === session2.host) {
          session2.host.showNotice(result.reason || "Could not save changes", {
            tone: "error",
            durationMs: 5e3
          });
        }
        return result;
      }
      if (result.trails) {
        acceptAuthoritativeTrails(result.trails, session2, mutationGeneration);
      }
      return result;
    } catch (_) {
      if (host === session2.host) {
        session2.host.showNotice("Could not save changes", { tone: "error", durationMs: 5e3 });
      }
      return null;
    } finally {
      pendingTrailIds.delete(trailId);
      if (host === session2.host && librarySession === session2) {
        renderLibrary(session2);
        restoreLibraryFocus(operationFocus);
      }
    }
  }
  async function duplicateTrail(session2, trail) {
    const result = await runTrailMutation(session2, trail.id, () => session2.host.client.duplicate(trail.id));
    if (host === session2.host && result?.ok && "trail" in result) {
      session2.host.showNotice(`Duplicated as \u201C${result.trail.name}\u201D`);
    }
  }
  async function togglePinned(session2, trail) {
    const result = await runTrailMutation(
      session2,
      trail.id,
      () => session2.host.client.setPinned(trail.id, !trail.pinned)
    );
    if (host === session2.host && result?.ok) {
      session2.host.showNotice(trail.pinned ? `Unpinned \u201C${trail.name}\u201D` : `Pinned \u201C${trail.name}\u201D`);
    }
  }
  async function removeTrail(session2, trail) {
    const result = await runTrailMutation(session2, trail.id, () => session2.host.client.delete(trail.id));
    if (host !== session2.host || !result?.ok || !("trail" in result)) return;
    const deleted = result.trail;
    offerDeleteUndo(session2.host, deleted, session2);
    restoreFocus(
      session2.list.querySelector(".wf-library-row-main") ?? session2.search
    );
  }
  function offerDeleteUndo(boundHost, deleted, originSession) {
    boundHost.showNotice(`Removed \u201C${deleted.name}\u201D`, {
      actionLabel: "Undo",
      durationMs: UNDO_DURATION_MS,
      undo: true,
      action: () => restoreDeletedTrail(boundHost, deleted, originSession)
    });
  }
  async function restoreDeletedTrail(boundHost, deleted, originSession) {
    const mutationGeneration = originSession.loadRequest;
    try {
      const restored = await boundHost.client.restore(deleted);
      if (host !== boundHost) return;
      if (!restored.ok) {
        boundHost.showNotice(restored.reason, {
          tone: "error",
          actionLabel: "Retry",
          durationMs: UNDO_DURATION_MS,
          undo: true,
          action: () => restoreDeletedTrail(boundHost, deleted, originSession)
        });
        return;
      }
      acceptAuthoritativeTrails(restored.trails, originSession, mutationGeneration);
      boundHost.showNotice(`Restored \u201C${restored.trail.name}\u201D`);
    } catch (_) {
      if (host !== boundHost) return;
      boundHost.showNotice("Could not restore trail", {
        tone: "error",
        actionLabel: "Retry",
        durationMs: UNDO_DURATION_MS,
        undo: true,
        action: () => restoreDeletedTrail(boundHost, deleted, originSession)
      });
    }
  }
  async function navigateSavedTrail(trail, mode) {
    if (!host) return;
    const boundHost = host;
    try {
      const result = await boundHost.client.open(trail.entries, mode);
      if (host !== boundHost) return;
      if (!result.ok) {
        boundHost.showNotice(result.reason || "Could not open trail", { tone: "error" });
        return;
      }
      if (mode === "current") boundHost.hideTrail();
      else boundHost.showNotice("Opened in new tab");
    } catch (_) {
      if (host === boundHost) {
        boundHost.showNotice("Could not open trail", { tone: "error" });
      }
    }
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsTreePreview.ts
  function openSavedTrailTreePreview(trail, opener) {
    if (!host) return;
    const previewHost = host;
    previewHost.closeLiveSurfaces();
    closeOverlaySurface("menu");
    closeOverlaySurface("treePreview");
    const panel = document.createElement("div");
    panel.className = "wf-trail-tree-preview";
    panel.dataset.tabtrailHitSurface = "";
    panel.dataset.tabtrailWheelSurface = "";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "false");
    panel.setAttribute("aria-label", `Preview path: ${trail.name}`);
    const header = document.createElement("div");
    header.className = "wf-trail-tree-preview-header";
    const identity = document.createElement("div");
    identity.className = "wf-trail-tree-preview-identity";
    const kicker = document.createElement("div");
    kicker.className = "wf-trail-tree-preview-kicker";
    kicker.textContent = "Preview";
    identity.appendChild(kicker);
    const title = document.createElement("div");
    title.className = "wf-trail-tree-preview-title";
    title.textContent = trail.name;
    identity.appendChild(title);
    const meta = document.createElement("div");
    meta.className = "wf-trail-tree-preview-meta";
    const hasDirectNavigation = trail.entries.some(
      (entry, index) => index > 0 && !entry.historyBacked
    );
    meta.textContent = `${pagesLabel(trail.entries.length)}${hasDirectNavigation ? " \xB7 Contains direct-navigation steps" : ""}`;
    identity.appendChild(meta);
    const close = document.createElement("button");
    close.type = "button";
    close.className = "wf-trail-tree-preview-close";
    close.textContent = "\u2715";
    close.title = "Close preview";
    close.setAttribute("aria-label", "Close path preview");
    close.addEventListener("click", () => closeOverlaySurface("treePreview"));
    header.appendChild(identity);
    header.appendChild(close);
    panel.appendChild(header);
    const list = document.createElement("div");
    list.className = "wf-trail-tree-preview-list";
    list.dataset.tabtrailScrollRegion = "";
    for (let index = 0; index < trail.entries.length; index += 1) {
      const entry = trail.entries[index];
      if (index > 0) list.appendChild(branchConnectorElement(entry));
      list.appendChild(buildReadOnlyTreeNode(entry, index === trail.entries.length - 1));
    }
    panel.appendChild(list);
    previewHost.layer.appendChild(panel);
    setTreePreviewElement(panel);
    positionTreePreview(panel);
    pushOverlaySurface("treePreview", () => {
      panel.remove();
      setTreePreviewElement(null);
      if (host === previewHost) restoreSurfaceFocus(previewHost, opener);
    });
    close.focus({ preventScroll: true });
  }
  function positionTreePreview(panel) {
    if (!host) return;
    const margin = VIEWPORT_MARGIN;
    const width = Math.min(360, Math.max(260, host.bar.getBoundingClientRect().width));
    panel.style.width = `${width}px`;
    const anchor = librarySession?.panel ?? host.bar;
    const anchorRect = anchor.getBoundingClientRect();
    const rightSpace = window.innerWidth - anchorRect.right - LIBRARY_PANEL_GAP - margin;
    const leftSpace = anchorRect.left - LIBRARY_PANEL_GAP - margin;
    let left;
    if (rightSpace >= width) left = anchorRect.right + LIBRARY_PANEL_GAP;
    else if (leftSpace >= width) left = anchorRect.left - LIBRARY_PANEL_GAP - width;
    else left = Math.min(Math.max(margin, anchorRect.left), Math.max(margin, window.innerWidth - width - margin));
    const maxHeight = Math.max(160, window.innerHeight - margin * 2);
    panel.style.maxHeight = `${Math.min(maxHeight, 420)}px`;
    const height = Math.min(panel.getBoundingClientRect().height || 280, maxHeight);
    const top = Math.min(
      Math.max(margin, anchorRect.top),
      Math.max(margin, window.innerHeight - height - margin)
    );
    const clamped = clampInViewport(left, top, width, height || 200, margin);
    panel.style.left = `${clamped.left}px`;
    panel.style.top = `${clamped.top}px`;
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsLibrary.ts
  function openLibraryPanel() {
    if (!host) return;
    const openingHost = host;
    const opener = activeShadowElement(openingHost);
    openingHost.closeLiveSurfaces();
    closeOverlaySurface("nameDialog");
    closeOverlaySurface("treePreview");
    closeOverlaySurface("menu");
    closeOverlaySurface("library");
    const panel = document.createElement("div");
    panel.id = "tabtrail-saved-trails-library";
    panel.className = "wf-library-panel";
    panel.dataset.tabtrailHitSurface = "";
    panel.dataset.tabtrailWheelSurface = "";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "false");
    panel.setAttribute("aria-label", "Saved trails");
    const header = document.createElement("div");
    header.className = "wf-library-header";
    const heading = document.createElement("div");
    heading.className = "wf-library-heading";
    const title = document.createElement("span");
    title.className = "wf-library-title";
    title.textContent = "Saved trails";
    const count = document.createElement("span");
    count.className = "wf-library-count";
    count.textContent = `0/${MAX_SAVED_TRAILS}`;
    count.setAttribute("aria-live", "polite");
    count.setAttribute("aria-atomic", "true");
    heading.appendChild(title);
    heading.appendChild(count);
    header.appendChild(heading);
    const grip = document.createElement("span");
    grip.className = "wf-grip";
    grip.textContent = "\u283F";
    grip.title = "Drag to move";
    grip.setAttribute("aria-hidden", "true");
    grip.addEventListener("pointerdown", (event) => {
      libraryDragStop?.();
      setLibraryDragStop(startFreePixelDrag(panel, event, {
        draggingClass: "wf-library-panel-dragging",
        onEnd: () => {
          setLibraryDragStop(null);
        }
      }));
    });
    header.appendChild(grip);
    const close = document.createElement("button");
    close.type = "button";
    close.className = "wf-library-close";
    close.textContent = "\u2715";
    close.title = "Close";
    close.setAttribute("aria-label", "Close saved trails");
    close.addEventListener("click", () => closeOverlaySurface("library"));
    header.appendChild(close);
    panel.appendChild(header);
    const tools = document.createElement("div");
    tools.className = "wf-library-tools";
    const search = document.createElement("input");
    search.type = "search";
    search.className = "wf-library-search";
    search.placeholder = "Fuzzy-search trails and pages";
    search.setAttribute("aria-label", "Fuzzy-search saved trails");
    search.maxLength = MAX_TRAIL_SEARCH_QUERY_LENGTH;
    tools.appendChild(search);
    panel.appendChild(tools);
    const list = document.createElement("div");
    list.className = "wf-library-list";
    list.dataset.tabtrailScrollRegion = "";
    list.setAttribute("role", "list");
    panel.appendChild(list);
    openingHost.layer.appendChild(panel);
    if (opener?.dataset.liveControl === "library") {
      opener.setAttribute("aria-expanded", "true");
      opener.setAttribute("aria-controls", panel.id);
    }
    const savedTrailsChanged = (trails) => {
      const current = librarySession;
      if (!current || current.panel !== panel) return;
      closeOverlaySurface("treePreview");
      current.loadRequest += 1;
      current.trails = normalizeSavedTrails(trails);
      current.state = "ready";
      renderLibrary2(current);
    };
    const session2 = {
      host: openingHost,
      panel,
      list,
      search,
      count,
      trails: [],
      query: "",
      loadRequest: 0,
      state: "loading",
      opener,
      restoreFocusOnClose: true,
      unsubscribe: () => {
      }
    };
    setLibrarySession(session2);
    search.addEventListener("input", () => {
      if (librarySession !== session2) return;
      session2.query = search.value.trim();
      renderLibrary2(session2);
    });
    session2.unsubscribe = openingHost.client.subscribe(savedTrailsChanged);
    positionLibraryPanel(panel);
    pushOverlaySurface("library", () => {
      session2.loadRequest += 1;
      session2.unsubscribe();
      libraryDragStop?.();
      setLibraryDragStop(null);
      closeOverlaySurface("treePreview");
      closeOverlaySurface("menu");
      panel.remove();
      if (opener?.dataset.liveControl === "library") {
        opener.setAttribute("aria-expanded", "false");
        opener.removeAttribute("aria-controls");
      }
      if (librarySession === session2) setLibrarySession(null);
      if (host === openingHost) {
        syncLiveInteraction(openingHost);
        openingHost.flushLiveTrailUpdates();
        if (session2.restoreFocusOnClose) restoreSurfaceFocus(openingHost, opener);
      }
    });
    syncLiveInteraction(openingHost);
    renderLibrary2(session2);
    search.focus({ preventScroll: true });
    void loadLibrary(session2);
  }
  async function loadLibrary(session2, focusAfterLoad = false) {
    const request = ++session2.loadRequest;
    session2.state = "loading";
    renderLibrary2(session2);
    try {
      const trails = await session2.host.client.load();
      if (librarySession !== session2 || session2.loadRequest !== request || !session2.panel.isConnected || host !== session2.host) return;
      session2.trails = trails;
      session2.state = "ready";
      renderLibrary2(session2);
      if (focusAfterLoad) restoreLibraryPrimaryFocus(session2);
    } catch (_) {
      if (librarySession !== session2 || session2.loadRequest !== request || !session2.panel.isConnected || host !== session2.host) return;
      session2.state = "error";
      renderLibrary2(session2);
      if (focusAfterLoad) restoreLibraryPrimaryFocus(session2);
    }
  }
  function renderLibrary2(session2) {
    if (librarySession !== session2 || !session2.panel.isConnected) return;
    closeOverlaySurface("menu");
    const activeControl = activeShadowElement(session2.host);
    const focusedRow = libraryFocusIdentity(activeControl);
    const hadLibraryFocus = activeControl !== null && session2.panel.contains(activeControl);
    const restoreRenderedFocus = () => {
      if (focusedRow) restoreLibraryFocus(focusedRow, true);
      else if (hadLibraryFocus) restoreLibraryPrimaryFocus(session2);
    };
    session2.count.textContent = `${session2.trails.length}/${MAX_SAVED_TRAILS}`;
    session2.panel.setAttribute("aria-busy", session2.state === "loading" ? "true" : "false");
    session2.search.disabled = false;
    session2.list.textContent = "";
    if (session2.state === "loading") {
      session2.list.appendChild(buildLibraryState("Loading saved trails\u2026", "status"));
      restoreRenderedFocus();
      return;
    }
    if (session2.state === "error") {
      const error = buildLibraryState("Couldn\u2019t load saved trails.", "alert");
      const retry = document.createElement("button");
      retry.type = "button";
      retry.className = "wf-library-state-action";
      retry.textContent = "Retry";
      retry.addEventListener("click", () => void loadLibrary(session2, true));
      error.appendChild(retry);
      session2.list.appendChild(error);
      restoreRenderedFocus();
      return;
    }
    const visible = searchSavedTrails(session2.trails, session2.query);
    if (session2.query !== "") {
      session2.count.textContent = `${visible.length} ${visible.length === 1 ? "match" : "matches"} \xB7 ${session2.trails.length}/${MAX_SAVED_TRAILS}`;
    }
    if (visible.length === 0) {
      if (session2.query !== "") {
        const empty2 = buildLibraryState("No trails match your search.");
        const clear = document.createElement("button");
        clear.type = "button";
        clear.className = "wf-library-state-action";
        clear.textContent = "Clear search";
        clear.addEventListener("click", () => {
          session2.search.value = "";
          session2.query = "";
          renderLibrary2(session2);
          session2.search.focus({ preventScroll: true });
        });
        empty2.appendChild(clear);
        session2.list.appendChild(empty2);
        restoreRenderedFocus();
        return;
      }
      const empty = buildLibraryState("No saved trails yet");
      const description = document.createElement("span");
      description.className = "wf-library-state-copy";
      description.textContent = LIBRARY_EMPTY_COPY;
      empty.appendChild(description);
      const state = session2.host.getState();
      if (state.cursor >= 0) {
        const save = document.createElement("button");
        save.type = "button";
        save.className = "wf-library-state-action";
        save.textContent = "Save current trail";
        save.addEventListener("click", () => openSaveCurrentTrailDialog(session2.opener));
        empty.appendChild(save);
      }
      session2.list.appendChild(empty);
      restoreRenderedFocus();
      return;
    }
    if (session2.trails.length >= MAX_SAVED_TRAILS) {
      const limit = document.createElement("div");
      limit.className = "wf-library-limit";
      limit.textContent = "Saved-trail limit reached. Remove one before saving or duplicating.";
      session2.list.appendChild(limit);
    }
    for (const hit of visible) {
      session2.list.appendChild(buildLibraryRow(session2, hit));
    }
    restoreRenderedFocus();
  }
  registerRenderLibrary(renderLibrary2);
  function buildLibraryState(message, role) {
    const state = document.createElement("div");
    state.className = "wf-library-state";
    if (role) state.setAttribute("role", role);
    const title = document.createElement("strong");
    title.textContent = message;
    state.appendChild(title);
    return state;
  }
  function positionLibraryPanel(panel) {
    if (!host) return;
    const barRect = host.bar.getBoundingClientRect();
    const margin = VIEWPORT_MARGIN;
    const availableWidth = Math.max(0, window.innerWidth - margin * 2);
    const width = Math.min(380, Math.max(280, barRect.width), availableWidth);
    panel.style.width = `${width}px`;
    panel.style.left = `${Math.min(
      Math.max(margin, barRect.left),
      Math.max(margin, window.innerWidth - width - margin)
    )}px`;
    const preferredTop = barRect.bottom + LIBRARY_PANEL_GAP;
    const height = Math.min(panel.getBoundingClientRect().height || 340, window.innerHeight - margin * 2);
    let top = preferredTop;
    if (top + height > window.innerHeight - margin) {
      top = Math.max(margin, barRect.top - height - LIBRARY_PANEL_GAP);
    }
    panel.style.top = `${top}px`;
    panel.style.maxHeight = `${Math.max(180, window.innerHeight - top - margin)}px`;
  }
  function appendHighlightedText(container, value, ranges) {
    let cursor = 0;
    for (const range of ranges) {
      const start = Math.max(cursor, Math.min(value.length, range.start));
      const end = Math.max(start, Math.min(value.length, range.end));
      if (start > cursor) container.appendChild(document.createTextNode(value.slice(cursor, start)));
      if (end > start) {
        const mark = document.createElement("mark");
        mark.className = "wf-library-search-match";
        mark.textContent = value.slice(start, end);
        container.appendChild(mark);
      }
      cursor = end;
    }
    if (cursor < value.length) container.appendChild(document.createTextNode(value.slice(cursor)));
  }
  function buildLibraryRow(session2, hit) {
    const { trail, match } = hit;
    const endpoint = savedTrailEndpoint(trail);
    const pending = pendingTrailIds.has(trail.id);
    const row = document.createElement("div");
    row.className = "wf-library-row";
    row.dataset.trailId = trail.id;
    row.setAttribute("role", "listitem");
    if (trail.pinned) row.classList.add("wf-library-row-pinned");
    if (pending) {
      row.setAttribute("aria-busy", "true");
      row.tabIndex = -1;
    }
    const main = document.createElement("button");
    main.type = "button";
    main.className = "wf-library-row-main";
    main.dataset.libraryAction = "main";
    main.disabled = pending;
    main.setAttribute("aria-label", `Open ${trail.name}`);
    const name = document.createElement("span");
    name.className = "wf-library-row-name";
    if (match?.field === "name") {
      const snippet = createTrailSearchSnippet(trail.name, match.ranges, 48);
      appendHighlightedText(name, snippet.value, snippet.ranges);
    } else name.textContent = trail.name;
    main.appendChild(name);
    const meta = document.createElement("span");
    meta.className = "wf-library-row-meta";
    meta.id = `tabtrail-saved-trail-meta-${allocateLibraryMetaId()}`;
    main.setAttribute("aria-describedby", meta.id);
    if (match && match.field !== "name") {
      const pageNumber = match.entryIndex === null ? "" : ` \xB7 Page ${match.entryIndex + 1}`;
      meta.appendChild(document.createTextNode(`${pagesLabel(trail.entries.length)}${pageNumber} \xB7 `));
      const snippet = createTrailSearchSnippet(match.value, match.ranges, 52);
      appendHighlightedText(meta, snippet.value, snippet.ranges);
    } else {
      const endLabel = endpoint ? entryTitle(endpoint) : "";
      meta.textContent = endLabel ? `${pagesLabel(trail.entries.length)} \xB7 ${endLabel}` : pagesLabel(trail.entries.length);
    }
    main.appendChild(meta);
    main.addEventListener("click", (event) => openLibraryOpenChooser(main, trail, event.detail === 0));
    row.appendChild(main);
    const pin = document.createElement("button");
    pin.type = "button";
    pin.className = "wf-library-pin";
    pin.dataset.libraryAction = "pin";
    pin.textContent = trail.pinned ? "\u2605" : "\u2606";
    pin.title = trail.pinned ? "Unpin trail" : "Pin trail";
    pin.setAttribute("aria-label", `${trail.pinned ? "Unpin" : "Pin"} ${trail.name}`);
    pin.setAttribute("aria-pressed", trail.pinned ? "true" : "false");
    pin.disabled = pending;
    pin.addEventListener("click", () => void togglePinned(session2, trail));
    row.appendChild(pin);
    const more = document.createElement("button");
    more.type = "button";
    more.className = "wf-row-more";
    more.dataset.libraryAction = "more";
    more.textContent = pending ? "\u2026" : "\u22EF";
    more.title = "More";
    more.setAttribute("aria-label", `More options for ${trail.name}`);
    more.disabled = pending;
    more.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openLibraryMenu(session2, row, more, trail, event.detail === 0);
    });
    row.appendChild(more);
    row.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      const active = activeShadowElement(session2.host);
      if (!pending) openLibraryMenu(session2, row, more, trail, !!active && row.contains(active));
    });
    return row;
  }
  function openLibraryOpenChooser(anchor, trail, focusOnOpen) {
    const endpoint = savedTrailEndpoint(trail);
    if (!endpoint || !host) {
      host?.showNotice("Trail has no pages", { tone: "error" });
      return;
    }
    openMenu(anchor, anchor, {
      title: trail.name,
      subtitle: endpoint.url
    }, [
      { label: "Open in current tab", action: () => void navigateSavedTrail(trail, "current") },
      { label: "Open in new tab", action: () => void navigateSavedTrail(trail, "new") }
    ], focusOnOpen);
  }
  function openLibraryMenu(session2, anchor, trigger, trail, focusOnOpen) {
    const endpoint = savedTrailEndpoint(trail);
    const canDuplicate = session2.trails.length < MAX_SAVED_TRAILS;
    const canUpdate = currentCapturedPath() !== null;
    openMenu(anchor, trigger, {
      title: trail.name,
      subtitle: endpoint?.url,
      meta: pagesLabel(trail.entries.length)
    }, [
      { label: "Preview", action: () => openSavedTrailTreePreview(trail, trigger) },
      { label: "Open in current tab", disabled: !endpoint, action: () => void navigateSavedTrail(trail, "current") },
      { label: "Open in new tab", disabled: !endpoint, action: () => void navigateSavedTrail(trail, "new") },
      { label: "Update from current path", disabled: !canUpdate, action: () => openUpdateDialog(trail, trigger) },
      { label: "Rename", action: () => openRenameDialog(trail, trigger) },
      { label: canDuplicate ? "Duplicate" : "Duplicate (limit reached)", disabled: !canDuplicate, action: () => void duplicateTrail(session2, trail) },
      { label: trail.pinned ? "Unpin" : "Pin", action: () => void togglePinned(session2, trail) },
      { label: "Remove trail", danger: true, action: () => void removeTrail(session2, trail) }
    ], focusOnOpen);
  }
  function openMenu(anchor, trigger, detail, items, focusOnOpen = true) {
    if (!host) return;
    closeOverlaySurface("menu");
    let closed = false;
    const handle = showContextMenu({
      layer: host.layer,
      anchor,
      trigger,
      detail,
      items,
      focusOnOpen,
      onClose: () => {
        if (closed) return;
        closed = true;
        dropOverlaySurface("menu");
      }
    });
    pushOverlaySurface("menu", () => {
      if (!closed) handle.close();
    });
  }

  // src/lib/ui/panels/breadcrumbTrail/savedTrailsPanel.ts
  function bindSavedTrailsHost(next) {
    setHost(next);
  }
  function unbindSavedTrailsHost() {
    setHost(null);
    closeAllSavedTrailSurfaces();
  }
  function closeAllSavedTrailSurfaces() {
    closeOverlaySurface("menu");
    closeOverlaySurface("treePreview");
    closeOverlaySurface("nameDialog");
    closeOverlaySurface("library");
  }
  function toggleSavedTrailsLibrary() {
    if (hasOverlaySurface("library")) {
      closeOverlaySurface("library");
      return;
    }
    openLibraryPanel();
  }

  // src/lib/ui/panels/breadcrumbTrail/breadcrumbTrail.ts
  var DEFAULT_POSITION = { xPercent: 50, yPercent: 8 };
  var PREVIEW_VIEWPORT_MARGIN = 12;
  var PREVIEW_GAP = 12;
  var PREVIEW_SIDE_MIN_WIDTH = 460;
  var PREVIEW_DESKTOP_WIDTH = 640;
  var PREVIEW_DESKTOP_HEIGHT = 520;
  var session = null;
  var mainDragStop = null;
  function isBreadcrumbTrailOpen() {
    return session !== null;
  }
  function hideBreadcrumbTrail() {
    if (!session) return;
    dismissPanel();
  }
  function updateBreadcrumbTrail(state) {
    if (!session) return;
    session.state = state;
    if (isOverlaySurfaceBlockingLiveRender()) {
      session.liveRenderPending = true;
      setLiveInteractionBlocked(true);
      return;
    }
    renderBar();
  }
  function updateBreadcrumbTrailSettings(settings) {
    if (!session) return;
    const visibleRowsChanged = session.options.settings.maxVisibleSegments !== settings.maxVisibleSegments;
    session.options.settings = settings;
    if (!visibleRowsChanged) return;
    if (isOverlaySurfaceBlockingLiveRender()) {
      session.liveRenderPending = true;
      setLiveInteractionBlocked(true);
      return;
    }
    renderBar();
  }
  function showBreadcrumbTrail(state, options) {
    const { host: host2, shadow } = createPanelHost();
    const removeInteractionShield = installOverlayInteractionShield(shadow);
    host2.style.pointerEvents = "none";
    const style = document.createElement("style");
    style.textContent = getBaseStyles() + breadcrumbTrail_default + savedTrailsPanel_default;
    shadow.appendChild(style);
    const layer = document.createElement("div");
    layer.className = "wf-layer";
    shadow.appendChild(layer);
    const bar = document.createElement("div");
    bar.className = "wf-bar";
    bar.dataset.tabtrailHitSurface = "";
    bar.dataset.tabtrailWheelSurface = "";
    bar.setAttribute("role", "navigation");
    bar.setAttribute("aria-label", "Navigation trail");
    layer.appendChild(bar);
    const noticeStack = document.createElement("div");
    noticeStack.className = "wf-notice-stack";
    noticeStack.dataset.tabtrailWheelSurface = "";
    noticeStack.dataset.tabtrailScrollRegion = "";
    layer.appendChild(noticeStack);
    session = {
      shadow,
      bar,
      layer,
      options,
      state,
      expanded: false,
      position: options.settings.overlayPosition ?? DEFAULT_POSITION,
      noticeStack,
      statusNoticeCleanup: null,
      undoNoticeCleanups: /* @__PURE__ */ new Set(),
      liveRenderPending: false
    };
    bindSavedTrailsHost({
      layer,
      bar,
      client: options.savedTrailsClient ?? browserSavedTrailsClient,
      getState: () => session?.state ?? { entries: [], cursor: -1 },
      showNotice,
      hideTrail: hideBreadcrumbTrail,
      closeLiveSurfaces: () => {
        closeOverlaySurface("menu");
        closeEntryPreview();
      },
      flushLiveTrailUpdates: () => {
        queueMicrotask(() => {
          if (!session?.liveRenderPending || isOverlaySurfaceBlockingLiveRender()) return;
          renderBar();
        });
      },
      restoreLiveFocus,
      setLiveInteractionBlocked
    });
    applyPosition();
    renderBar();
    const onDocumentKeydown = (event) => {
      if (event.key !== "Escape" || !session) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (closeTopOverlaySurface()) return;
      if (previewElement) {
        closeEntryPreview(true);
        return;
      }
      hideBreadcrumbTrail();
    };
    document.addEventListener("keydown", onDocumentKeydown, true);
    registerPanelCleanup(() => {
      document.removeEventListener("keydown", onDocumentKeydown, true);
      mainDragStop?.();
      mainDragStop = null;
      removeInteractionShield();
      session?.statusNoticeCleanup?.();
      for (const cleanup of session?.undoNoticeCleanups ?? []) cleanup();
      closeAllOverlaySurfaces();
      closeEntryPreview();
      unbindSavedTrailsHost();
      const closing = session;
      session = null;
      closing?.options.callbacks.onClose();
    });
  }
  function applyPosition() {
    if (!session) return;
    const { xPercent, yPercent } = session.position;
    session.bar.style.left = `${xPercent}%`;
    session.bar.style.top = `${yPercent}%`;
    if (previewElement) positionPreviewPane(previewElement);
  }
  function setLiveInteractionBlocked(blocked) {
    if (!session) return;
    session.bar.inert = blocked;
    session.bar.classList.toggle("wf-bar-blocked", blocked);
    if (blocked) session.bar.setAttribute("aria-disabled", "true");
    else session.bar.removeAttribute("aria-disabled");
  }
  function liveEntryKey(entry) {
    return `${entry.timestamp}:${entry.url}`;
  }
  function liveFocusIdentity(opener) {
    const control = opener?.dataset.liveControl;
    if (!control) return null;
    return { control, entryKey: opener.dataset.liveEntryKey };
  }
  function restoreLiveFocus(opener) {
    const identity = liveFocusIdentity(opener);
    scheduleFocusWhenIdle(() => {
      if (!session) return null;
      let target = null;
      if (identity) {
        const candidates = session.bar.querySelectorAll(
          `[data-live-control="${identity.control}"]`
        );
        target = [...candidates].find(
          (candidate) => !identity.entryKey || candidate.dataset.liveEntryKey === identity.entryKey
        ) ?? null;
        if (!target) {
          target = session.bar.querySelector("[data-live-control=library]");
        }
      } else if (opener?.isConnected) {
        target = opener;
      }
      return target;
    });
  }
  function focusLiveControlWhenIdle(control) {
    const marker = document.createElement("span");
    marker.dataset.liveControl = control;
    restoreLiveFocus(marker);
  }
  function visibleIndices(state, maxVisible, expanded) {
    const total = state.entries.length;
    if (expanded || total <= maxVisible) {
      return state.entries.map((_, index) => index);
    }
    const budget = Math.min(Math.max(1, maxVisible), total);
    const selected = /* @__PURE__ */ new Set([0]);
    const addIndex = (index) => {
      if (selected.size >= budget) return;
      if (index < 0 || index >= total) return;
      selected.add(index);
    };
    addIndex(state.cursor);
    addIndex(total - 1);
    for (let distance = 1; selected.size < budget && distance < total; distance += 1) {
      addIndex(state.cursor - distance);
      addIndex(state.cursor + distance);
    }
    return [...selected].sort((a, b) => a - b);
  }
  function renderBar() {
    if (!session) return;
    setLiveInteractionBlocked(isOverlaySurfaceBlockingLiveRender());
    session.liveRenderPending = false;
    const { bar, state, options } = session;
    const { settings, callbacks } = options;
    const activeLiveControl = session.shadow.activeElement instanceof HTMLElement ? session.shadow.activeElement : null;
    const menuReturnFocus = liveMenuTrigger;
    const previewReturn = previewElement ? previewReturnFocus : null;
    closeOverlaySurface("menu");
    closeEntryPreview();
    if (activeLiveControl?.dataset.liveControl) restoreLiveFocus(activeLiveControl);
    if (menuReturnFocus) restoreLiveFocus(menuReturnFocus);
    if (previewReturn) restoreLiveFocus(previewReturn);
    bar.textContent = "";
    bar.appendChild(buildBranchHeader(callbacks));
    const branchList = buildBranchList();
    bar.appendChild(branchList);
    if (state.entries.length === 0) {
      const empty = document.createElement("span");
      empty.className = "wf-empty";
      empty.textContent = "No trail yet. Start clicking links to build one.";
      branchList.appendChild(empty);
      return;
    }
    const indices = visibleIndices(state, settings.maxVisibleSegments, session.expanded);
    const forkIndex = state.entries.reduce(
      (latest, entry, index) => index > 0 && !entry.historyBacked ? index : latest,
      -1
    );
    let previousRendered = null;
    for (const index of indices) {
      if (previousRendered !== null) {
        if (index > previousRendered + 1) {
          const firstHiddenIndex = previousRendered + 1;
          branchList.appendChild(branchConnectorElement(state.entries[firstHiddenIndex]));
          branchList.appendChild(buildMorePill(index - previousRendered - 1));
        }
        branchList.appendChild(branchConnectorElement(state.entries[index]));
      }
      branchList.appendChild(buildBranchRow(index, state, callbacks, index === forkIndex));
      previousRendered = index;
    }
    if (session.expanded && state.entries.length > settings.maxVisibleSegments) {
      branchList.appendChild(buildCollapsePill());
    }
  }
  function buildBranchHeader(callbacks) {
    const header = document.createElement("div");
    header.className = "wf-branch-header";
    const leftChrome = document.createElement("div");
    leftChrome.className = "wf-header-left";
    leftChrome.appendChild(buildSettingsButton(callbacks));
    leftChrome.appendChild(buildLibraryButton());
    header.appendChild(leftChrome);
    const title = document.createElement("span");
    title.className = "wf-branch-title";
    title.textContent = "In-Page Trail";
    header.appendChild(title);
    header.appendChild(buildGrip());
    header.appendChild(buildCloseButton());
    return header;
  }
  function buildBranchList() {
    const branchList = document.createElement("div");
    branchList.className = "wf-branch-list";
    branchList.dataset.tabtrailScrollRegion = "";
    return branchList;
  }
  function buildGrip() {
    const grip = document.createElement("span");
    grip.className = "wf-grip";
    grip.textContent = "\u283F";
    grip.title = "Drag to move";
    grip.setAttribute("aria-hidden", "true");
    grip.addEventListener("pointerdown", startDrag);
    return grip;
  }
  function buildSettingsButton(callbacks) {
    const settings = document.createElement("button");
    settings.className = "wf-settings";
    settings.type = "button";
    settings.textContent = "\u2699";
    settings.title = "Open settings";
    settings.setAttribute("aria-label", "Open settings");
    settings.dataset.liveControl = "settings";
    settings.addEventListener("click", () => callbacks.onOpenOptions());
    return settings;
  }
  function buildLibraryButton() {
    const library = document.createElement("button");
    library.className = "wf-library";
    library.type = "button";
    library.textContent = "\u2630";
    library.title = "Saved trails";
    library.setAttribute("aria-label", "Saved trails");
    library.setAttribute("aria-haspopup", "dialog");
    library.setAttribute("aria-expanded", "false");
    library.dataset.liveControl = "library";
    library.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      toggleSavedTrailsLibrary();
    });
    return library;
  }
  function buildCloseButton() {
    const close = document.createElement("button");
    close.className = "wf-close";
    close.type = "button";
    close.textContent = "\u2715";
    close.title = "Hide (Esc)";
    close.setAttribute("aria-label", "Hide trail");
    close.dataset.liveControl = "close";
    close.addEventListener("click", () => hideBreadcrumbTrail());
    return close;
  }
  function restoreFocusAfterNotice(noticeSession) {
    scheduleFocusWhenIdle(() => {
      if (session !== noticeSession) return null;
      const target = noticeSession.noticeStack.querySelector(".wf-notice-action:not(:disabled)") ?? noticeSession.layer.querySelector(".wf-library-search") ?? noticeSession.layer.querySelector(".wf-library-row-main") ?? noticeSession.bar.querySelector("[data-live-control=library]");
      return target;
    });
  }
  function showNotice(message, options = {}) {
    if (!session) return;
    const noticeSession = session;
    const undoLane = options.undo === true;
    if (!undoLane) noticeSession.statusNoticeCleanup?.();
    const notice = document.createElement("div");
    notice.className = `wf-notice wf-notice-${options.tone ?? "info"} ${undoLane ? "wf-notice-undo" : "wf-notice-status"}`;
    notice.dataset.tabtrailHitSurface = "";
    notice.setAttribute("role", options.tone === "error" ? "alert" : "status");
    notice.setAttribute("aria-live", options.tone === "error" ? "assertive" : "polite");
    const copy = document.createElement("span");
    copy.className = "wf-notice-copy";
    copy.textContent = message;
    notice.appendChild(copy);
    if (options.actionLabel && options.action) {
      const action = document.createElement("button");
      action.type = "button";
      action.className = "wf-notice-action";
      action.textContent = options.actionLabel;
      action.addEventListener("click", () => {
        if (!options.action || action.disabled) return;
        action.disabled = true;
        action.textContent = "Working\u2026";
        void Promise.resolve(options.action()).then(() => {
          if (notice.isConnected) remove();
        }).catch(() => {
          if (session === noticeSession) {
            showNotice("Action failed", { tone: "error", durationMs: 5e3 });
          }
        });
      });
      notice.appendChild(action);
    }
    if (undoLane) {
      noticeSession.noticeStack.appendChild(notice);
    } else {
      noticeSession.noticeStack.prepend(notice);
    }
    let remainingMs = options.durationMs ?? (options.action ? 8e3 : 2200);
    let startedAt = Date.now();
    let timer = null;
    const remove = () => {
      const ownedFocus = notice.contains(noticeSession.shadow.activeElement);
      if (timer != null) window.clearTimeout(timer);
      timer = null;
      notice.remove();
      if (undoLane) {
        noticeSession.undoNoticeCleanups.delete(remove);
      } else if (noticeSession.statusNoticeCleanup === remove) {
        noticeSession.statusNoticeCleanup = null;
      }
      if (ownedFocus) restoreFocusAfterNotice(noticeSession);
    };
    const resume = () => {
      if (timer != null || remainingMs <= 0) return;
      startedAt = Date.now();
      timer = window.setTimeout(remove, remainingMs);
    };
    const pause = () => {
      if (timer == null) return;
      window.clearTimeout(timer);
      timer = null;
      remainingMs = Math.max(0, remainingMs - (Date.now() - startedAt));
    };
    notice.addEventListener("mouseenter", pause);
    notice.addEventListener("mouseleave", resume);
    notice.addEventListener("focusin", pause);
    notice.addEventListener("focusout", resume);
    if (undoLane) noticeSession.undoNoticeCleanups.add(remove);
    else noticeSession.statusNoticeCleanup = remove;
    resume();
  }
  function buildMorePill(hiddenCount) {
    const pill = document.createElement("button");
    pill.type = "button";
    pill.className = "wf-more";
    pill.dataset.liveControl = "expand";
    pill.textContent = `+${hiddenCount} more`;
    pill.title = "Show the full trail";
    pill.addEventListener("click", () => {
      if (!session) return;
      session.expanded = true;
      renderBar();
      focusLiveControlWhenIdle("collapse");
    });
    return pill;
  }
  function buildCollapsePill() {
    const pill = document.createElement("button");
    pill.type = "button";
    pill.className = "wf-more wf-more-collapse";
    pill.dataset.liveControl = "collapse";
    pill.textContent = "Show less";
    pill.title = "Collapse the trail";
    pill.addEventListener("click", () => {
      if (!session) return;
      session.expanded = false;
      renderBar();
      focusLiveControlWhenIdle("expand");
    });
    return pill;
  }
  function buildBranchRow(index, state, callbacks, isFork) {
    const entry = state.entries[index];
    const isCurrent = index === state.cursor;
    const row = document.createElement("div");
    row.className = "wf-branch-row";
    if (isCurrent) row.classList.add("wf-branch-row-current");
    if (index > state.cursor) row.classList.add("wf-branch-row-forward");
    if (isFork) {
      row.classList.add("wf-branch-row-fork");
      row.title = "Direct-navigation boundary \u2014 earlier pages are outside native browser history";
    }
    const main = document.createElement(isCurrent ? "div" : "button");
    if (!isCurrent) main.type = "button";
    main.className = "wf-branch-row-main";
    main.dataset.liveControl = "row-main";
    main.dataset.liveEntryKey = liveEntryKey(entry);
    if (isCurrent) {
      main.setAttribute("role", "group");
      main.setAttribute("aria-current", "page");
    }
    if (isFork) {
      main.setAttribute(
        "aria-label",
        isCurrent ? `${entryTitle(entry)}. Current page. Direct-navigation boundary; earlier pages are outside native browser history.` : `${entryTitle(entry)}. Direct-navigation boundary; selecting this page navigates directly.`
      );
    }
    const node = document.createElement("span");
    node.className = "wf-branch-node";
    node.setAttribute("aria-hidden", "true");
    main.appendChild(node);
    const content = document.createElement("div");
    content.className = "wf-branch-entry";
    const title = document.createElement("span");
    title.className = "wf-branch-entry-title";
    title.textContent = entryTitle(entry);
    content.appendChild(title);
    const url = document.createElement("span");
    url.className = "wf-branch-entry-url";
    url.textContent = entryUrlSubtitle(entry);
    content.appendChild(url);
    main.appendChild(content);
    row.appendChild(main);
    const more = buildRowMoreButton(row, index, entry, callbacks);
    row.appendChild(more);
    if (!isCurrent) {
      main.addEventListener("click", (event) => {
        event.preventDefault();
        callbacks.onJump(index);
      });
    }
    row.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const focusOnOpen = session?.shadow.activeElement instanceof HTMLElement && row.contains(session.shadow.activeElement);
      openEntryMenu(row, index, entry, callbacks, more, focusOnOpen);
    });
    return row;
  }
  function buildRowMoreButton(anchor, index, entry, callbacks) {
    const more = document.createElement("button");
    more.className = "wf-row-more";
    more.type = "button";
    more.textContent = "\u22EF";
    more.title = "More";
    more.setAttribute("aria-label", "More options for this page");
    more.dataset.liveControl = "row-more";
    more.dataset.liveEntryKey = liveEntryKey(entry);
    more.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      toggleEntryMenu(anchor, more, index, entry, callbacks, event.detail === 0);
    });
    return more;
  }
  var previewElement = null;
  var previewedRowElement = null;
  var previewManualPosition = null;
  var previewDragStop = null;
  var previewReturnFocus = null;
  function closeEntryPreview(restore = false) {
    const returnFocus = previewReturnFocus;
    previewDragStop?.();
    previewDragStop = null;
    previewManualPosition = null;
    previewedRowElement?.classList.remove("wf-branch-row-previewed");
    previewedRowElement = null;
    previewElement?.remove();
    previewElement = null;
    previewReturnFocus = null;
    if (restore) scheduleFocusWhenIdle(() => returnFocus);
  }
  function openEntryPreview(anchor, entry, onOpenInNewTab, returnFocus) {
    if (!session) return;
    closeEntryPreview();
    if (anchor) {
      anchor.classList.add("wf-branch-row-previewed");
      previewedRowElement = anchor;
    }
    const preview = document.createElement("div");
    preview.className = "wf-preview-pane";
    preview.dataset.tabtrailHitSurface = "";
    preview.setAttribute("role", "dialog");
    preview.setAttribute("aria-modal", "false");
    const header = document.createElement("div");
    header.className = "wf-preview-pane-header";
    const identity = document.createElement("div");
    identity.className = "wf-preview-pane-identity";
    const kicker = document.createElement("div");
    kicker.className = "wf-preview-pane-kicker";
    kicker.textContent = "Preview";
    identity.appendChild(kicker);
    const title = document.createElement("div");
    title.id = "tabtrail-live-preview-title";
    title.className = "wf-preview-pane-title";
    title.textContent = entryTitle(entry);
    identity.appendChild(title);
    const url = document.createElement("div");
    url.id = "tabtrail-live-preview-url";
    url.className = "wf-preview-pane-url";
    url.textContent = entryUrlSubtitle(entry);
    identity.appendChild(url);
    preview.setAttribute("aria-labelledby", title.id);
    preview.setAttribute("aria-describedby", url.id);
    const actions = document.createElement("div");
    actions.className = "wf-preview-pane-actions";
    const drag = document.createElement("span");
    drag.className = "wf-preview-pane-drag";
    drag.textContent = "\u283F";
    drag.title = "Move preview pane";
    drag.setAttribute("aria-hidden", "true");
    drag.addEventListener("pointerdown", (event) => {
      if (!previewElement) return;
      previewElement.classList.remove("wf-preview-pane-bottom");
      previewDragStop?.();
      previewDragStop = startFreePixelDrag(previewElement, event, {
        draggingClass: "wf-preview-pane-dragging",
        onMove: (position) => {
          previewManualPosition = position;
        },
        onEnd: () => {
          previewDragStop = null;
        }
      });
    });
    const open = document.createElement("button");
    open.className = "wf-preview-pane-action";
    open.type = "button";
    open.textContent = "\u2197";
    open.title = "Open in new tab";
    open.setAttribute("aria-label", "Open previewed page in a new tab");
    open.addEventListener("click", () => onOpenInNewTab());
    const close = document.createElement("button");
    close.className = "wf-preview-pane-close";
    close.type = "button";
    close.textContent = "\u2715";
    close.title = "Close preview";
    close.setAttribute("aria-label", "Close page preview");
    close.addEventListener("click", () => closeEntryPreview(true));
    actions.appendChild(drag);
    actions.appendChild(open);
    actions.appendChild(close);
    header.appendChild(identity);
    header.appendChild(actions);
    const frame = document.createElement("iframe");
    frame.className = "wf-preview-pane-frame";
    frame.title = `Preview: ${entryTitle(entry)}`;
    frame.referrerPolicy = "no-referrer";
    frame.setAttribute("sandbox", "allow-forms allow-popups allow-same-origin allow-scripts");
    frame.src = entry.url;
    preview.appendChild(header);
    preview.appendChild(frame);
    session.layer.appendChild(preview);
    positionPreviewPane(preview);
    previewElement = preview;
    previewReturnFocus = returnFocus;
    close.focus({ preventScroll: true });
  }
  function positionPreviewPane(preview) {
    if (!session) return;
    const barRect = session.bar.getBoundingClientRect();
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const margin = PREVIEW_VIEWPORT_MARGIN;
    const availableHeight = Math.max(160, viewportHeight - margin * 2);
    const rightSpace = viewportWidth - barRect.right - PREVIEW_GAP - margin;
    const leftSpace = barRect.left - PREVIEW_GAP - margin;
    const canUseRight = viewportWidth >= 760 && rightSpace >= PREVIEW_SIDE_MIN_WIDTH;
    const canUseLeft = viewportWidth >= 760 && leftSpace >= PREVIEW_SIDE_MIN_WIDTH;
    preview.classList.remove("wf-preview-pane-bottom");
    if (previewManualPosition) {
      const rect = preview.getBoundingClientRect();
      const position = clampInViewport(
        previewManualPosition.left,
        previewManualPosition.top,
        rect.width || PREVIEW_DESKTOP_WIDTH,
        rect.height || PREVIEW_DESKTOP_HEIGHT,
        margin
      );
      previewManualPosition = position;
      preview.style.left = `${position.left}px`;
      preview.style.top = `${position.top}px`;
      return;
    }
    preview.style.width = "";
    preview.style.height = "";
    preview.style.left = "";
    preview.style.top = "";
    if (canUseRight || canUseLeft) {
      const useRight = canUseRight && (!canUseLeft || rightSpace >= leftSpace);
      const availableWidth = useRight ? rightSpace : leftSpace;
      const width2 = Math.min(PREVIEW_DESKTOP_WIDTH, availableWidth);
      const height2 = Math.min(PREVIEW_DESKTOP_HEIGHT, availableHeight);
      const left = useRight ? barRect.right + PREVIEW_GAP : barRect.left - PREVIEW_GAP - width2;
      const top = Math.min(
        Math.max(margin, barRect.top),
        Math.max(margin, viewportHeight - height2 - margin)
      );
      preview.style.width = `${width2}px`;
      preview.style.height = `${height2}px`;
      preview.style.left = `${left}px`;
      preview.style.top = `${top}px`;
      return;
    }
    preview.classList.add("wf-preview-pane-bottom");
    const width = Math.max(0, viewportWidth - margin * 2);
    const targetHeight = Math.round(viewportHeight * 0.66);
    const height = Math.min(Math.max(260, targetHeight), availableHeight);
    preview.style.width = `${width}px`;
    preview.style.height = `${height}px`;
    preview.style.left = `${margin}px`;
    preview.style.top = `${Math.max(margin, viewportHeight - height - margin)}px`;
  }
  function toggleEntryMenu(anchor, trigger, index, entry, callbacks, focusOnOpen) {
    if (liveMenuTrigger === trigger) {
      closeOverlaySurface("menu");
      return;
    }
    openEntryMenu(anchor, index, entry, callbacks, trigger, focusOnOpen);
  }
  var liveMenuTrigger = null;
  function openEntryMenu(anchor, index, entry, callbacks, trigger, focusOnOpen) {
    if (!session) return;
    closeOverlaySurface("menu");
    let closed = false;
    liveMenuTrigger = trigger;
    const handle = showContextMenu({
      layer: session.layer,
      anchor,
      trigger,
      detail: {
        title: entryTitle(entry),
        subtitle: entry.url,
        meta: `Visited ${formatTrailTimestamp(entry.timestamp, Date.now())}`
      },
      items: [
        {
          label: "Preview",
          action: () => openEntryPreview(anchor, entry, () => callbacks.onOpenInNewTab(index), trigger)
        },
        { label: "Open in new tab", action: () => callbacks.onOpenInNewTab(index) },
        { label: "Open in new window", action: () => callbacks.onOpenInNewWindow(index) },
        { label: "Copy URL", action: () => void copyText(entry.url) },
        {
          label: "Save trail up to this point in path",
          action: () => openSaveTrailDialog(index, trigger)
        }
      ],
      focusOnOpen,
      onClose: () => {
        if (closed) return;
        closed = true;
        liveMenuTrigger = null;
        dropOverlaySurface("menu");
      }
    });
    pushOverlaySurface("menu", () => {
      if (!closed) handle.close();
    });
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return;
    } catch (_) {
    }
    const scratch = document.createElement("textarea");
    scratch.value = text;
    scratch.style.cssText = "position:fixed;opacity:0;pointer-events:none;";
    document.body.appendChild(scratch);
    scratch.select();
    try {
      document.execCommand("copy");
    } finally {
      scratch.remove();
    }
  }
  function startDrag(event) {
    if (!session) return;
    mainDragStop?.();
    mainDragStop = null;
    event.preventDefault();
    const dragSession = session;
    const { bar } = dragSession;
    const captureTarget = event.currentTarget instanceof HTMLElement ? event.currentTarget : bar;
    const pointerId = event.pointerId;
    try {
      captureTarget.setPointerCapture(pointerId);
    } catch (_) {
    }
    const barRect = bar.getBoundingClientRect();
    const grabOffsetX = event.clientX - (barRect.left + barRect.width / 2);
    const grabOffsetY = event.clientY - barRect.top;
    bar.classList.add("wf-dragging");
    const onMove = (moveEvent) => {
      if (moveEvent.pointerId !== pointerId) return;
      if (session !== dragSession) return;
      const x = (moveEvent.clientX - grabOffsetX) / window.innerWidth * 100;
      const y = (moveEvent.clientY - grabOffsetY) / window.innerHeight * 100;
      dragSession.position = {
        xPercent: Math.min(Math.max(x, 0), 100),
        yPercent: Math.min(Math.max(y, 0), 96)
      };
      applyPosition();
    };
    let stopped = false;
    const finish = (persist) => {
      if (stopped) return;
      stopped = true;
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onPointerEnd, true);
      window.removeEventListener("pointercancel", onPointerEnd, true);
      try {
        if (captureTarget.hasPointerCapture(pointerId)) {
          captureTarget.releasePointerCapture(pointerId);
        }
      } catch (_) {
      }
      bar.classList.remove("wf-dragging");
      if (mainDragStop === cancel) mainDragStop = null;
      if (persist && session === dragSession) {
        dragSession.options.callbacks.onPositionChange(dragSession.position);
      }
    };
    const onPointerEnd = (endEvent) => {
      if (endEvent.pointerId === pointerId) finish(true);
    };
    const cancel = () => finish(false);
    mainDragStop = cancel;
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onPointerEnd, true);
    window.addEventListener("pointercancel", onPointerEnd, true);
  }

  // src/entryPoints/overlayFrame/overlayFrame.ts
  var RPC_TIMEOUT_MS = 15e3;
  var MOUSE_CHORD_SWALLOW_WINDOW_MS = 600;
  var HIT_SURFACE_SELECTOR = "[data-tabtrail-hit-surface]";
  var port = null;
  var initialized = false;
  var shuttingDown = false;
  var latestSettings = null;
  var nextRequestId = 0;
  var nextSurfaceSequence = 0;
  var geometryFrame = 0;
  var previousSurfaceRects = [];
  var previousLayoutKey = "";
  var sendContractionNextFrame = false;
  var swallowMouseUntil = 0;
  var swallowedMouseButton = -1;
  var pendingRpcs = /* @__PURE__ */ new Map();
  var savedTrailSubscribers = /* @__PURE__ */ new Set();
  var candidatePorts = /* @__PURE__ */ new Set();
  function postToHost(message) {
    if (!port) return;
    port.postMessage(message);
  }
  function rejectPendingRpcs(reason) {
    for (const pending of pendingRpcs.values()) {
      window.clearTimeout(pending.timeout);
      pending.reject(new Error(reason));
    }
    pendingRpcs.clear();
  }
  function requestHost(method, params) {
    if (!port || shuttingDown) return Promise.reject(new Error("Overlay host disconnected"));
    const requestId = ++nextRequestId;
    const request = { requestId, method, params };
    return new Promise((resolve, reject) => {
      const timeout = window.setTimeout(() => {
        pendingRpcs.delete(requestId);
        reject(new Error("Overlay request timed out"));
      }, RPC_TIMEOUT_MS);
      pendingRpcs.set(requestId, {
        method,
        timeout,
        resolve,
        reject
      });
      postToHost({
        type: "FRAME_RPC_REQUEST",
        version: OVERLAY_FRAME_PROTOCOL_VERSION,
        request
      });
    });
  }
  function savedFailureReason(result, fallback) {
    return result.reason || fallback;
  }
  function asSavedMutationResult(result, fallback) {
    return result.ok ? result : { ok: false, reason: savedFailureReason(result, fallback) };
  }
  var savedTrailsClient = {
    load: async () => {
      const result = await requestHost("SAVED_LOAD", {});
      if (result.ok) return result.trails;
      throw new Error(savedFailureReason(result, "Could not load saved trails"));
    },
    subscribe: (onChanged) => {
      savedTrailSubscribers.add(onChanged);
      return () => {
        savedTrailSubscribers.delete(onChanged);
      };
    },
    open: (path, mode) => requestHost("SAVED_OPEN", { path, mode }),
    save: async (path, name) => asSavedMutationResult(
      await requestHost("SAVED_SAVE", { path, name }),
      "Could not save trail"
    ),
    rename: async (id, name) => asSavedMutationResult(
      await requestHost("SAVED_RENAME", { id, name }),
      "Could not rename trail"
    ),
    duplicate: async (id) => asSavedMutationResult(
      await requestHost("SAVED_DUPLICATE", { id }),
      "Could not duplicate trail"
    ),
    replace: async (id, path, expectedPath) => {
      const result = await requestHost("SAVED_REPLACE", { id, path, expectedPath });
      return result.ok ? result : { ok: false, reason: savedFailureReason(result, "Could not update trail") };
    },
    setPinned: async (id, pinned) => asSavedMutationResult(
      await requestHost("SAVED_SET_PINNED", { id, pinned }),
      "Could not change pinned state"
    ),
    delete: async (id) => asSavedMutationResult(
      await requestHost("SAVED_DELETE", { id }),
      "Could not remove trail"
    ),
    restore: async (trail) => asSavedMutationResult(
      await requestHost("SAVED_RESTORE", { trail }),
      "Could not restore trail"
    )
  };
  function currentPanelShadow() {
    return document.getElementById("ht-panel-host")?.shadowRoot ?? null;
  }
  function collectSurfaceRects() {
    const shadow = currentPanelShadow();
    if (!shadow) return [];
    const rects = [];
    let noticesRect = null;
    for (const element of shadow.querySelectorAll(HIT_SURFACE_SELECTOR)) {
      if (element.getClientRects().length === 0) continue;
      const rect = element.getBoundingClientRect();
      if (!Number.isFinite(rect.x) || !Number.isFinite(rect.y) || !Number.isFinite(rect.width) || !Number.isFinite(rect.height) || rect.width <= 0 || rect.height <= 0) continue;
      const surface = { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
      if (element.classList.contains("wf-notice")) {
        if (!noticesRect) {
          noticesRect = surface;
        } else {
          const left = Math.min(noticesRect.x, surface.x);
          const top = Math.min(noticesRect.y, surface.y);
          const right = Math.max(noticesRect.x + noticesRect.width, surface.x + surface.width);
          const bottom = Math.max(noticesRect.y + noticesRect.height, surface.y + surface.height);
          noticesRect = { x: left, y: top, width: right - left, height: bottom - top };
        }
        continue;
      }
      rects.push(surface);
    }
    if (noticesRect) rects.push(noticesRect);
    return rects;
  }
  function surfaceLayoutKey(rects) {
    return `${window.innerWidth}x${window.innerHeight}:` + rects.map((rect) => `${rect.x.toFixed(2)},${rect.y.toFixed(2)},${rect.width.toFixed(2)},${rect.height.toFixed(2)}`).join(";");
  }
  function uniqueRects(rects) {
    const seen = /* @__PURE__ */ new Set();
    const unique = [];
    for (const rect of rects) {
      const key = `${rect.x}:${rect.y}:${rect.width}:${rect.height}`;
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(rect);
    }
    return unique;
  }
  function sendSurfaceRects(rects) {
    if (rects.length > OVERLAY_FRAME_MAX_SURFACES) {
      postToHost({
        type: "FRAME_ERROR",
        version: OVERLAY_FRAME_PROTOCOL_VERSION,
        reason: "Overlay produced too many interaction surfaces"
      });
      return;
    }
    postToHost({
      type: "FRAME_SURFACES_UPDATED",
      version: OVERLAY_FRAME_PROTOCOL_VERSION,
      sequence: nextSurfaceSequence++,
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      rects
    });
  }
  function sendMeasuredSurfaceGeometry(force) {
    const currentRects = collectSurfaceRects();
    const layoutKey = surfaceLayoutKey(currentRects);
    if (layoutKey !== previousLayoutKey) {
      const transitionalRects = uniqueRects([...previousSurfaceRects, ...currentRects]);
      sendSurfaceRects(transitionalRects);
      previousSurfaceRects = currentRects;
      previousLayoutKey = layoutKey;
      sendContractionNextFrame = true;
    } else if (force || sendContractionNextFrame) {
      sendSurfaceRects(currentRects);
      sendContractionNextFrame = false;
    }
  }
  function reportSurfaceGeometry() {
    if (!port || shuttingDown) return;
    sendMeasuredSurfaceGeometry(false);
    geometryFrame = requestAnimationFrame(reportSurfaceGeometry);
  }
  function deepActiveElement() {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    return active;
  }
  function focusableControls() {
    const root = currentPanelShadow();
    if (!root) return [];
    const selector = [
      "button:not(:disabled)",
      "input:not(:disabled)",
      "select:not(:disabled)",
      "textarea:not(:disabled)",
      "a[href]",
      "[tabindex]:not([tabindex='-1'])"
    ].join(",");
    return [...root.querySelectorAll(selector)].filter((element) => !element.hidden && element.getClientRects().length > 0 && element.closest("[inert]") === null);
  }
  function releaseFocusAtTabBoundary(event) {
    if (event.key !== "Tab") return;
    const controls = focusableControls();
    const active = deepActiveElement();
    if (controls.length === 0 || !(active instanceof HTMLElement)) return;
    const atBoundary = event.shiftKey ? active === controls[0] : active === controls[controls.length - 1];
    if (!atBoundary) return;
    postToHost({
      type: "FRAME_FOCUS_OWNERSHIP",
      version: OVERLAY_FRAME_PROTOCOL_VERSION,
      owned: false
    });
  }
  function triggerEvent(event) {
    if (event instanceof KeyboardEvent) {
      return {
        type: "keydown",
        code: event.code,
        altKey: event.altKey,
        ctrlKey: event.ctrlKey,
        metaKey: event.metaKey,
        shiftKey: event.shiftKey,
        repeat: event.repeat,
        isTrusted: event.isTrusted
      };
    }
    return {
      type: "mousedown",
      button: event.button,
      altKey: event.altKey,
      ctrlKey: event.ctrlKey,
      metaKey: event.metaKey,
      shiftKey: event.shiftKey,
      isTrusted: event.isTrusted
    };
  }
  function onFrameKeyDown(event) {
    releaseFocusAtTabBoundary(event);
    if (!latestSettings || !matchesToggleTrigger(triggerEvent(event), latestSettings.trigger)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    void requestHost("LIVE_CLOSE", {}).catch(() => {
    });
  }
  function onFrameMouseDown(event) {
    if (!latestSettings || !matchesToggleTrigger(triggerEvent(event), latestSettings.trigger)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    swallowMouseUntil = performance.now() + MOUSE_CHORD_SWALLOW_WINDOW_MS;
    swallowedMouseButton = event.button;
    void requestHost("LIVE_CLOSE", {}).catch(() => {
    });
  }
  function onFrameMouseFollowUp(event) {
    if (performance.now() > swallowMouseUntil) return;
    const relevant = event.type === "contextmenu" ? swallowedMouseButton === 2 : event.button === swallowedMouseButton;
    if (!relevant) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }
  function claimFocusOwnership() {
    postToHost({
      type: "FRAME_FOCUS_OWNERSHIP",
      version: OVERLAY_FRAME_PROTOCOL_VERSION,
      owned: true
    });
  }
  function dispatchEscape() {
    document.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Escape",
      code: "Escape",
      bubbles: true,
      cancelable: true
    }));
  }
  function stopFrame(reason) {
    if (shuttingDown) return;
    shuttingDown = true;
    cancelAnimationFrame(geometryFrame);
    rejectPendingRpcs(reason);
    savedTrailSubscribers.clear();
    if (isBreadcrumbTrailOpen()) hideBreadcrumbTrail();
    port?.close();
    port = null;
  }
  function initializeUi(state, settings) {
    if (initialized) throw new Error("Overlay frame initialized twice");
    initialized = true;
    latestSettings = settings;
    showBreadcrumbTrail(state, {
      settings,
      savedTrailsClient,
      callbacks: {
        onJump: (index) => {
          void requestHost("LIVE_JUMP", { index }).catch(() => {
          });
        },
        onOpenInNewTab: (index) => {
          void requestHost("LIVE_OPEN_NEW_TAB", { index }).catch(() => {
          });
        },
        onOpenInNewWindow: (index) => {
          void requestHost("LIVE_OPEN_NEW_WINDOW", { index }).catch(() => {
          });
        },
        onOpenOptions: () => {
          void requestHost("LIVE_OPEN_OPTIONS", {}).catch(() => {
          });
        },
        onClose: () => {
          if (!shuttingDown) void requestHost("LIVE_CLOSE", {}).catch(() => {
          });
        },
        onPositionChange: (position) => {
          void requestHost("LIVE_SET_POSITION", { position }).catch(() => {
          });
        }
      }
    });
    reportSurfaceGeometry();
  }
  function receiveHostMessage(received) {
    if (!isOverlayHostToFrameMessage(received)) {
      postToHost({
        type: "FRAME_ERROR",
        version: OVERLAY_FRAME_PROTOCOL_VERSION,
        reason: "Invalid overlay host message"
      });
      stopFrame("Invalid overlay host message");
      return;
    }
    const message = received;
    switch (message.type) {
      case "HOST_INIT":
        try {
          initializeUi(message.state, message.settings);
        } catch (_) {
          postToHost({
            type: "FRAME_ERROR",
            version: OVERLAY_FRAME_PROTOCOL_VERSION,
            reason: "Overlay UI failed to initialize"
          });
        }
        return;
      case "HOST_TRAIL_UPDATED":
        if (initialized) updateBreadcrumbTrail(message.state);
        return;
      case "HOST_SETTINGS_UPDATED":
        latestSettings = message.settings;
        if (initialized) updateBreadcrumbTrailSettings(message.settings);
        return;
      case "HOST_SAVED_TRAILS_UPDATED":
        for (const subscriber of savedTrailSubscribers) subscriber(message.trails);
        return;
      case "HOST_RPC_RESPONSE": {
        const pending = pendingRpcs.get(message.response.requestId);
        if (!pending) return;
        if (pending.method !== message.response.method) {
          stopFrame("Overlay response method mismatch");
          return;
        }
        pendingRpcs.delete(message.response.requestId);
        window.clearTimeout(pending.timeout);
        pending.resolve(message.response.result);
        return;
      }
      case "HOST_DISMISS_TRANSIENTS":
        closeOverlaySurface("menu");
        return;
      case "HOST_FOCUS_RELEASED":
        return;
      case "HOST_REQUEST_SURFACES":
        sendMeasuredSurfaceGeometry(true);
        return;
      case "HOST_ESCAPE":
        dispatchEscape();
        return;
      case "HOST_PING":
        postToHost({
          type: "FRAME_PONG",
          version: OVERLAY_FRAME_PROTOCOL_VERSION,
          heartbeatId: message.heartbeatId
        });
        return;
      case "HOST_SHUTDOWN":
        stopFrame(message.reason || "Overlay host closed");
        return;
    }
  }
  function acceptConnection(connection) {
    port = connection.port;
    for (const candidate of candidatePorts) {
      if (candidate !== port) candidate.close();
    }
    candidatePorts.clear();
    window.removeEventListener("message", onBootstrapMessage);
    port.addEventListener("message", (event) => receiveHostMessage(event.data));
    port.addEventListener("messageerror", () => stopFrame("Overlay message could not be decoded"));
    port.start();
    document.addEventListener("focusin", claimFocusOwnership, true);
    document.addEventListener("pointerdown", claimFocusOwnership, true);
    document.addEventListener("keydown", onFrameKeyDown, true);
    document.addEventListener("mousedown", onFrameMouseDown, true);
    document.addEventListener("auxclick", onFrameMouseFollowUp, true);
    document.addEventListener("click", onFrameMouseFollowUp, true);
    document.addEventListener("contextmenu", onFrameMouseFollowUp, true);
    postToHost({ type: "FRAME_READY", version: OVERLAY_FRAME_PROTOCOL_VERSION });
  }
  function onBootstrapMessage(event) {
    if (event.source !== window.parent || port) return;
    const connection = parseOverlayFrameConnectEvent(event);
    if (!connection) return;
    candidatePorts.add(connection.port);
    void claimOverlayFrame(connection.message.nonce).then((result) => {
      if (port || !result.ok) {
        candidatePorts.delete(connection.port);
        connection.port.close();
        return;
      }
      acceptConnection(connection);
    }).catch(() => {
      candidatePorts.delete(connection.port);
      connection.port.close();
    });
  }
  window.addEventListener("message", onBootstrapMessage);
})();
