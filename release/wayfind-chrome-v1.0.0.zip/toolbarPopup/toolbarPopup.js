"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/wayfind.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var WAYFIND_STORAGE_KEYS = {
    settings: "wayfindSettings"
  };
  var WAYFIND_MODIFIER_KEYS = [
    "alt",
    "ctrl",
    "super"
  ];
  var TRIGGER_KEY_CODE_PATTERN = /^(?:Key[A-Z]|Digit[0-9])$/;
  var TRIGGER_MOUSE_BUTTONS = [1, 2, 3, 4];
  var MIN_VISIBLE_SEGMENTS = 4;
  var MAX_VISIBLE_SEGMENTS = 20;
  var DEFAULT_WAYFIND_TRIGGER = {
    modifier: "alt",
    withShift: false,
    kind: "key",
    keyCode: "KeyH",
    mouseButton: 1
  };
  var DEFAULT_WAYFIND_SETTINGS = {
    trigger: DEFAULT_WAYFIND_TRIGGER,
    showTransitionArrows: true,
    overlayPosition: null,
    maxVisibleSegments: 8
  };
  function normalizeModifierKey(value, fallback) {
    return WAYFIND_MODIFIER_KEYS.includes(value) ? value : fallback;
  }
  function isValidTriggerKeyCode(value) {
    return typeof value === "string" && TRIGGER_KEY_CODE_PATTERN.test(value);
  }
  function isValidTriggerMouseButton(value) {
    return typeof value === "number" && TRIGGER_MOUSE_BUTTONS.includes(value);
  }
  function normalizeFlag(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function normalizeWayfindTrigger(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_WAYFIND_TRIGGER };
    }
    const trigger = value;
    const keyCode = isValidTriggerKeyCode(trigger.keyCode) ? trigger.keyCode : DEFAULT_WAYFIND_TRIGGER.keyCode;
    const mouseButton = isValidTriggerMouseButton(trigger.mouseButton) ? trigger.mouseButton : DEFAULT_WAYFIND_TRIGGER.mouseButton;
    return {
      modifier: normalizeModifierKey(trigger.modifier, DEFAULT_WAYFIND_TRIGGER.modifier),
      withShift: normalizeFlag(trigger.withShift, DEFAULT_WAYFIND_TRIGGER.withShift),
      kind: trigger.kind === "mouse" ? "mouse" : "key",
      keyCode,
      mouseButton
    };
  }
  function normalizeOverlayPosition(value) {
    if (typeof value !== "object" || value === null) return null;
    const position = value;
    const x = Number(position.xPercent);
    const y = Number(position.yPercent);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
    return {
      xPercent: Math.min(Math.max(x, 0), 100),
      yPercent: Math.min(Math.max(y, 0), 100)
    };
  }
  function normalizeMaxVisibleSegments(value) {
    const numeric = Number(value);
    if (!Number.isInteger(numeric)) return DEFAULT_WAYFIND_SETTINGS.maxVisibleSegments;
    return Math.min(Math.max(numeric, MIN_VISIBLE_SEGMENTS), MAX_VISIBLE_SEGMENTS);
  }
  function normalizeWayfindSettings(value) {
    if (typeof value !== "object" || value === null) {
      return { ...DEFAULT_WAYFIND_SETTINGS, trigger: { ...DEFAULT_WAYFIND_TRIGGER } };
    }
    const settings2 = value;
    return {
      trigger: normalizeWayfindTrigger(settings2.trigger),
      showTransitionArrows: normalizeFlag(
        settings2.showTransitionArrows,
        DEFAULT_WAYFIND_SETTINGS.showTransitionArrows
      ),
      overlayPosition: normalizeOverlayPosition(settings2.overlayPosition),
      maxVisibleSegments: normalizeMaxVisibleSegments(settings2.maxVisibleSegments)
    };
  }
  function formatWayfindModifierKey(modifier) {
    if (modifier === "ctrl") return "Ctrl / Control";
    if (modifier === "super") return "Super / Command";
    return "Alt / Option";
  }
  function formatTriggerKeyLabel(keyCode) {
    if (keyCode.startsWith("Key")) return keyCode.slice(3);
    if (keyCode.startsWith("Digit")) return keyCode.slice(5);
    return keyCode;
  }
  function formatTriggerMouseLabel(button) {
    if (button === 1) return "Middle Click";
    if (button === 2) return "Right Click";
    if (button === 3) return "Mouse 4";
    if (button === 4) return "Mouse 5";
    return `Mouse Button ${button}`;
  }
  function formatWayfindTriggerCombo(trigger) {
    const parts = [formatWayfindModifierKey(trigger.modifier).split(" / ")[0]];
    if (trigger.withShift) parts.push("Shift");
    parts.push(
      trigger.kind === "mouse" ? formatTriggerMouseLabel(trigger.mouseButton) : formatTriggerKeyLabel(trigger.keyCode)
    );
    return parts.join(" + ");
  }
  async function loadWayfindSettings() {
    try {
      const data = await import_webextension_polyfill.default.storage.local.get(WAYFIND_STORAGE_KEYS.settings);
      return normalizeWayfindSettings(data[WAYFIND_STORAGE_KEYS.settings]);
    } catch (_) {
      return { ...DEFAULT_WAYFIND_SETTINGS, trigger: { ...DEFAULT_WAYFIND_TRIGGER } };
    }
  }
  async function saveWayfindSettings(settings2) {
    await import_webextension_polyfill.default.storage.local.set({
      [WAYFIND_STORAGE_KEYS.settings]: normalizeWayfindSettings(settings2)
    });
  }

  // src/lib/core/trail/trailCore.ts
  function formatTrailTimestamp(timestamp, now) {
    const elapsed = Math.max(0, now - timestamp);
    const seconds = Math.floor(elapsed / 1e3);
    if (seconds < 45) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${Math.max(1, minutes)}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/asyncFlow.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // src/lib/adapters/runtime/runtimeClient.ts
  var DEFAULT_RUNTIME_RETRY_POLICY = {
    retryDelaysMs: [0, 80, 220, 420]
  };
  async function sendRuntimeMessage(message) {
    return await import_webextension_polyfill2.default.runtime.sendMessage(message);
  }
  async function sendRuntimeMessageWithRetry(message, policy = DEFAULT_RUNTIME_RETRY_POLICY) {
    let lastError = null;
    for (const delay of policy.retryDelaysMs) {
      if (delay > 0) {
        await sleep(delay);
      }
      try {
        return await sendRuntimeMessage(message);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error(`Runtime message failed: ${message.type}`);
  }

  // src/lib/adapters/runtime/wayfindApi.ts
  async function getTrailWithRetry(tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_GET", tabId });
  }
  async function jumpToTrailEntry(index, tabId) {
    return sendRuntimeMessageWithRetry({ type: "TRAIL_JUMP", index, tabId });
  }

  // src/lib/ui/settings/settingsControls.ts
  function populateModifierSelect(select, selected) {
    select.textContent = "";
    for (const modifier of WAYFIND_MODIFIER_KEYS) {
      const option = document.createElement("option");
      option.value = modifier;
      option.textContent = formatWayfindModifierKey(modifier);
      if (modifier === selected) option.selected = true;
      select.appendChild(option);
    }
  }

  // src/entryPoints/toolbarPopup/toolbarPopup.ts
  var settings = null;
  var capturing = false;
  var toastTimer = 0;
  var currentTabId;
  function element(id) {
    return document.getElementById(id);
  }
  function showPopupToast(message) {
    const toast = element("popupToast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 1800);
  }
  function displayUrl(url) {
    try {
      const parsed = new URL(url);
      return `${parsed.host}${parsed.pathname}`.replace(/\/$/, "") || parsed.host;
    } catch (_) {
      return url;
    }
  }
  function extractLetter(url) {
    try {
      const host = new URL(url).hostname.replace(/^www\./, "");
      return (host[0] ?? "?").toUpperCase();
    } catch (_) {
      return "?";
    }
  }
  function faviconNode(entry) {
    const wrap = document.createElement("span");
    wrap.className = "trail-item-favicon";
    if (entry.favIconUrl && /^https?:/.test(entry.favIconUrl)) {
      const img = document.createElement("img");
      img.src = entry.favIconUrl;
      img.alt = "";
      img.addEventListener("error", () => {
        img.remove();
        wrap.textContent = extractLetter(entry.url);
      });
      wrap.appendChild(img);
      return wrap;
    }
    wrap.textContent = extractLetter(entry.url);
    return wrap;
  }
  function triggerButtonLabel(trigger) {
    return trigger.kind === "mouse" ? formatTriggerMouseLabel(trigger.mouseButton) : formatTriggerKeyLabel(trigger.keyCode);
  }
  function renderSettings() {
    if (!settings) return;
    const { trigger } = settings;
    const modifierSelect = element("triggerModifier");
    if (modifierSelect) populateModifierSelect(modifierSelect, trigger.modifier);
    const shiftInput = element("triggerWithShift");
    if (shiftInput) shiftInput.checked = trigger.withShift;
    const captureButton = element("triggerCaptureBtn");
    if (captureButton && !capturing) {
      captureButton.textContent = triggerButtonLabel(trigger);
      captureButton.classList.remove("is-capturing");
    }
    const combo = formatWayfindTriggerCombo(trigger);
    const shortcutLabel = element("shortcutLabel");
    if (shortcutLabel) shortcutLabel.textContent = `Press ${combo} to show your trail`;
  }
  async function persistTrigger(patch) {
    if (!settings) return;
    settings = { ...settings, trigger: { ...settings.trigger, ...patch } };
    await saveWayfindSettings(settings);
    settings = await loadWayfindSettings();
    renderSettings();
    showPopupToast("Saved");
  }
  function captureKeydown(event) {
    event.preventDefault();
    event.stopPropagation();
    if (event.key === "Escape") {
      stopCapture();
      return;
    }
    if (isValidTriggerKeyCode(event.code)) {
      stopCapture();
      void persistTrigger({ kind: "key", keyCode: event.code });
    }
  }
  function captureMousedown(event) {
    if (!isValidTriggerMouseButton(event.button)) {
      if (event.button === 0) stopCapture();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    stopCapture();
    void persistTrigger({ kind: "mouse", mouseButton: event.button });
  }
  function captureContextMenu(event) {
    event.preventDefault();
    event.stopPropagation();
  }
  function startCapture() {
    if (capturing) return;
    capturing = true;
    const captureButton = element("triggerCaptureBtn");
    if (captureButton) {
      captureButton.textContent = "Press key / button\u2026";
      captureButton.classList.add("is-capturing");
    }
    window.setTimeout(() => {
      if (!capturing) return;
      window.addEventListener("keydown", captureKeydown, true);
      window.addEventListener("mousedown", captureMousedown, true);
      window.addEventListener("contextmenu", captureContextMenu, true);
    }, 0);
  }
  function stopCapture() {
    if (!capturing) return;
    capturing = false;
    window.removeEventListener("keydown", captureKeydown, true);
    window.removeEventListener("mousedown", captureMousedown, true);
    window.removeEventListener("contextmenu", captureContextMenu, true);
    renderSettings();
  }
  function renderTrail(state) {
    const list = element("trailList");
    const empty = element("trailEmpty");
    const count = element("trailCount");
    if (!list || !empty || !count) return;
    list.textContent = "";
    if (state.entries.length === 0) {
      empty.hidden = false;
      count.textContent = "";
      return;
    }
    empty.hidden = true;
    count.textContent = `${state.entries.length} page${state.entries.length === 1 ? "" : "s"}`;
    const now = Date.now();
    state.entries.forEach((entry, index) => {
      const item = document.createElement("li");
      item.className = "trail-item";
      if (index === state.cursor) item.classList.add("is-current");
      if (index > state.cursor) item.classList.add("is-forward");
      item.appendChild(faviconNode(entry));
      const body = document.createElement("div");
      body.className = "trail-item-body";
      const title = document.createElement("div");
      title.className = "trail-item-title";
      title.textContent = entry.title.trim() || displayUrl(entry.url);
      const url = document.createElement("div");
      url.className = "trail-item-url";
      url.textContent = displayUrl(entry.url);
      body.appendChild(title);
      body.appendChild(url);
      item.appendChild(body);
      const time = document.createElement("span");
      time.className = "trail-item-time";
      time.textContent = formatTrailTimestamp(entry.timestamp, now);
      item.appendChild(time);
      item.title = entry.url;
      if (index !== state.cursor) {
        item.addEventListener("click", async () => {
          const result = await jumpToTrailEntry(index, currentTabId);
          if (result && result.ok === false) {
            showPopupToast(result.reason || "Couldn't navigate.");
            return;
          }
          window.close();
        });
      }
      list.appendChild(item);
    });
  }
  async function refreshTrail() {
    try {
      const [activeTab] = await import_webextension_polyfill3.default.tabs.query({ active: true, currentWindow: true }).catch(() => []);
      currentTabId = activeTab?.id;
      const snapshot = await getTrailWithRetry(currentTabId);
      renderTrail(snapshot.state);
    } catch (_) {
      showPopupToast("Couldn't read the trail.");
    }
  }
  function bindControls() {
    element("closePopupBtn")?.addEventListener("click", () => window.close());
    element("triggerModifier")?.addEventListener("change", (event) => {
      const modifier = event.target.value;
      void persistTrigger({ modifier });
    });
    element("triggerWithShift")?.addEventListener("change", (event) => {
      void persistTrigger({ withShift: event.target.checked });
    });
    element("triggerCaptureBtn")?.addEventListener("click", startCapture);
    element("settingsBtn")?.addEventListener("click", async () => {
      try {
        await import_webextension_polyfill3.default.runtime.openOptionsPage();
      } catch (_) {
      }
      window.close();
    });
  }
  async function init() {
    settings = await loadWayfindSettings();
    renderSettings();
    bindControls();
    await refreshTrail();
  }
  void init();
})();
