"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/webextension-polyfill/dist/browser-polyfill.js
  var require_browser_polyfill = __commonJS({
    "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
      (function(global, factory) {
        if (typeof define === "function" && define.amd) {
          define("webextension-polyfill", ["module"], factory);
        } else if (typeof exports !== "undefined") {
          factory(module);
        } else {
          var mod = {
            exports: {}
          };
          factory(mod);
          global.browser = mod.exports;
        }
      })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
        "use strict";
        if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
          const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
          const wrapAPIs = (extensionAPIs) => {
            const apiMetadata = {
              "alarms": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "clearAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "bookmarks": {
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getChildren": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getRecent": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getSubTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTree": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeTree": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "browserAction": {
                "disable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "enable": {
                  "minArgs": 0,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "getBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "openPopup": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setBadgeBackgroundColor": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setBadgeText": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "browsingData": {
                "remove": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "removeCache": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCookies": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeDownloads": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFormData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeHistory": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeLocalStorage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePasswords": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removePluginData": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "settings": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "commands": {
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "contextMenus": {
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "cookies": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAllCookieStores": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "devtools": {
                "inspectedWindow": {
                  "eval": {
                    "minArgs": 1,
                    "maxArgs": 2,
                    "singleCallbackArg": false
                  }
                },
                "panels": {
                  "create": {
                    "minArgs": 3,
                    "maxArgs": 3,
                    "singleCallbackArg": true
                  },
                  "elements": {
                    "createSidebarPane": {
                      "minArgs": 1,
                      "maxArgs": 1
                    }
                  }
                }
              },
              "downloads": {
                "cancel": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "download": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "erase": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFileIcon": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "open": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "pause": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeFile": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "resume": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "extension": {
                "isAllowedFileSchemeAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "isAllowedIncognitoAccess": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "history": {
                "addUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "deleteRange": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "deleteUrl": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getVisits": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "search": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "i18n": {
                "detectLanguage": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAcceptLanguages": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "identity": {
                "launchWebAuthFlow": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "idle": {
                "queryState": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "management": {
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getSelf": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "setEnabled": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "uninstallSelf": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "notifications": {
                "clear": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPermissionLevel": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              },
              "pageAction": {
                "getPopup": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getTitle": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "hide": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setIcon": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "setPopup": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "setTitle": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                },
                "show": {
                  "minArgs": 1,
                  "maxArgs": 1,
                  "fallbackToNoCallback": true
                }
              },
              "permissions": {
                "contains": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "request": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "runtime": {
                "getBackgroundPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getPlatformInfo": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "openOptionsPage": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "requestUpdateCheck": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "sendMessage": {
                  "minArgs": 1,
                  "maxArgs": 3
                },
                "sendNativeMessage": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "setUninstallURL": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "sessions": {
                "getDevices": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getRecentlyClosed": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "restore": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "storage": {
                "local": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                },
                "managed": {
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  }
                },
                "sync": {
                  "clear": {
                    "minArgs": 0,
                    "maxArgs": 0
                  },
                  "get": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "getBytesInUse": {
                    "minArgs": 0,
                    "maxArgs": 1
                  },
                  "remove": {
                    "minArgs": 1,
                    "maxArgs": 1
                  },
                  "set": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              },
              "tabs": {
                "captureVisibleTab": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "create": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "detectLanguage": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "discard": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "duplicate": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "executeScript": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "getZoom": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getZoomSettings": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goBack": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "goForward": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "highlight": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "insertCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "move": {
                  "minArgs": 2,
                  "maxArgs": 2
                },
                "query": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "reload": {
                  "minArgs": 0,
                  "maxArgs": 2
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "removeCSS": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "sendMessage": {
                  "minArgs": 2,
                  "maxArgs": 3
                },
                "setZoom": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "setZoomSettings": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "update": {
                  "minArgs": 1,
                  "maxArgs": 2
                }
              },
              "topSites": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "webNavigation": {
                "getAllFrames": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "getFrame": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "webRequest": {
                "handlerBehaviorChanged": {
                  "minArgs": 0,
                  "maxArgs": 0
                }
              },
              "windows": {
                "create": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "get": {
                  "minArgs": 1,
                  "maxArgs": 2
                },
                "getAll": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getCurrent": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getLastFocused": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "update": {
                  "minArgs": 2,
                  "maxArgs": 2
                }
              }
            };
            if (Object.keys(apiMetadata).length === 0) {
              throw new Error("api-metadata.json has not been included in browser-polyfill");
            }
            class DefaultWeakMap extends WeakMap {
              constructor(createItem, items = void 0) {
                super(items);
                this.createItem = createItem;
              }
              get(key) {
                if (!this.has(key)) {
                  this.set(key, this.createItem(key));
                }
                return super.get(key);
              }
            }
            const isThenable = (value) => {
              return value && typeof value === "object" && typeof value.then === "function";
            };
            const makeCallback = (promise, metadata) => {
              return (...callbackArgs) => {
                if (extensionAPIs.runtime.lastError) {
                  promise.reject(new Error(extensionAPIs.runtime.lastError.message));
                } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                  promise.resolve(callbackArgs[0]);
                } else {
                  promise.resolve(callbackArgs);
                }
              };
            };
            const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
            const wrapAsyncFunction = (name, metadata) => {
              return function asyncFunctionWrapper(target, ...args) {
                if (args.length < metadata.minArgs) {
                  throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
                }
                if (args.length > metadata.maxArgs) {
                  throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
                }
                return new Promise((resolve, reject) => {
                  if (metadata.fallbackToNoCallback) {
                    try {
                      target[name](...args, makeCallback({
                        resolve,
                        reject
                      }, metadata));
                    } catch (cbError) {
                      console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                      target[name](...args);
                      metadata.fallbackToNoCallback = false;
                      metadata.noCallback = true;
                      resolve();
                    }
                  } else if (metadata.noCallback) {
                    target[name](...args);
                    resolve();
                  } else {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  }
                });
              };
            };
            const wrapMethod = (target, method, wrapper) => {
              return new Proxy(method, {
                apply(targetMethod, thisObj, args) {
                  return wrapper.call(thisObj, target, ...args);
                }
              });
            };
            let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
            const wrapObject = (target, wrappers = {}, metadata = {}) => {
              let cache = /* @__PURE__ */ Object.create(null);
              let handlers = {
                has(proxyTarget2, prop) {
                  return prop in target || prop in cache;
                },
                get(proxyTarget2, prop, receiver) {
                  if (prop in cache) {
                    return cache[prop];
                  }
                  if (!(prop in target)) {
                    return void 0;
                  }
                  let value = target[prop];
                  if (typeof value === "function") {
                    if (typeof wrappers[prop] === "function") {
                      value = wrapMethod(target, target[prop], wrappers[prop]);
                    } else if (hasOwnProperty(metadata, prop)) {
                      let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                      value = wrapMethod(target, target[prop], wrapper);
                    } else {
                      value = value.bind(target);
                    }
                  } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                    value = wrapObject(value, wrappers[prop], metadata[prop]);
                  } else if (hasOwnProperty(metadata, "*")) {
                    value = wrapObject(value, wrappers[prop], metadata["*"]);
                  } else {
                    Object.defineProperty(cache, prop, {
                      configurable: true,
                      enumerable: true,
                      get() {
                        return target[prop];
                      },
                      set(value2) {
                        target[prop] = value2;
                      }
                    });
                    return value;
                  }
                  cache[prop] = value;
                  return value;
                },
                set(proxyTarget2, prop, value, receiver) {
                  if (prop in cache) {
                    cache[prop] = value;
                  } else {
                    target[prop] = value;
                  }
                  return true;
                },
                defineProperty(proxyTarget2, prop, desc) {
                  return Reflect.defineProperty(cache, prop, desc);
                },
                deleteProperty(proxyTarget2, prop) {
                  return Reflect.deleteProperty(cache, prop);
                }
              };
              let proxyTarget = Object.create(target);
              return new Proxy(proxyTarget, handlers);
            };
            const wrapEvent = (wrapperMap) => ({
              addListener(target, listener, ...args) {
                target.addListener(wrapperMap.get(listener), ...args);
              },
              hasListener(target, listener) {
                return target.hasListener(wrapperMap.get(listener));
              },
              removeListener(target, listener) {
                target.removeListener(wrapperMap.get(listener));
              }
            });
            const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onRequestFinished(req) {
                const wrappedReq = wrapObject(req, {}, {
                  getContent: {
                    minArgs: 0,
                    maxArgs: 0
                  }
                });
                listener(wrappedReq);
              };
            });
            const onMessageWrappers = new DefaultWeakMap((listener) => {
              if (typeof listener !== "function") {
                return listener;
              }
              return function onMessage(message, sender, sendResponse) {
                let didCallSendResponse = false;
                let wrappedSendResponse;
                let sendResponsePromise = new Promise((resolve) => {
                  wrappedSendResponse = function(response) {
                    didCallSendResponse = true;
                    resolve(response);
                  };
                });
                let result;
                try {
                  result = listener(message, sender, wrappedSendResponse);
                } catch (err) {
                  result = Promise.reject(err);
                }
                const isResultThenable = result !== true && isThenable(result);
                if (result !== true && !isResultThenable && !didCallSendResponse) {
                  return false;
                }
                const sendPromisedResult = (promise) => {
                  promise.then((msg) => {
                    sendResponse(msg);
                  }, (error) => {
                    let message2;
                    if (error && (error instanceof Error || typeof error.message === "string")) {
                      message2 = error.message;
                    } else {
                      message2 = "An unexpected error occurred";
                    }
                    sendResponse({
                      __mozWebExtensionPolyfillReject__: true,
                      message: message2
                    });
                  }).catch((err) => {
                    console.error("Failed to send onMessage rejected reply", err);
                  });
                };
                if (isResultThenable) {
                  sendPromisedResult(result);
                } else {
                  sendPromisedResult(sendResponsePromise);
                }
                return true;
              };
            });
            const wrappedSendMessageCallback = ({
              reject,
              resolve
            }, reply) => {
              if (extensionAPIs.runtime.lastError) {
                if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                  resolve();
                } else {
                  reject(new Error(extensionAPIs.runtime.lastError.message));
                }
              } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
                reject(new Error(reply.message));
              } else {
                resolve(reply);
              }
            };
            const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                const wrappedCb = wrappedSendMessageCallback.bind(null, {
                  resolve,
                  reject
                });
                args.push(wrappedCb);
                apiNamespaceObj.sendMessage(...args);
              });
            };
            const staticWrappers = {
              devtools: {
                network: {
                  onRequestFinished: wrapEvent(onRequestFinishedWrappers)
                }
              },
              runtime: {
                onMessage: wrapEvent(onMessageWrappers),
                onMessageExternal: wrapEvent(onMessageWrappers),
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 1,
                  maxArgs: 3
                })
              },
              tabs: {
                sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                  minArgs: 2,
                  maxArgs: 3
                })
              }
            };
            const settingMetadata = {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            };
            apiMetadata.privacy = {
              network: {
                "*": settingMetadata
              },
              services: {
                "*": settingMetadata
              },
              websites: {
                "*": settingMetadata
              }
            };
            return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
          };
          module2.exports = wrapAPIs(chrome);
        } else {
          module2.exports = globalThis.browser;
        }
      });
    }
  });

  // src/lib/backgroundRuntime/domains/trailDomain.ts
  var import_webextension_polyfill2 = __toESM(require_browser_polyfill());

  // src/lib/common/contracts/wayfind.ts
  var import_webextension_polyfill = __toESM(require_browser_polyfill());
  var TRAIL_MIRROR_KEY_PREFIX = "wayfindTrail:";
  function trailMirrorKey(tabId) {
    return `${TRAIL_MIRROR_KEY_PREFIX}${tabId}`;
  }

  // src/lib/core/trail/trailCore.ts
  var TRAIL_MAX_ENTRIES = 100;
  var EMPTY_TRAIL_STATE = { entries: [], cursor: -1 };
  var KNOWN_TRANSITIONS = [
    "link",
    "typed",
    "reload",
    "spa",
    "fragment",
    "form",
    "back_forward",
    "other"
  ];
  function normalizeTrailTransition(value) {
    return KNOWN_TRANSITIONS.includes(value) ? value : "other";
  }
  function deriveTransition(event) {
    if (event.kind === "historyState") return "spa";
    if (event.kind === "refFragment") return "fragment";
    switch (event.transitionType) {
      case "link":
        return "link";
      case "typed":
      case "generated":
      case "keyword":
      case "keyword_generated":
        return "typed";
      case "reload":
        return "reload";
      case "form_submit":
        return "form";
      default:
        return "other";
    }
  }
  function hasQualifier(event, qualifier) {
    return Array.isArray(event.qualifiers) && event.qualifiers.includes(qualifier);
  }
  function makeEntry(event) {
    return {
      url: event.url,
      title: "",
      favIconUrl: "",
      timestamp: event.timestamp,
      transition: deriveTransition(event),
      redirected: hasQualifier(event, "client_redirect") || hasQualifier(event, "server_redirect")
    };
  }
  function refreshEntry(entry, event) {
    return {
      ...entry,
      url: event.url,
      timestamp: event.timestamp,
      redirected: entry.redirected || hasQualifier(event, "client_redirect") || hasQualifier(event, "server_redirect")
    };
  }
  function findBackForwardIndex(state, url) {
    const { entries, cursor } = state;
    for (let distance = 1; distance < entries.length; distance += 1) {
      const before = cursor - distance;
      if (before >= 0 && entries[before].url === url) return before;
      const after = cursor + distance;
      if (after < entries.length && entries[after].url === url) return after;
    }
    return -1;
  }
  function applyNavigationEvent(state, event) {
    const { entries, cursor } = state;
    const current = cursor >= 0 && cursor < entries.length ? entries[cursor] : null;
    if (!current) {
      return { state: { entries: [makeEntry(event)], cursor: 0 }, changed: true };
    }
    const jumpIndex = event.pendingJumpIndex;
    if (typeof jumpIndex === "number" && jumpIndex >= 0 && jumpIndex < entries.length && entries[jumpIndex].url === event.url) {
      if (jumpIndex === cursor) return { state, changed: false };
      return { state: { entries, cursor: jumpIndex }, changed: true };
    }
    if (event.transitionType === "reload" || event.url === current.url) {
      const next2 = entries.slice();
      next2[cursor] = refreshEntry(current, event);
      return { state: { entries: next2, cursor }, changed: true };
    }
    if (hasQualifier(event, "forward_back")) {
      const index = findBackForwardIndex(state, event.url);
      if (index !== -1) {
        return { state: { entries, cursor: index }, changed: true };
      }
    }
    const next = entries.slice(0, cursor + 1);
    next.push(makeEntry(event));
    let nextCursor = next.length - 1;
    const overflow = next.length - TRAIL_MAX_ENTRIES;
    if (overflow > 0) {
      next.splice(0, overflow);
      nextCursor -= overflow;
    }
    return { state: { entries: next, cursor: nextCursor }, changed: true };
  }
  function resolveJumpPlan(state, targetIndex) {
    const { entries, cursor } = state;
    if (!Number.isInteger(targetIndex) || targetIndex < 0 || targetIndex >= entries.length) {
      return null;
    }
    if (targetIndex === cursor) return null;
    const low = Math.min(cursor, targetIndex);
    const high = Math.max(cursor, targetIndex);
    for (let index = low + 1; index <= high; index += 1) {
      if (entries[index].redirected) {
        return { kind: "navigate", url: entries[targetIndex].url };
      }
    }
    return { kind: "historyGo", delta: targetIndex - cursor };
  }
  function normalizeTrailState(value) {
    if (typeof value !== "object" || value === null) {
      return { entries: [], cursor: -1 };
    }
    const raw = value;
    if (!Array.isArray(raw.entries)) return { entries: [], cursor: -1 };
    const entries = [];
    for (const item of raw.entries.slice(-TRAIL_MAX_ENTRIES)) {
      if (typeof item !== "object" || item === null) continue;
      const entry = item;
      if (typeof entry.url !== "string" || entry.url === "") continue;
      entries.push({
        url: entry.url,
        title: typeof entry.title === "string" ? entry.title : "",
        favIconUrl: typeof entry.favIconUrl === "string" ? entry.favIconUrl : "",
        timestamp: typeof entry.timestamp === "number" && Number.isFinite(entry.timestamp) ? entry.timestamp : 0,
        transition: normalizeTrailTransition(entry.transition),
        redirected: entry.redirected === true
      });
    }
    if (entries.length === 0) return { entries: [], cursor: -1 };
    const cursor = typeof raw.cursor === "number" && Number.isInteger(raw.cursor) ? Math.min(Math.max(raw.cursor, 0), entries.length - 1) : entries.length - 1;
    return { entries, cursor };
  }

  // src/lib/common/utils/asyncFlow.ts
  function createInFlightMemo(task) {
    let inFlight = null;
    return () => {
      if (inFlight) return inFlight;
      inFlight = task().catch((error) => {
        inFlight = null;
        throw error;
      });
      return inFlight;
    };
  }
  function createKeyedTaskQueue() {
    const tasksByKey = /* @__PURE__ */ new Map();
    return {
      run(key, task) {
        const previousTask = tasksByKey.get(key) ?? Promise.resolve();
        const result = previousTask.then(() => task());
        const settled = result.then(() => {
        }, () => {
        });
        tasksByKey.set(key, settled);
        void settled.then(() => {
          if (tasksByKey.get(key) === settled) {
            tasksByKey.delete(key);
          }
        });
        return result;
      }
    };
  }

  // src/lib/backgroundRuntime/domains/trailDomain.ts
  function normalizePageUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.href : null;
    } catch (_) {
      return null;
    }
  }
  var KNOWN_BROWSER_STORE_RESTRICTED_HOSTS = /* @__PURE__ */ new Set([
    "addons.mozilla.org",
    "chromewebstore.google.com"
  ]);
  function normalizeHostname(hostname) {
    return hostname.toLowerCase().replace(/^www\./, "");
  }
  function isKnownBrowserStoreRestrictedUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
      const hostname = normalizeHostname(parsed.hostname);
      if (KNOWN_BROWSER_STORE_RESTRICTED_HOSTS.has(hostname)) return true;
      return hostname === "chrome.google.com" && parsed.pathname.toLowerCase().startsWith("/webstore");
    } catch (_) {
      return false;
    }
  }
  function isPageGestureRestrictedUrl(url) {
    return !normalizePageUrl(url) || isKnownBrowserStoreRestrictedUrl(url);
  }
  function createTrailDomain() {
    const trailsByTabId = /* @__PURE__ */ new Map();
    const incognitoTabIds = /* @__PURE__ */ new Set();
    const overlayOpenTabIds = /* @__PURE__ */ new Set();
    const pendingJumpByTabId = /* @__PURE__ */ new Map();
    const tabQueue = createKeyedTaskQueue();
    const ensureLoaded = createInFlightMemo(rehydrate);
    function getSessionStore() {
      const store = import_webextension_polyfill2.default.storage.session;
      return store && typeof store.get === "function" ? store : null;
    }
    const sessionStore = getSessionStore();
    const mirrorStore = sessionStore ?? import_webextension_polyfill2.default.storage.local;
    const mirrorIsSessionScoped = sessionStore !== null;
    async function rehydrate() {
      const [stored, tabs] = await Promise.all([
        mirrorStore.get(null).catch(() => ({})),
        import_webextension_polyfill2.default.tabs.query({}).catch(() => [])
      ]);
      const liveTabIds = /* @__PURE__ */ new Set();
      for (const tab of tabs) {
        if (tab.id == null) continue;
        liveTabIds.add(tab.id);
        if (tab.incognito) incognitoTabIds.add(tab.id);
      }
      const staleKeys = [];
      for (const [key, value] of Object.entries(stored)) {
        if (!key.startsWith(TRAIL_MIRROR_KEY_PREFIX)) continue;
        const tabId = Number(key.slice(TRAIL_MIRROR_KEY_PREFIX.length));
        if (!Number.isInteger(tabId) || !liveTabIds.has(tabId)) {
          staleKeys.push(key);
          continue;
        }
        if (!trailsByTabId.has(tabId)) {
          const state = normalizeTrailState(value);
          if (state.entries.length > 0) trailsByTabId.set(tabId, state);
        }
      }
      if (staleKeys.length > 0) await mirrorStore.remove(staleKeys).catch(() => {
      });
    }
    function mirrorTrail(tabId) {
      if (incognitoTabIds.has(tabId) && !mirrorIsSessionScoped) return;
      const state = trailsByTabId.get(tabId);
      void tabQueue.run(tabId, async () => {
        if (!state || state.entries.length === 0) {
          await mirrorStore.remove(trailMirrorKey(tabId)).catch(() => {
          });
          return;
        }
        await mirrorStore.set({ [trailMirrorKey(tabId)]: state }).catch(() => {
        });
      });
    }
    async function isIncognitoTab(tabId) {
      if (incognitoTabIds.has(tabId)) return true;
      const tab = await import_webextension_polyfill2.default.tabs.get(tabId).catch(() => null);
      if (tab?.incognito) {
        incognitoTabIds.add(tabId);
        return true;
      }
      return false;
    }
    function getTrailState(tabId) {
      return trailsByTabId.get(tabId) ?? EMPTY_TRAIL_STATE;
    }
    async function pushTrailToTab(tabId, type) {
      const state = getTrailState(tabId);
      try {
        await import_webextension_polyfill2.default.tabs.sendMessage(tabId, { type, state }, { frameId: 0 });
        return true;
      } catch (_) {
        return false;
      }
    }
    function notifyOverlayIfOpen(tabId) {
      if (!overlayOpenTabIds.has(tabId)) return;
      void pushTrailToTab(tabId, "TRAIL_UPDATED");
    }
    function patchCursorEntry(tabId, tab) {
      const state = trailsByTabId.get(tabId);
      if (!state || state.cursor < 0) return;
      const entry = state.entries[state.cursor];
      if (!entry || tab.url !== entry.url) return;
      const title = typeof tab.title === "string" ? tab.title : entry.title;
      const favIconUrl = typeof tab.favIconUrl === "string" ? tab.favIconUrl : entry.favIconUrl;
      if (title === entry.title && favIconUrl === entry.favIconUrl) return;
      const entries = state.entries.slice();
      entries[state.cursor] = { ...entry, title, favIconUrl };
      trailsByTabId.set(tabId, { entries, cursor: state.cursor });
      mirrorTrail(tabId);
      notifyOverlayIfOpen(tabId);
    }
    async function patchCursorEntryFromLiveTab(tabId) {
      const tab = await import_webextension_polyfill2.default.tabs.get(tabId).catch(() => null);
      if (tab) patchCursorEntry(tabId, tab);
    }
    function handleNavigationDetails(kind, details) {
      if (details.frameId !== 0) return;
      const tabId = details.tabId;
      void tabQueue.run(tabId, async () => {
        await ensureLoaded();
        await isIncognitoTab(tabId);
        const pendingJumpIndex = pendingJumpByTabId.get(tabId) ?? null;
        pendingJumpByTabId.delete(tabId);
        const event = {
          kind,
          url: details.url,
          timestamp: Date.now(),
          transitionType: details.transitionType,
          qualifiers: details.transitionQualifiers,
          pendingJumpIndex
        };
        const { state, changed } = applyNavigationEvent(getTrailState(tabId), event);
        if (!changed) return;
        trailsByTabId.set(tabId, state);
        mirrorTrail(tabId);
        notifyOverlayIfOpen(tabId);
      }).then(() => patchCursorEntryFromLiveTab(tabId));
    }
    async function executeContentScriptInTab(tabId, allFrames) {
      const runtimeBrowser = import_webextension_polyfill2.default;
      try {
        if (runtimeBrowser.scripting?.executeScript) {
          await runtimeBrowser.scripting.executeScript({
            target: { tabId, ...allFrames ? { allFrames: true } : {} },
            files: ["contentScript.js"]
          });
          return true;
        }
        if (runtimeBrowser.tabs.executeScript) {
          await runtimeBrowser.tabs.executeScript(tabId, {
            file: "contentScript.js",
            runAt: "document_start",
            ...allFrames ? { allFrames: true } : {}
          });
          return true;
        }
      } catch (_) {
        return false;
      }
      return false;
    }
    async function injectContentScriptIntoTab(tab) {
      if (tab.id == null || tab.discarded === true || isPageGestureRestrictedUrl(tab.url)) return "skipped";
      if (await executeContentScriptInTab(tab.id, true)) return "injected";
      return await executeContentScriptInTab(tab.id, false) ? "injected" : "failed";
    }
    async function activateExistingContentScripts() {
      const tabs = await import_webextension_polyfill2.default.tabs.query({}).catch(() => []);
      await Promise.all(tabs.map((tab) => injectContentScriptIntoTab(tab)));
    }
    async function resolveTargetTabId(tabId, senderTab) {
      if (tabId != null) return tabId;
      if (senderTab?.id != null) return senderTab.id;
      const [active] = await import_webextension_polyfill2.default.tabs.query({ active: true, currentWindow: true }).catch(() => []);
      return active?.id ?? null;
    }
    async function toggleOverlay(senderTab) {
      await ensureLoaded();
      const tabId = senderTab?.id;
      if (tabId == null) return { ok: false, reason: "No tab for overlay" };
      const delivered = await pushTrailToTab(tabId, "TRAIL_SHOW");
      return delivered ? { ok: true } : { ok: false, reason: "Overlay unavailable on this page" };
    }
    async function getTrail(tabId, senderTab) {
      await ensureLoaded();
      const targetTabId = await resolveTargetTabId(tabId, senderTab);
      if (targetTabId == null) return { ok: false, tabId: null, state: EMPTY_TRAIL_STATE };
      return { ok: true, tabId: targetTabId, state: getTrailState(targetTabId) };
    }
    async function jumpTo(index, tabId, senderTab) {
      await ensureLoaded();
      const targetTabId = await resolveTargetTabId(tabId, senderTab);
      if (targetTabId == null) return { ok: false, reason: "No tab to navigate" };
      const state = getTrailState(targetTabId);
      const plan = resolveJumpPlan(state, index);
      if (!plan) return { ok: true };
      pendingJumpByTabId.set(targetTabId, index);
      if (plan.kind === "historyGo") {
        try {
          await import_webextension_polyfill2.default.tabs.sendMessage(targetTabId, { type: "HISTORY_GO", delta: plan.delta }, { frameId: 0 });
          return { ok: true };
        } catch (_) {
        }
      }
      const url = state.entries[index]?.url;
      if (!url) {
        pendingJumpByTabId.delete(targetTabId);
        return { ok: false, reason: "Trail entry missing" };
      }
      try {
        await import_webextension_polyfill2.default.tabs.update(targetTabId, { url });
        return { ok: true };
      } catch (_) {
        pendingJumpByTabId.delete(targetTabId);
        return { ok: false, reason: "Navigation failed" };
      }
    }
    async function openEntryInNewTab(index, tabId, senderTab) {
      await ensureLoaded();
      const targetTabId = await resolveTargetTabId(tabId, senderTab);
      if (targetTabId == null) return { ok: false, reason: "No source tab" };
      const entry = getTrailState(targetTabId).entries[index];
      if (!entry) return { ok: false, reason: "Trail entry missing" };
      const sourceTab = await import_webextension_polyfill2.default.tabs.get(targetTabId).catch(() => null);
      try {
        await import_webextension_polyfill2.default.tabs.create({
          url: entry.url,
          active: false,
          ...sourceTab?.windowId != null ? { windowId: sourceTab.windowId } : {},
          ...sourceTab?.index != null ? { index: sourceTab.index + 1 } : {}
        });
        return { ok: true };
      } catch (_) {
        return { ok: false, reason: "Could not open tab" };
      }
    }
    function setOverlayOpen(senderTab, open) {
      const tabId = senderTab?.id;
      if (tabId == null) return { ok: false, reason: "No tab" };
      if (open) overlayOpenTabIds.add(tabId);
      else overlayOpenTabIds.delete(tabId);
      return { ok: true };
    }
    function markContentScriptReady(_tab) {
      return { ok: true };
    }
    async function handleStartup() {
      trailsByTabId.clear();
      overlayOpenTabIds.clear();
      pendingJumpByTabId.clear();
      incognitoTabIds.clear();
      if (mirrorIsSessionScoped) return;
      const stored = await import_webextension_polyfill2.default.storage.local.get(null).catch(() => ({}));
      const keys = Object.keys(stored).filter((key) => key.startsWith(TRAIL_MIRROR_KEY_PREFIX));
      if (keys.length > 0) await import_webextension_polyfill2.default.storage.local.remove(keys).catch(() => {
      });
    }
    function handleTabRemoved(tabId) {
      trailsByTabId.delete(tabId);
      overlayOpenTabIds.delete(tabId);
      pendingJumpByTabId.delete(tabId);
      const wasIncognito = incognitoTabIds.delete(tabId);
      if (!(wasIncognito && !mirrorIsSessionScoped)) {
        void mirrorStore.remove(trailMirrorKey(tabId)).catch(() => {
        });
      }
    }
    function registerLifecycleListeners() {
      import_webextension_polyfill2.default.webNavigation.onCommitted.addListener((details) => {
        handleNavigationDetails("committed", details);
      });
      import_webextension_polyfill2.default.webNavigation.onHistoryStateUpdated.addListener((details) => {
        handleNavigationDetails("historyState", details);
      });
      import_webextension_polyfill2.default.webNavigation.onReferenceFragmentUpdated.addListener((details) => {
        handleNavigationDetails("refFragment", details);
      });
      import_webextension_polyfill2.default.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        if (changeInfo.title == null && changeInfo.favIconUrl == null) return;
        patchCursorEntry(tabId, tab);
      });
      import_webextension_polyfill2.default.tabs.onRemoved.addListener((tabId) => {
        handleTabRemoved(tabId);
      });
      import_webextension_polyfill2.default.runtime.onInstalled.addListener(() => {
        void activateExistingContentScripts();
      });
      import_webextension_polyfill2.default.runtime.onStartup.addListener(() => {
        void handleStartup();
      });
    }
    return {
      ensureLoaded,
      toggleOverlay,
      getTrail,
      jumpTo,
      openEntryInNewTab,
      setOverlayOpen,
      markContentScriptReady,
      activateExistingContentScripts,
      registerLifecycleListeners
    };
  }

  // src/lib/backgroundRuntime/handlers/trailMessageHandler.ts
  var import_webextension_polyfill4 = __toESM(require_browser_polyfill());

  // src/lib/backgroundRuntime/handlers/runtimeRouter.ts
  var import_webextension_polyfill3 = __toESM(require_browser_polyfill());
  var UNHANDLED = Symbol("background-runtime-unhandled");
  function registerRuntimeMessageRouter(handlers) {
    import_webextension_polyfill3.default.runtime.onMessage.addListener(async (receivedMessage, sender) => {
      if (typeof receivedMessage !== "object" || receivedMessage === null) return null;
      const message = receivedMessage;
      for (const handler of handlers) {
        try {
          const result = await handler(message, sender);
          if (result !== UNHANDLED) {
            return result;
          }
        } catch (error) {
          console.error("[Wayfind] Runtime message handler failed:", error);
          if (message.type === "TRAIL_GET") {
            throw error;
          }
          return { ok: false, reason: "Internal error" };
        }
      }
      return null;
    });
  }

  // src/lib/backgroundRuntime/handlers/trailMessageHandler.ts
  async function openOptionsPage() {
    try {
      await import_webextension_polyfill4.default.runtime.openOptionsPage();
      return { ok: true };
    } catch (_) {
      return { ok: false, reason: "Settings unavailable" };
    }
  }
  function createTrailMessageHandler(domain) {
    return async (message, sender) => {
      switch (message.type) {
        case "TRAIL_CONTENT_READY":
          return domain.markContentScriptReady(sender.tab);
        case "TRAIL_GET":
          return await domain.getTrail(message.tabId, sender.tab);
        case "TRAIL_TOGGLE_OVERLAY":
          return await domain.toggleOverlay(sender.tab);
        case "TRAIL_JUMP":
          return await domain.jumpTo(message.index, message.tabId, sender.tab);
        case "TRAIL_OPEN_IN_NEW_TAB":
          return await domain.openEntryInNewTab(message.index, message.tabId, sender.tab);
        case "TRAIL_OVERLAY_STATE":
          return domain.setOverlayOpen(sender.tab, message.open);
        case "WAYFIND_OPEN_OPTIONS":
          return await openOptionsPage();
        default:
          return UNHANDLED;
      }
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  var import_webextension_polyfill5 = __toESM(require_browser_polyfill());

  // src/lib/common/utils/storageMigrations.ts
  var STORAGE_SCHEMA_VERSION_KEY = "storageSchemaVersion";
  var STORAGE_SCHEMA_VERSION = 1;
  function readSchemaVersion(storage) {
    const numeric = Number(storage[STORAGE_SCHEMA_VERSION_KEY]);
    if (!Number.isFinite(numeric)) return 0;
    const rounded = Math.floor(numeric);
    return rounded > 0 ? rounded : 0;
  }
  function isStorageSchemaVersionCurrent(rawVersion) {
    return Number(rawVersion) === STORAGE_SCHEMA_VERSION;
  }
  function createCurrentVersionMigrationResult() {
    return {
      fromVersion: STORAGE_SCHEMA_VERSION,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed: false,
      migratedStorage: {}
    };
  }
  function migrateStorageSnapshot(input) {
    const migratedStorage = { ...input };
    const fromVersion = readSchemaVersion(input);
    if (fromVersion > STORAGE_SCHEMA_VERSION) {
      return {
        fromVersion,
        toVersion: fromVersion,
        changed: false,
        migratedStorage
      };
    }
    let changed = false;
    if (migratedStorage[STORAGE_SCHEMA_VERSION_KEY] !== STORAGE_SCHEMA_VERSION) {
      migratedStorage[STORAGE_SCHEMA_VERSION_KEY] = STORAGE_SCHEMA_VERSION;
      changed = true;
    }
    return {
      fromVersion,
      toVersion: STORAGE_SCHEMA_VERSION,
      changed,
      migratedStorage
    };
  }

  // src/lib/common/utils/storageMigrationsRuntime.ts
  async function migrateStorageIfNeeded() {
    const versionSnapshot = await import_webextension_polyfill5.default.storage.local.get(STORAGE_SCHEMA_VERSION_KEY);
    if (isStorageSchemaVersionCurrent(versionSnapshot[STORAGE_SCHEMA_VERSION_KEY])) {
      return createCurrentVersionMigrationResult();
    }
    const snapshot = await import_webextension_polyfill5.default.storage.local.get(null);
    const result = migrateStorageSnapshot(snapshot);
    if (!result.changed) return result;
    const deletedKeys = Object.keys(snapshot).filter((key) => !(key in result.migratedStorage));
    if (deletedKeys.length > 0) {
      await import_webextension_polyfill5.default.storage.local.remove(deletedKeys);
    }
    await import_webextension_polyfill5.default.storage.local.set(result.migratedStorage);
    return result;
  }

  // src/entryPoints/backgroundRuntime/background.ts
  var trail = createTrailDomain();
  trail.registerLifecycleListeners();
  registerRuntimeMessageRouter([
    createTrailMessageHandler(trail)
  ]);
  async function bootstrapBackground() {
    const migration = await migrateStorageIfNeeded();
    if (migration.changed) {
      console.log(
        `[Wayfind] Storage migration applied (${migration.fromVersion} -> ${migration.toVersion}).`
      );
    }
    void trail.ensureLoaded();
  }
  void bootstrapBackground().catch((error) => {
    console.error("[Wayfind] Background bootstrap failed:", error);
  });
})();
