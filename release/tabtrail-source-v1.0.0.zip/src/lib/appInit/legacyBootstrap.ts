declare global {
  interface Window {
    __tabtrailCleanup?: () => void;
  }
}

/** Retires the combined content-script bootstrap used before the bundle split. */
export function retireLegacyCombinedBootstrap(): void {
  const cleanup = window.__tabtrailCleanup;
  if (!cleanup) return;
  try {
    cleanup();
  } catch (_) {
    // An update can invalidate the old extension context before cleanup runs.
  } finally {
    delete window.__tabtrailCleanup;
  }
}
